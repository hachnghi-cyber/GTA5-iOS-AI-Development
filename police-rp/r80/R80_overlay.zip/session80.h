#ifndef RP_SESSION80_H
#define RP_SESSION80_H
#include <stdint.h>
#include <stddef.h>
/* Diagnostics only. No writes, game calls, identifiers or authorization. */
typedef int (*RP80Read)(void *,uintptr_t,void *,size_t);
enum {RP80_UNAVAILABLE,RP80_NO_SESSION,RP80_TRANSITION,RP80_PUBLIC,RP80_PRIVATE};
int rp80_read(RP80Read,void *,uintptr_t);
int rp80_device(void);
#endif
