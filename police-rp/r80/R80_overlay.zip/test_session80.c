#include "session80.c"
#include <assert.h>
#include <stdio.h>
static uintptr_t base=0x100000000,ptr=0x200000000;
static unsigned bad,mutate,reads;static uint32_t status=5,flags=1,field=1;
static int readfake(void *v,uintptr_t a,void *out,size_t n){
 (void)v;uintptr_t off=a-base;uint32_t header[]={0xfeedfacf,0x0100000c,0,2,1,24,0,0},cmd[]={0x1b,24};
 #define COPY(o,x) if(off==(o)&&n==sizeof(x)){memcpy(out,&(x),n);return 1;}
 COPY(0,header) COPY(32,cmd)
 if(off==40&&n==sizeof uuid){memcpy(out,uuid,n);if(bad==1)((char*)out)[0]^=1;return 1;}
 if(off==0xcee078&&bad==2)return 0;
 COPY(0xcee078,wrapper) COPY(0x17247d8,established) COPY(0x1724800,leaving) COPY(0x181ba2c,privacy)
 COPY(0x3263d60,ptr)
 if(a==ptr+0x1864c&&n==4){uint32_t x=status;if(mutate&&reads++)x++;memcpy(out,&x,n);return 1;}
 if(a==ptr+0x1836c&&n==4){if(bad==3)return 0;memcpy(out,&flags,n);return 1;}
 if(a==ptr+0x180fc&&n==4){memcpy(out,&field,n);return 1;}
 return 0;
}
int main(void){assert(rp80_device()==0);assert(rp80_read(readfake,0,base)==RP80_PRIVATE);flags=0;assert(rp80_read(readfake,0,base)==RP80_PUBLIC);flags=1;field=0;assert(rp80_read(readfake,0,base)==RP80_PUBLIC);field=1;status=7;assert(rp80_read(readfake,0,base)==RP80_TRANSITION);status=5;ptr=0;assert(rp80_read(readfake,0,base)==RP80_NO_SESSION);ptr=0x200000001;assert(rp80_read(readfake,0,base)==0);ptr=0x200000000;for(bad=1;bad<=3;bad++)assert(rp80_read(readfake,0,base)==0);bad=0;mutate=1;assert(rp80_read(readfake,0,base)==0);assert(rp80_read(readfake,0,UINTPTR_MAX)==0);assert(rp80_read(0,0,base)==0);puts("PASS 13 checks: privacy, transition, no session, UUID/code mismatch, unreadable, unstable, overflow, null provider; no game call");return 0;}
