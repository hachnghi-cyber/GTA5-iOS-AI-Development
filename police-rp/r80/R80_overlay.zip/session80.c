#include "session80.h"
#include <string.h>
#define READ(off,dst) (rd(ctx,base+(uintptr_t)(off),&(dst),sizeof(dst)))
#define MATCH(off,expected) (rd(ctx,base+(uintptr_t)(off),buf,sizeof(expected))&&!memcmp(buf,expected,sizeof(expected)))
/* Exact R72 UUID and complete audited predicate bodies; this is NOT a full image hash. */
static const unsigned char uuid[]={0xdc,0x32,0xa2,0x7a,0xe4,0x07,0x32,0x0f,0x8f,0x52,0x76,0x51,0x50,0x44,0xb1,0xa9};
static const uint32_t established[]={0xf000d9e8,0xf946b108,0xb40000c8,0x91406109,0xb9464d28,0x7100151f,0x1a9f17e0,0xd65f03c0,0x52800000,0xd65f03c0};
static const uint32_t leaving[]={0xf000d9e8,0xf946b108,0xb40000c8,0x91406109,0xb9464d28,0x71001d1f,0x1a9fd7e0,0xd65f03c0,0x52800000,0xd65f03c0};
static const uint32_t wrapper[]={0xb0012ba8,0x91358108,0xf9400100,0x52800001,0x142cb669};
static const uint32_t privacy[]={0x8b21c808,0x91406109,0xb9436d28,0x37000068,0x52800000,0xd65f03c0,0x52802908,0x9b280028,0x91406109,0xb940fd28,0x7100011f,0x1a9f07e0,0xd65f03c0};
static int exact(RP80Read rd,void *ctx,uintptr_t base){
 unsigned char buf[64];uint32_t h[8],cmd[2];unsigned seen=0;size_t pos=32;
 if(!rd||!base||base>UINTPTR_MAX-0x3263d68||!READ(0,h)||h[0]!=0xfeedfacf||h[1]!=0x0100000c||h[3]!=2||h[4]>128||h[5]>16384)return 0;
 size_t end=32+h[5];
 for(unsigned i=0;i<h[4];i++){
  if(pos>end||end-pos<8||!READ(pos,cmd)||cmd[1]<8||cmd[1]%8||cmd[1]>end-pos)return 0;
  if(cmd[0]==0x1b){if(cmd[1]!=24||seen++||!MATCH(pos+8,uuid))return 0;}
  pos+=cmd[1];
 }
 return seen==1&&pos==end&&MATCH(0x17247d8,established)&&MATCH(0x1724800,leaving)&&MATCH(0xcee078,wrapper)&&MATCH(0x181ba2c,privacy);
}
typedef struct {uintptr_t ptr;uint32_t status,flags,field;} State;
static int sample(RP80Read rd,void *ctx,uintptr_t base,State *s){
 *s=(State){0};if(!READ(0x3263d60,s->ptr))return 0;
 if(!s->ptr)return 1;
 if((s->ptr&7)||s->ptr>UINTPTR_MAX-0x18650)return 0;
 /* SessionType=0: offsets and predicates from the four audited functions. */
 return rd(ctx,s->ptr+0x1864c,&s->status,4)&&rd(ctx,s->ptr+0x1836c,&s->flags,4)&&rd(ctx,s->ptr+0x180fc,&s->field,4);
}
int rp80_read(RP80Read rd,void *ctx,uintptr_t base){
 State a,b;if(!exact(rd,ctx,base)||!sample(rd,ctx,base,&a)||!sample(rd,ctx,base,&b)||a.ptr!=b.ptr||a.status!=b.status||a.flags!=b.flags||a.field!=b.field)return RP80_UNAVAILABLE;
 if(!a.ptr)return RP80_NO_SESSION;
 if(a.status!=5)return RP80_TRANSITION;
 /* CommandNetworkIsPrivateSession passes SessionType=0. */
 return (a.flags&1)&&a.field?RP80_PRIVATE:RP80_PUBLIC;
}
#ifdef __APPLE__
#include <mach/mach.h>
#include <mach-o/dyld.h>
static int self_read(void *ctx,uintptr_t addr,void *out,size_t n){
 (void)ctx;vm_size_t got=0;return vm_read_overwrite(mach_task_self(),(vm_address_t)addr,(vm_size_t)n,(vm_address_t)out,&got)==KERN_SUCCESS&&got==n;
}
int rp80_device(void){return rp80_read(self_read,0,(uintptr_t)_dyld_get_image_header(0));}
#else
int rp80_device(void){return RP80_UNAVAILABLE;}
#endif
