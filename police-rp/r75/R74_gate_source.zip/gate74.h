#ifndef RP_GATE74_H
#define RP_GATE74_H
#include "bootstrap55.h"
#include <pthread.h>
/* Zero-initialized caller-owned, process lifetime, initialized once on independently verified owner.
 * Trusted adapter must provide real room privacy, current consent and monotonic
 * time. Packet fields and thread-observer counters are NOT evidence. */
#define RP74_MAX_AGE_MS 250u
typedef struct { RP46Roster roster; uint64_t observed_ms, consent_generation; int verified; } RP74Snapshot;
typedef struct { void *arg; int (*arm)(void*,const RP46Roster*); int (*tick)(void*); int (*confirm)(void*,uint32_t); int (*stop)(void*); } RP74Ops;
enum { RP74_IDLE, RP74_ACTIVE, RP74_STOP_PENDING };
typedef struct { pthread_t owner; RP74Ops ops; RP74Snapshot agreed; uint64_t last_ms,last_generation,last_press; unsigned state,busy,initialized; } RP74;
int rp74_init(RP74*,const RP74Ops*);
int rp74_start(RP74*,const RP74Snapshot*,uint64_t now,uint64_t explicit_press_serial);
int rp74_frame(RP74*,const RP74Snapshot*,uint64_t now);
int rp74_confirm(RP74*,const RP74Snapshot*,uint64_t now,uint64_t explicit_press_serial,uint32_t displayed_token);
int rp74_stop(RP74*);
/* Bind existing lifecycle only AFTER separately verified bootstrap is ready. */
int rp74_bind55(RP74*);
#endif
