#include "gate74.h"
#include <assert.h>
#include <stdio.h>
int main(void){RP74 g={0};assert(rp55_status()==RP55_COLD);assert(!rp74_bind55(&g));assert(!rp53_get_api());assert(!rp74_start(&g,NULL,0,1));assert(!rp74_frame(&g,NULL,0));assert(!rp74_stop(&g));puts("PASS full native core stays cold; no engine address invoked");return 0;}
