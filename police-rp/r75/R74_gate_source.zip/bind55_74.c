#include "gate74.h"
static int arm(void*a,const RP46Roster*r){(void)a;return rp55_arm(r,1);}
static int tick(void*a){(void)a;return rp55_tick(1);}
static int confirm(void*a,uint32_t t){(void)a;return rp55_confirm(t,1,1);}
static int stop(void*a){(void)a;return rp55_stop();}
int rp74_bind55(RP74*p){if(rp55_status()!=RP55_READY)return 0;RP74Ops o={0,arm,tick,confirm,stop};return rp74_init(p,&o);}
