#include "gate74.h"
static int enter(RP74 *p){if(!p||!p->initialized||!pthread_equal(pthread_self(),p->owner)||p->busy)return 0;p->busy=1;return 1;}
static int leave(RP74 *p,int r){p->busy=0;return r;}
static int valid(const RP74Snapshot*s,uint64_t now){
 if(!s||s->verified!=1||!s->consent_generation||s->observed_ms>now||now-s->observed_ms>RP74_MAX_AGE_MS)return 0;
 const RP46Roster*r=&s->roster;const RP45Context*c=&r->ctx;
 if(r->count<2||r->count>RP46_MAX||!c->session||!c->host||!c->local||!c->epoch||c->slot>=32||c->private_room!=1||c->local_opted!=1||c->all_opted!=1)return 0;
 unsigned host=0,local=0;for(unsigned i=0;i<r->count;i++){const RP46Member*m=&r->members[i];if(!m->id||m->slot>=32||m->opted!=1||(i&&m->slot<=r->members[i-1].slot))return 0;for(unsigned j=0;j<i;j++)if(m->id==r->members[j].id)return 0;host+=m->id==c->host;local+=m->id==c->local&&m->slot==c->slot;}
 return host==1&&local==1;
}
static int same(const RP74Snapshot*a,const RP74Snapshot*b){const RP46Roster*x=&a->roster,*y=&b->roster;const RP45Context*c=&x->ctx,*d=&y->ctx;if(a->consent_generation!=b->consent_generation||x->count!=y->count||c->session!=d->session||c->host!=d->host||c->local!=d->local||c->slot!=d->slot||c->epoch!=d->epoch)return 0;for(unsigned i=0;i<x->count;i++)if(x->members[i].id!=y->members[i].id||x->members[i].slot!=y->members[i].slot)return 0;return 1;}
static int stop_locked(RP74*p){if(p->state==RP74_IDLE)return 1;p->state=RP74_STOP_PENDING;if(!p->ops.stop(p->ops.arg))return 0;p->state=RP74_IDLE;p->agreed=(RP74Snapshot){0};return 1;}
static int current(RP74*p,const RP74Snapshot*s,uint64_t now){if(p->state!=RP74_ACTIVE)return 0;if(now<p->last_ms||!valid(s,now)||s->observed_ms<p->agreed.observed_ms||!same(&p->agreed,s)){stop_locked(p);return 0;}p->last_ms=now;p->agreed.observed_ms=s->observed_ms;return 1;}
int rp74_init(RP74*p,const RP74Ops*o){if(!p||p->initialized||!o||!o->arm||!o->tick||!o->confirm||!o->stop)return 0;*p=(RP74){.owner=pthread_self(),.ops=*o,.initialized=1};return 1;}
int rp74_start(RP74*p,const RP74Snapshot*s,uint64_t now,uint64_t press){if(!enter(p))return 0;if(p->state!=RP74_IDLE||now<p->last_ms||!press||press<=p->last_press)return leave(p,0);p->last_press=press;p->last_ms=now;if(!valid(s,now)||s->consent_generation<=p->last_generation)return leave(p,0);p->last_generation=s->consent_generation;p->agreed=*s;p->state=RP74_STOP_PENDING;if(!p->ops.arm(p->ops.arg,&p->agreed.roster)){stop_locked(p);return leave(p,0);}p->state=RP74_ACTIVE;return leave(p,1);}
int rp74_frame(RP74*p,const RP74Snapshot*s,uint64_t now){if(!enter(p))return 0;if(p->state==RP74_STOP_PENDING){stop_locked(p);return leave(p,0);}if(!current(p,s,now))return leave(p,0);if(!p->ops.tick(p->ops.arg)){stop_locked(p);return leave(p,0);}return leave(p,1);}
int rp74_confirm(RP74*p,const RP74Snapshot*s,uint64_t now,uint64_t press,uint32_t token){if(!enter(p))return 0;if(!current(p,s,now))return leave(p,0);if(!press||press<=p->last_press||!token)return leave(p,0);p->last_press=press;return leave(p,p->ops.confirm(p->ops.arg,token));}
int rp74_stop(RP74*p){if(!enter(p))return 0;return leave(p,stop_locked(p));}
