/*
 * Police RP ONLY v1.8 - RAGE network player manager OBSERVATION PROBE.
 * For original GTA5 iOS v12 ARM64 UUID only.
 *
 * Reads a snapshot of game-managed network player slots via vm_read_overwrite
 * from SELF. No hooks, writes, function calls into RAGE, identity lookups, or
 * network sends. All slot IDs are unverified until device/roster correlation.
 * Do not enable Menyoo or ScriptHook in GTA Online.
 *
 * Reverse-engineered from original GTA5 v12:
 *  CNetworkPlayerMgr::GetActivePlayerFromIndex(unsigned char):
 *      manager initialized at +0x8f8, 32 slots at +0x900, stride 0x430.
 *  rage::netPlayer::IsValid(): a local-player special case, otherwise
 *      32-bit marker at slot+0x1c not 0 or UINT32_MAX.
 *  MacportJobPlayerActive(): local player's index is a byte at slot+0x21.
 * These offsets are *version-locked*, and not a public engine ABI.
 */
#include <dispatch/dispatch.h>
#include <mach/mach.h>
#include <mach/vm_map.h>
#include <mach-o/dyld.h>
#include <mach-o/loader.h>
#include <mach/vm_prot.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

#define V12_ONLINE_MODE ((uintptr_t)0x1027B1AE8ULL)
#define V12_JOB         ((uintptr_t)0x1027B1B2CULL)
#define V12_SHIFT       ((uintptr_t)0x10355EE34ULL)
#define V12_SESSION     ((uintptr_t)0x10355577DULL)
#define V12_INGAME      ((uintptr_t)0x1035501FCULL)
#define V12_TAGS        ((uintptr_t)0x10356504CULL)
#define V12_BLIPS       ((uintptr_t)0x1035650CCULL)
#define V12_CNETWORK_MGR_POINTER ((uintptr_t)0x102719600ULL)
#define V12_INTERFACE_MGR_POINTER ((uintptr_t)0x103446028ULL)
#define V12_SLOTS       32U
#define V12_MGR_INIT_OFFSET 0x8F8U
#define V12_MGR_LOCAL_OFFSET 0x100U
#define V12_MGR_SLOTS_OFFSET 0x900U
#define V12_SLOT_STRIDE 0x430U
#define V12_SLOT_STATUS 0x1CU
#define V12_SLOT_NETID  0x21U
#define PRP_FILE "PoliceRPNetwork-v18.txt"
#define PRP_HEARTBEAT 20U
#define PRP_MAX_LINES 250U
static const uint8_t kUuid[16]={0x6a,0x49,0x8e,0x32,0xe7,0x0c,0x33,0x4c,
                                0xbc,0xa3,0xaf,0xfd,0x35,0xe8,0xd1,0x71};
static dispatch_source_t gTimer;
static uintptr_t gSlide;
static unsigned gTicks,gLines;
static uint64_t gPrevious;
static int gHavePrevious;

static void logline(const char *s,int truncate_file) {
    if (!truncate_file && gLines>=PRP_MAX_LINES) return;
    fprintf(stderr,"%s\n",s);
    const char *home=getenv("HOME");
    if (!home || !*home) return;
    char file[1024];
    int n=snprintf(file,sizeof(file),"%s/Documents/" PRP_FILE,home);
    if (n<0 || (size_t)n>=sizeof(file)) return;
    FILE *f=fopen(file,truncate_file?"w":"a");
    if (!f) return;
    int ok=(fputs(s,f)>=0 && fputc('\n',f)!=EOF);
    if (fclose(f)!=0) ok=0;
    if (ok) gLines=truncate_file?1U:gLines+1U;
}

static int image_contains(const struct mach_header_64 *h, uintptr_t addr, size_t bytes) {
    const uint8_t *cmds=(const uint8_t *)(h+1);
    size_t off=0;
    for (uint32_t i=0;i<h->ncmds;i++) {
        if (off>h->sizeofcmds || h->sizeofcmds-off<sizeof(struct load_command)) return 0;
        const struct load_command *c=(const struct load_command *)(cmds+off);
        if (c->cmdsize<sizeof(struct load_command) || c->cmdsize>h->sizeofcmds-off) return 0;
        if (c->cmd==LC_SEGMENT_64 && c->cmdsize>=sizeof(struct segment_command_64)) {
            const struct segment_command_64 *s=(const struct segment_command_64 *)c;
            if ((s->initprot & VM_PROT_READ) && bytes<=s->vmsize &&
                addr>=s->vmaddr && addr-s->vmaddr<=s->vmsize-bytes) return 1;
        }
        off+=c->cmdsize;
    }
    return 0;
}

static int resolve_image(void) {
    uint32_t count=_dyld_image_count();
    for (uint32_t i=0;i<count;i++) {
        const char *name=_dyld_get_image_name(i);
        if (!name) continue;
        const char *b=strrchr(name,'/');
        if (strcmp(b?b+1:name,"GTA5")) continue;
        const struct mach_header_64 *h=(const struct mach_header_64 *)_dyld_get_image_header(i);
        if (!h || h->magic!=MH_MAGIC_64 || h->cputype!=CPU_TYPE_ARM64 ||
            h->filetype!=MH_EXECUTE || h->ncmds>512 || h->sizeofcmds>1024*1024) return 0;
        size_t off=0;
        const uint8_t *cmds=(const uint8_t *)(h+1);
        int uuidok=0;
        for (uint32_t j=0;j<h->ncmds;j++) {
            if (off>h->sizeofcmds || h->sizeofcmds-off<sizeof(struct load_command)) return 0;
            const struct load_command *c=(const struct load_command *)(cmds+off);
            if (c->cmdsize<sizeof(struct load_command) || c->cmdsize>h->sizeofcmds-off) return 0;
            if (c->cmd==LC_UUID && c->cmdsize>=sizeof(struct uuid_command))
                uuidok=!memcmp(((const struct uuid_command *)c)->uuid,kUuid,sizeof(kUuid));
            off+=c->cmdsize;
        }
        if (!uuidok) return 0;
        const uintptr_t pos[]={V12_ONLINE_MODE,V12_JOB,V12_SHIFT,V12_SESSION,
           V12_INGAME,V12_TAGS,V12_BLIPS,V12_CNETWORK_MGR_POINTER,V12_INTERFACE_MGR_POINTER};
        const size_t len[]={4,4,1,1,1,32*4,32*4,8,8};
        for (unsigned j=0;j<sizeof(pos)/sizeof(pos[0]);j++)
            if (!image_contains(h,pos[j],len[j])) return 0;
        gSlide=(uintptr_t)_dyld_get_image_vmaddr_slide(i);
        return 1;
    }
    return 0;
}

/* Kernel-checked copy avoids dereferencing stale, unmapped game pointers.
 * Failure is expected during disconnect/reconnect; never retry in a loop. */
static int copy_self(uintptr_t addr, void *dst, size_t n) {
    if (!dst || !n || addr<0x10000 || addr>UINTPTR_MAX-n) return 0;
    vm_size_t copied=0;
    kern_return_t kr=vm_read_overwrite(mach_task_self(),
        (vm_address_t)addr,(vm_size_t)n,(vm_address_t)(uintptr_t)dst,&copied);
    return kr==KERN_SUCCESS && copied==(vm_size_t)n;
}

static uint64_t signature(int mode,int job,unsigned shift,unsigned session,unsigned in_game,
                          uint32_t tag,uint32_t blip,uint32_t valid,uint32_t idmask,
                          uint32_t local,unsigned ready,unsigned source_match,unsigned failed) {
    uint64_t h=UINT64_C(14695981039346656037);
#define MIX(n) do{ h^=(uint32_t)(n); h*=UINT64_C(1099511628211); }while(0)
    MIX(mode);MIX(job);MIX(shift);MIX(session);MIX(in_game);MIX(tag);MIX(blip);
    MIX(valid);MIX(idmask);MIX(local);MIX(ready);MIX(source_match);MIX(failed);
#undef MIX
    return h;
}

static void sample(void *ctx) {
    (void)ctx;
    ++gTicks;
    int32_t mode=-99,job=-99;
    uint8_t shift=0,session=0,ingame=0;
    if (!copy_self(V12_ONLINE_MODE+gSlide,&mode,4) ||
        !copy_self(V12_JOB+gSlide,&job,4) ||
        !copy_self(V12_SHIFT+gSlide,&shift,1) ||
        !copy_self(V12_SESSION+gSlide,&session,1) ||
        !copy_self(V12_INGAME+gSlide,&ingame,1)) {
        if (gTicks==1 || gTicks%PRP_HEARTBEAT==0)
            logline("[PRP_NET_V18] game_globals_read_failed=1 observe_only=1",0);
        return;
    }
    if (job<-1 || job>64 || shift>1 || session>1 || ingame>1) return;
    uint32_t tagmask=0,blipmask=0;
    int32_t tags[V12_SLOTS]={0},blips[V12_SLOTS]={0};
    int tags_ok=copy_self(V12_TAGS+gSlide,tags,sizeof(tags));
    int blips_ok=copy_self(V12_BLIPS+gSlide,blips,sizeof(blips));
    if (tags_ok && blips_ok) {
        for (unsigned i=0;i<V12_SLOTS;i++) {
            if (tags[i]>0) tagmask|=UINT32_C(1)<<i;
            if (blips[i]>0) blipmask|=UINT32_C(1)<<i;
        }
    }
    uintptr_t mgr=0,mgr_alt=0;
    int a=copy_self(V12_INTERFACE_MGR_POINTER+gSlide,&mgr,sizeof(mgr));
    int b=copy_self(V12_CNETWORK_MGR_POINTER+gSlide,&mgr_alt,sizeof(mgr_alt));
    unsigned source_match=(a && b && mgr && mgr==mgr_alt)?1U:0U;
    unsigned ready=0,failed=(!tags_ok || !blips_ok)?1U:0U;
    uint32_t validmask=0,idmask=0,localmask=0;
    char ids[256];
    size_t used=0;
    ids[0]='\0';
    if (a && mgr>=0x10000 && mgr<UINTPTR_MAX-0x10000) {
        uint8_t initialized=0;
        uintptr_t local_ptr=0;
        if (copy_self(mgr+V12_MGR_INIT_OFFSET,&initialized,1) &&
            copy_self(mgr+V12_MGR_LOCAL_OFFSET,&local_ptr,sizeof(local_ptr))) {
            ready=(initialized&1U)?1U:0U;
            if (ready) {
                for (unsigned i=0;i<V12_SLOTS;i++) {
                    uintptr_t addr=mgr+V12_MGR_SLOTS_OFFSET+(uintptr_t)i*V12_SLOT_STRIDE;
                    uint8_t raw[8];
                    if (!copy_self(addr+V12_SLOT_STATUS,raw,sizeof(raw))) {failed++;continue;}
                    uint32_t state=0;
                    memcpy(&state,raw,sizeof(state));
                    int is_local=(local_ptr==addr);
                    if (is_local || (state!=0U && state!=UINT32_MAX)) {
                        validmask|=UINT32_C(1)<<i;
                        if (is_local) localmask|=UINT32_C(1)<<i;
                        unsigned id=raw[V12_SLOT_NETID-V12_SLOT_STATUS];
                        if (id<32U) {
                            idmask|=UINT32_C(1)<<id;
                            int n=snprintf(ids+used,sizeof(ids)-used,"%s%u:%u",used?",":"",i,id);
                            if (n<0 || (size_t)n>=sizeof(ids)-used) {ids[0]='\0';used=0;break;}
                            used+=(size_t)n;
                        }
                    }
                }
            }
        } else failed++;
    }
    uint64_t sig=signature(mode,job,shift,session,ingame,tagmask,blipmask,
                            validmask,idmask,localmask,ready,source_match,failed);
    if (!gHavePrevious || sig!=gPrevious || gTicks%PRP_HEARTBEAT==0) {
        char line[700];
        snprintf(line,sizeof(line),
          "[PRP_NET_V18] tick=%u job=%d shift=%u police_active=%u online_mode_raw=%d "
          "session_started_raw=%u was_in_game_raw=%u manager_present=%u manager_initialized=%u "
          "manager_sources_match=%u network_valid_slot_mask=%08x network_valid_slot_count=%u "
          "network_local_slot_mask=%08x network_id_raw_mask=%08x visual_tag_mask=%08x "
          "visual_blip_mask=%08x slot_read_failures=%u ids_raw=%s "
          "player_id_verified=0 player_count_verified=0 arrest_target_verified=0 hooks=0 network_events=0",
          gTicks,job,(unsigned)shift,(unsigned)(job>=0 && job<=2 && shift),mode,
          (unsigned)session,(unsigned)ingame,(unsigned)(a && mgr!=0),ready,source_match,
          validmask,(unsigned)__builtin_popcount(validmask),localmask,idmask,tagmask,blipmask,failed,
          used?ids:"none");
        logline(line,0);
        gPrevious=sig;
        gHavePrevious=1;
    }
}

__attribute__((constructor)) static void start_probe(void) {
    int ok=resolve_image();
    char line[240];
    snprintf(line,sizeof(line),
       "[PRP_DIAG_V18] dylib_loaded=1 gta5_uuid_verified=%d hooks=0 "
       "network_events=0 police_gameplay=0 memory_reader=vm_read_overwrite",ok);
    logline(line,1);
    if (!ok) return;
    gTimer=dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER,0,0,dispatch_get_main_queue());
    if (!gTimer) { logline("[PRP_NET_V18] timer_create_failed=1",0);return; }
    dispatch_source_set_event_handler_f(gTimer,sample);
    dispatch_source_set_timer(gTimer,dispatch_time(DISPATCH_TIME_NOW,NSEC_PER_SEC),
                              NSEC_PER_SEC,100*NSEC_PER_MSEC);
    dispatch_resume(gTimer);
}
