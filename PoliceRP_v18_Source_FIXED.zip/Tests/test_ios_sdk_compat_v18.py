"""Regress Xcode 16.4 iPhoneOS missing mach_vm.h API failure."""
from pathlib import Path
import unittest

SOURCE = Path(__file__).resolve().parents[1] / "Diagnostics" / "PoliceRPNetworkProbe.c"

class TestIOSSDKCompat(unittest.TestCase):
    def test_supported_sdk_header(self):
        s = SOURCE.read_text()
        self.assertIn("#include <mach/vm_map.h>", s)
        self.assertNotIn("#include <mach/mach_vm.h>", s)
    def test_supported_read_api(self):
        s = SOURCE.read_text()
        self.assertIn("kern_return_t kr=vm_read_overwrite(mach_task_self(),", s)
        self.assertIn("vm_size_t copied=0;", s)
        self.assertIn("(vm_address_t)addr,(vm_size_t)n,(vm_address_t)(uintptr_t)dst,&copied", s)
        self.assertNotIn("mach_vm_read_overwrite", s)
    def test_diagnostic_markers_kept(self):
        s = SOURCE.read_text()
        for marker in ("player_id_verified=0", "arrest_target_verified=0", "hooks=0", "network_events=0", "police_gameplay=0", "gta5_uuid_verified=%d"):
            self.assertIn(marker, s)

if __name__ == "__main__":
    unittest.main()
