# GTA V iOS v12 – Police RP ONLY v1.8 (Network Manager Probe)

## Kết quả v1.7 đã xác minh trên iPhone

- Log 25 mẫu trong khoảng tick 1–240, thư viện load và UUID đúng.
- Mặt nạ `tag` và `blip` trùng nhau tại mọi mẫu; từ 4 lên 5, về 4 rồi tới 7 ô dương.
- `job=0 shift=1` nhận ca cảnh sát, `job=-1 shift=0` kết thúc ca.
- Chưa thể suy ra số người trong phòng hay Player ID từ các biểu tượng.

## Bước tiến v1.8

Đã tìm được từ nhị phân **GTA5 v12 ARM64 gốc**:

- `rage::netInterface::m_PlayerMgr` = VM `0x103446028`, là vị trí chứa con trỏ manager.
- `CNetwork::sm_PlayerMgr` = VM `0x102719600`, vị trí manager tham chiếu bổ sung.
- `CNetworkPlayerMgr::GetActivePlayerFromIndex(unsigned char)` = VM `0x1018D81A4`.
- Theo assembly, manager có 32 slot tại `+0x900`, stride `0x430` và bit initialized tại `+0x8F8`.
- `rage::netPlayer::IsValid` = VM `0x101FFB96C` kiểm tra trạng thái tại `slot+0x1C`, có ngoại lệ local player.
- `MacportJobPlayerActive` = VM `0x1000F6FBC` cho thấy byte `slot+0x21` có vai trò index người chơi.

**v1.8 KHÔNG gọi bất kỳ hàm RAGE nào.** Mọi giá trị chỉ đọc qua `mach_vm_read_overwrite` đối với chính tiến trình. Nếu vùng nhớ bị giải phóng lúc rời phòng, lệnh đọc phải trả lỗi thay vì dereference con trỏ không hợp lệ. Log chỉ số slot / raw ID, không ghi tên người chơi hay địa chỉ IP.

### Chức năng

- Kiểm tra GTA5 UUID của đúng v12 và địa chỉ thuộc segment đọc được.
- Theo dõi cờ initialized của network manager, số slot RAGE được đánh dấu hợp lệ và slot nhân vật cục bộ.
- Quan sát byte index từng slot như **dữ liệu thô**, chưa xác minh ID người chơi.
- So sánh cùng lúc `network_valid_slot_mask`, `visual_tag_mask`, `visual_blip_mask`, nghề cảnh sát, trạng thái Online.
- Không patch game logic, không hook, không gửi gói mạng, không còng hoặc điều khiển nhân vật.
- Người chơi khác vẫn có thể dùng v12 thường; họ không cần mod để phục vụ phép đo chẩn đoán này.

### Build trên GitHub bằng iPhone

1. Đưa **PoliceRP_v18_Source.zip** vào thư mục gốc repository GitHub (giữ nguyên ZIP).
2. Đưa **import-police-rp-v18-IPHONE.yml** vào `.github/workflows/build-prp-v18-network-ios.yml`.
3. Mở GitHub Actions → chọn **Police RP v1.8 - Build network manager READ ONLY** → **Run workflow**.
4. Tải artifact `PRP-v18-iPhone-ARM64-NETWORK-MANAGER-READ-ONLY` và gửi vào ChatGPT.
5. Sau khi kiểm tra dylib và đóng IPA unsigned từ v12 gốc, sao lưu rồi ký/cài để thử.

### Thử iPhone sau khi có IPA

- Story Mode ~10s; vào Online solo ~20s; vào phòng người khác có 2–5 người ~30s; thử có người mới vào/rời ~20s.
- Nhận ca và kết thúc ca Cảnh sát Los Santos nếu cần.
- Gửi `Documents/PoliceRPNetwork-v18.txt`.
- Nếu có thể, ghi lại **số người thực thấy trên danh sách Online và thời điểm người vào/rời**, để so sánh chứ không đoán từ bitmask.

### Giới hạn / rủi ro

- **Đây chỉ là mã nguồn**, chưa qua build Xcode, chưa có IPA v1.8, chưa chạy trên iPhone.
- `mach_vm_read_overwrite` có thể bị sandbox từ chối; log báo lỗi đọc, không cố gắng bypass.
- Phương thức/offset nêu trên là chi tiết riêng của đúng GTA5 v12, có thể thay đổi ở bản khác.
- Mã có kiểm tra read-safe nhưng chỉ thử thực tế mới biết ổn định. Sao lưu trước khi cài.
- `player_id_verified=0`, `player_count_verified=0`, `arrest_target_verified=0` là điều kiện bắt buộc; không dùng các raw ID để xử lý còng/giam.
- Không bật Menyoo, ScriptHook hoặc Zombie trong Online. Không dùng bản HostGate.
