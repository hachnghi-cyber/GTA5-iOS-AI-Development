import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'Tools'))
from check_network_v18 import analyze
from analyze_visual_v17 import events

H='[PRP_DIAG_V18] dylib_loaded=1 gta5_uuid_verified=1 hooks=0 network_events=0 police_gameplay=0 memory_reader=mach_vm_read_overwrite'

def sample(tick=1,valid='00000001',count=1,local='00000001',ids='0:0',ready=1):
    return ('[PRP_NET_V18] tick=%d job=0 shift=1 police_active=1 online_mode_raw=3 '
    'session_started_raw=1 was_in_game_raw=1 manager_present=1 manager_initialized=%d '
    'manager_sources_match=1 network_valid_slot_mask=%s network_valid_slot_count=%d '
    'network_local_slot_mask=%s network_id_raw_mask=00000001 visual_tag_mask=%s '
    'visual_blip_mask=%s slot_read_failures=0 ids_raw=%s '
    'player_id_verified=0 player_count_verified=0 arrest_target_verified=0 hooks=0 network_events=0' %
    (tick,ready,valid,count,local,valid,valid,ids))

class TestNetworkV18(unittest.TestCase):
    def test_not_verified(self):self.assertEqual(analyze(sample())['status'],'NOT_VERIFIED')
    def test_no_samples(self):self.assertEqual(analyze(H)['status'],'NO_SAMPLES')
    def test_sample(self):self.assertEqual(analyze(H+'\n'+sample())['status'],'NETWORK_MANAGER_SEEN')
    def test_no_manager(self):self.assertEqual(analyze(H+'\n'+sample(ready=0))['status'],'NETWORK_MANAGER_NOT_SEEN')
    def test_changes(self):
        report=analyze('\n'.join([H,sample(),sample(2,'00000003',2,'00000001','0:0,1:1')]))
        self.assertEqual(report['status'],'NETWORK_SLOT_CHANGE_OBSERVED')
        self.assertEqual(report['network_slot_changes'][0]['appeared'],[1])
    def test_local_subset(self):self.assertEqual(analyze(H+'\n'+sample(local='00000002'))['status'],'BAD_SAMPLE')
    def test_count_bad(self):self.assertEqual(analyze(H+'\n'+sample(count=2))['status'],'BAD_SAMPLE')
    def test_id_out_of_range(self):self.assertEqual(analyze(H+'\n'+sample(ids='0:32'))['status'],'BAD_SAMPLE')
    def test_id_from_missing_slot(self):self.assertEqual(analyze(H+'\n'+sample(ids='1:1'))['status'],'BAD_SAMPLE')
    def test_duplicate_slot(self):self.assertEqual(analyze(H+'\n'+sample(ids='0:1,0:2'))['status'],'BAD_SAMPLE')
    def test_non_increasing(self):self.assertEqual(analyze(H+'\n'+sample()+'\n'+sample())['status'],'BAD_SAMPLE')
    def test_truncated(self):self.assertEqual(analyze(H+'\n'+sample()[:-5])['status'],'MALFORMED_SAMPLE')
    def test_bad_mask(self):self.assertEqual(analyze(H+'\n'+sample(valid='zzzzzzzz'))['status'],'MALFORMED_SAMPLE')
    def test_errors(self):self.assertTrue(analyze(H+'\n[PRP_NET_V18] game_globals_read_failed=1 observe_only=1')['diagnostic_errors'])
    def test_v17_transitions(self):
        fake='\n'.join([
          '[PRP_ROSTER_V17] tick=39 tag_positive_mask=00000017 blip_positive_mask=00000017',
          '[PRP_ROSTER_V17] tick=43 tag_positive_mask=00000037 blip_positive_mask=00000037',
          '[PRP_ROSTER_V17] tick=72 tag_positive_mask=00000035 blip_positive_mask=00000035'])
        result=events(fake)
        self.assertEqual(result[1]['appeared'],[5])
        self.assertEqual(result[2]['disappeared'],[1])
    def test_privacy_no_names(self):
        self.assertNotIn('gamer_tag',sample())
        self.assertNotIn('ip_address',sample())

if __name__=='__main__':unittest.main()
