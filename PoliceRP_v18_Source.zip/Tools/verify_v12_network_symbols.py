#!/usr/bin/env python3
"""Static identity/symbol gate for ORIGINAL v12 GTA5, not a dynamic game hook."""
import argparse
import hashlib
import json
import re
from pathlib import Path

EXPECTED_SHA='d252115585d8f81987fa88138e89e190d42a7ca8134421f0a5f639af27c8585b'
EXPECTED={
    'rage::netInterface::m_PlayerMgr':(0x103446028,'__ZN4rage12netInterface11m_PlayerMgrE'),
    'CNetwork::sm_PlayerMgr':(0x102719600,'__ZN8CNetwork12sm_PlayerMgrE'),
    'rage::netPlayerMgrBase::IsInitialized':(0x101fe69dc,'__ZNK4rage16netPlayerMgrBase13IsInitializedEv'),
    'CNetworkPlayerMgr::GetActivePlayerFromIndex':(0x1018d81a4,'__ZN17CNetworkPlayerMgr24GetActivePlayerFromIndexEh'),
    'rage::netPlayer::IsValid':(0x101ffb96c,'__ZNK4rage9netPlayer7IsValidEv'),
    'CNetworkPlayerMgr::GetMyPlayer':(0x10185a304,'__ZN17CNetworkPlayerMgr11GetMyPlayerEv'),
    'MacportJobPlayerActive':(0x1000f6fbc,'__ZL22MacportJobPlayerActivei'),
    'MacportJobPlayerOfPed':(0x100106800,'__ZL21MacportJobPlayerOfPedi'),
}

def check(binary,symbols):
    data=Path(binary).read_bytes()
    digest=hashlib.sha256(data).hexdigest()
    text=Path(symbols).read_text('utf-8',errors='replace')
    resolved={}
    for name,(addr,mangled) in EXPECTED.items():
        rows=[line for line in text.splitlines() if mangled in line]
        exact=any(re.match(r'^%016x\s+.*?\s%s\s*$'%(addr,re.escape(mangled)),x) for x in rows)
        resolved[name]={'expected_vmaddr':f'{addr:016x}','symbol_found_at_address':exact}
    return {'original_sha256_matches':digest==EXPECTED_SHA,'sha256':digest,
            'verified_symbols':resolved,'safe_to_build_for_this_binary':digest==EXPECTED_SHA and
                                      all(v['symbol_found_at_address'] for v in resolved.values()),
            'important':'Static symbol/assembly matches do NOT prove runtime IDs or gameplay.'}

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('GTA5')
    p.add_argument('symbols')
    args=p.parse_args()
    result=check(args.GTA5,args.symbols)
    print(json.dumps(result,indent=2))
    raise SystemExit(0 if result['safe_to_build_for_this_binary'] else 2)
