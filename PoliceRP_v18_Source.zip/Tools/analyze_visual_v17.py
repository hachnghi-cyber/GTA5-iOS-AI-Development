#!/usr/bin/env python3
"""Summarize verified change events in a v1.7 observation log for later correlation."""
import re
import sys
from pathlib import Path

def events(text):
    previous=None
    result=[]
    for line in text.splitlines():
        if not line.startswith('[PRP_ROSTER_V17] tick='):continue
        m=re.search(r'tick=(\d+).*?tag_positive_mask=([0-9a-f]{8}).*?blip_positive_mask=([0-9a-f]{8})',line)
        if not m:continue
        tick=int(m[1]);tag=int(m[2],16);blip=int(m[3],16)
        if previous is None or previous!=tag:
            prev=previous or 0
            result.append(dict(tick=tick,tag=hex(tag),blip=hex(blip),
               appeared=[i for i in range(32) if ((tag&~prev)>>i)&1],
               disappeared=[i for i in range(32) if ((prev&~tag)>>i)&1]))
            previous=tag
    return result

if __name__=='__main__':
    import json
    print(json.dumps(events(Path(sys.argv[1]).read_text()),indent=2))
