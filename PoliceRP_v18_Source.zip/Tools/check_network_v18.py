#!/usr/bin/env python3
"""Parse ONLY v1.8 passive network-manager diagnostics. Never treat raw IDs as authenticated."""
import json
import re
import sys
from pathlib import Path

KVS = re.compile(r'(\w+)=([^\s]+)')
MASKS = ('network_valid_slot_mask','network_local_slot_mask','network_id_raw_mask','visual_tag_mask','visual_blip_mask')
NUMERIC = ('tick','job','shift','police_active','online_mode_raw','session_started_raw',
           'was_in_game_raw','manager_present','manager_initialized','manager_sources_match',
           'network_valid_slot_count','slot_read_failures')

def analyze(text):
    rows = []
    headers=[line for line in text.splitlines() if line.startswith('[PRP_DIAG_V18]')]
    if not headers or 'gta5_uuid_verified=1' not in headers[-1]:
        return {'status':'NOT_VERIFIED','samples':0}
    errors=[]
    for line in text.splitlines():
        if line.startswith('[PRP_NET_V18]') and 'tick=' not in line:
            errors.append(line)
            continue
        if not line.startswith('[PRP_NET_V18] tick='): continue
        raw=dict(KVS.findall(line))
        if not all(k in raw for k in MASKS + NUMERIC + ('ids_raw','player_id_verified','arrest_target_verified','player_count_verified','hooks','network_events')):
            return {'status':'MALFORMED_SAMPLE','samples':len(rows)}
        try:
            row={k:int(raw[k]) for k in NUMERIC}
            row.update({k:int(raw[k],16) for k in MASKS})
            ids = [] if raw['ids_raw']=='none' else [tuple(int(v) for v in item.split(':'))
                                                      for item in raw['ids_raw'].split(',')]
        except (ValueError, TypeError):
            return {'status':'MALFORMED_SAMPLE','samples':len(rows)}
        row['ids_raw']=ids
        if (row['network_valid_slot_count']!=row['network_valid_slot_mask'].bit_count() or
            row['network_local_slot_mask'] & ~row['network_valid_slot_mask'] or
            any(not (0<=s<32 and 0<=n<32) for s,n in ids) or
            len({s for s,_ in ids})!=len(ids) or
            any(not row['network_valid_slot_mask']&(1<<s) for s,_ in ids) or
            int(raw['player_id_verified'])!=0 or int(raw['arrest_target_verified'])!=0 or
            int(raw['player_count_verified'])!=0 or int(raw['hooks'])!=0 or
            int(raw['network_events'])!=0 or
            row['tick']<1 or (rows and rows[-1]['tick']>=row['tick'])):
            return {'status':'BAD_SAMPLE','samples':len(rows)}
        rows.append(row)
    if not rows:
        return {'status':'NO_SAMPLES','samples':0,'diagnostic_errors':errors}
    changes=[]
    for prev,cur in zip(rows,rows[1:]):
        a=prev['network_valid_slot_mask']; b=cur['network_valid_slot_mask']
        if a!=b:
            changes.append({'tick':cur['tick'],
                            'appeared':[i for i in range(32) if ((b&~a)>>i)&1],
                            'disappeared':[i for i in range(32) if ((a&~b)>>i)&1]})
    return {
        'status':'NETWORK_SLOT_CHANGE_OBSERVED' if changes else
                 'NETWORK_MANAGER_SEEN' if any(r['manager_initialized'] for r in rows)
                 else 'NETWORK_MANAGER_NOT_SEEN',
        'samples':len(rows),'engine_manager_initialized':any(r['manager_initialized'] for r in rows),
        'network_slot_changes':changes,
        'last_valid_network_slots':rows[-1]['network_valid_slot_count'],
        'last_visual_tag_slots':rows[-1]['visual_tag_mask'].bit_count(),
        'last_raw_id_map':rows[-1]['ids_raw'],
        'read_failures_recorded':sum(r['slot_read_failures'] for r in rows),
        'diagnostic_errors':errors,'verified_remote_player_ids':False,
        'verified_player_count':False,'verified_arrest_targets':False,
        'warning':'RAGE network slot indices and raw byte IDs are not authenticated remote IDs or consent.'
    }

if __name__=='__main__':
    print(json.dumps(analyze(Path(sys.argv[1]).read_text('utf-8',errors='replace')),
                     indent=2,ensure_ascii=False))
