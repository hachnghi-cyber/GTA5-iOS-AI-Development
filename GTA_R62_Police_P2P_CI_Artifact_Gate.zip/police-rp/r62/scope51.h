#ifndef SCOPE51_H
#define SCOPE51_H
#include "thread50.h"
/* Synchronous call-site wrappers only. Installer must establish original
 * targets, exact call sites, same-thread lifetime, and real monotonic clock.
 * No code patch or automatic registration is performed by this module. */
typedef struct RP51Scope RP51Scope;
typedef struct {
 void *arg;
 void (*receive)(void*,void*,const void*);
 int (*decode)(void*,void*,const void*,unsigned,void*);
 void (*dispatch)(void*,void*,void*,const void*,const char*,unsigned);
 int (*deliver)(void*,const void*,const char*,size_t,uint32_t);
 int (*owner)(void*);
 uint32_t (*now)(void*);
} RP51Ops;
typedef struct { RP51Ops ops; RP51Scope *scope; } RP51;
int rp51_init(RP51*,const RP51Ops*);
void rp51_receive(RP51*,void*,const void*);
int rp51_decode(RP51*,void*,const void*,unsigned,void*);
void rp51_dispatch(RP51*,void*,void*,const void*,const char*,unsigned);
int rp51_post_permission(RP51*,const void*,const char*);
/* Native binding uses original R42 offsets; only valid after external exact
 * build + actual hook-site verification. No installation in this function. */
typedef struct { RP51 binding; RP50 *gate; uintptr_t base; uint32_t (*clock)(void*); void *clock_arg; } RP51Native;
int rp51_native_init(RP51Native*,RP50*,uint32_t(*)(void*),void*);
#endif
