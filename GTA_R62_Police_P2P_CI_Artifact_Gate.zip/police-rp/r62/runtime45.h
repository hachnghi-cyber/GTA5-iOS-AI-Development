#ifndef RUNTIME45_H
#define RUNTIME45_H
#include "state44.h"
/* Single game-thread coordinator. The adapter must supply verified session,
 * actual host identity and explicit opt-in of every member; no wire field is trusted as identity. */
typedef struct {uint64_t session,host,local;uint32_t epoch;uint8_t slot,private_room,all_opted,local_opted;} RP45Context;
typedef struct {RP45Context ctx;RP44Client client;RPRoom room;RP44State views[RP_MAX];uint32_t revision;uint8_t active,is_host;} RP45Runtime;
int runtime45_begin(RP45Runtime*,const RP45Context*,uint32_t generation,uint32_t now);
int runtime45_live(RP45Runtime*,const RP45Context*,uint32_t now);
int runtime45_join(RP45Runtime*,const RP45Context*,unsigned slot,uint64_t id,int explicit_optin,uint32_t now);
int runtime45_observe(RP45Runtime*,const RP45Context*,unsigned slot,uint64_t id,const int32_t xyz[3],int alive,uint32_t now);
int runtime45_leave(RP45Runtime*,const RP45Context*,unsigned slot,uint64_t id,uint32_t now);
int runtime45_admin(RP45Runtime*,const RP45Context*,unsigned op,unsigned target,int explicit_press,uint32_t now);
int runtime45_snapshot(RP45Runtime*,const RP45Context*,unsigned slot,char out[RP44_WIRE],uint32_t now);
int runtime45_receive(RP45Runtime*,const RP45Context*,uint64_t sender,const char*,size_t,uint32_t now);
int runtime45_press(RP45Runtime*,const RP45Context*,unsigned op,unsigned target,int explicit_press,char out[RP_WIRE],uint32_t now);
unsigned runtime45_suggest(const RP45Runtime*,int at_station,int nearest,int distance_cm);
#endif
