#ifndef STATE44_H
#define STATE44_H
#include "rp43.h"
/* Host-sourced, addressed snapshots. Not a cryptographic protocol. The caller
 * must independently verify engine room, host and identities. All effects are
 * local UI suggestions; no automatic character control. */
#define RP44_WIRE 89
#define RP44_TTL 6000u
typedef struct {uint32_t epoch,revision,generation,ack,case_id,attempt,reward,partner_gen,partner_case;uint8_t slot,partner,flags,state;} RP44State;
typedef struct {uint64_t host,local;uint32_t epoch,generation,last_rx,next_seq;uint8_t slot,active,consented;uint32_t consent_attempt;RP44State state;} RP44Client;
enum {S44_OFFICER=1,S44_DUTY=2,S44_WANTED=4};
int state44_encode(const RP44State*,char out[RP44_WIRE]);
int state44_decode(const char*,size_t,RP44State*);
int state44_snapshot(const RPRoom*,unsigned slot,uint32_t revision,RP44State*);
int state44_bind(RP44Client*,uint64_t host,uint64_t local,uint32_t epoch,unsigned slot,uint32_t generation,int private_room,int opt_in);
int state44_apply(RP44Client*,uint64_t observed_host,uint64_t sender,const char*,size_t,uint32_t now,int private_room,int opt_in);
int state44_live(RP44Client*,uint64_t observed_host,uint32_t now,int private_room,int opt_in);
int state44_action(RP44Client*,unsigned op,unsigned target,uint32_t target_gen,uint32_t case_id,uint32_t now,int explicit_press,RPMessage*);
#endif
