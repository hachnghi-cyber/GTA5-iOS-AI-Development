#!/usr/bin/env python3
"""Exact-R42 loader-only staging. No branch writes, no runtime patching.
Optional stage requires a real, separately built iPhoneOS dylib. Output must be re-signed.
"""
import argparse, hashlib, json, struct, zipfile
from pathlib import Path
from plan52 import inspect, IPA_HASH, EXE_HASH
PATH='@executable_path/Frameworks/libRP53.dylib'
ENTRY='Payload/GTAV.app/GTA5'
LIB='Payload/GTAV.app/Frameworks/libRP53.dylib'
EXPORT='_rp53_get_api'
SYSTEM='/usr/lib/libSystem.B.dylib'
LOADS={0xc,0x80000018,0x8000001f,0x80000023,0x20}
SHA=lambda b:hashlib.sha256(b).hexdigest()
def require(v,msg):
    if not v: raise ValueError(msg)
def commands(b,ft):
    require(len(b)>=32,'short header')
    m,c,sub,t,n,size,flags,_=struct.unpack_from('<8I',b)
    require((m,c,sub,t)==(0xfeedfacf,0x100000c,0,ft),'not ARM64 Mach-O expected filetype')
    require(32+size<=len(b) and n<=size//8,'bad command count/size')
    p=32; out=[]
    for _ in range(n):
        require(p+8<=32+size,'short command')
        k,s=struct.unpack_from('<II',b,p)
        require(s>=8 and s%8==0 and p+s<=32+size,'bad command bounds')
        out.append((k,p,b[p:p+s]));p+=s
    require(p==32+size,'command size mismatch')
    return out,p

def cstr(b,o):
    require(0<=o<len(b),'string offset');end=b.find(b'\0',o);require(end>=o,'unterminated string');return b[o:end].decode('ascii')
def dylib_name(cmd):
    require(len(cmd)>=24,'short dylib command');o=struct.unpack_from('<I',cmd,8)[0];require(o>=24,'bad name offset');return cstr(cmd,o)
def load_cmd(path):
    s=path.encode('ascii')+b'\0';size=(24+len(s)+7)&~7
    return struct.pack('<6I',0xc,size,24,2,0,0)+s.ljust(size-24,b'\0')
def find_cmd(cs,k):
    hits=[c for t,_,c in cs if t==k];require(len(hits)==1,f'expected exactly one command {k:#x}');return hits[0]
def linkedit_blob(b,c,o=8):
    require(len(c)>=o+8,'short linkedit command');p,n=struct.unpack_from('<II',c,o);require(n>0 and p+n<=len(b),'bad linkedit bounds');return b[p:p+n]
def uleb(b,p):
    v=0
    for i in range(10):
        require(p<len(b),'short ULEB');x=b[p];p+=1;require(i<9 or x<=1,'ULEB overflow');v|=(x&127)<<(7*i)
        if not x&128:return v,p
    raise ValueError('unterminated ULEB')
def export_address(trie,name):
    p=0;rest=name.encode('ascii');visited=set()
    while True:
        require(p not in visited and p<len(trie),'bad export trie');visited.add(p)
        n,p=uleb(trie,p);end=p+n;require(end<len(trie),'bad export terminal')
        if not rest:
            require(n>0,'missing export');flags,p=uleb(trie,p);addr,p=uleb(trie,p)
            require(flags==0 and p==end and addr>0,'not ordinary defined export');return addr
        p=end;count=trie[p];p+=1;matches=[]
        for _ in range(count):
            e=trie.find(b'\0',p);require(e>p,'bad export edge');edge=trie[p:e];child,p=uleb(trie,e+1)
            require(child<len(trie),'export child outside trie')
            if rest.startswith(edge):matches.append((edge,child))
        require(len(matches)==1,'missing/ambiguous export');edge,p=matches[0];rest=rest[len(edge):]

def validate_dylib(b):
    cs,_=commands(b,6)
    require(dylib_name(find_cmd(cs,0xd))==PATH,'wrong install ID')
    bv=find_cmd(cs,0x32);require(len(bv)>=24,'short build version');platform,minos,sdk,ntools=struct.unpack_from('<4I',bv,8)
    require(platform==2 and 0<minos<=0xf0000 and sdk>=minos and len(bv)==24+ntools*8,'requires iPhoneOS device and minOS <= 15.0')
    deps=[dylib_name(c) for k,_,c in cs if k in LOADS];require(deps==[SYSTEM],'unexpected dependencies')
    segs=[]
    for k,_,c in cs:
        if k!=0x19:continue
        require(len(c)>=72,'short segment');name,va,vs,fo,fs,mp,ip,ns,fl=struct.unpack_from('<16sQQQQiiII',c,8)
        require(len(c)==72+80*ns and fs<=vs and fo+fs<=len(b) and not(mp&2 and mp&4) and not(ip&2 and ip&4),'invalid segment / W+X')
        segs.append((name.rstrip(b'\0'),va,vs,fo,fs,ip))
        for i in range(ns):
            sf=struct.unpack_from('<I',c,72+80*i+64)[0]
            require(sf&255 not in (9,10,0x16),'constructor/terminator/init offsets not allowed')
    require(len(segs)>0,'missing segments');texts=[s for s in segs if s[0]==b'__TEXT' and s[3]==0 and s[5]&4]
    require(len(texts)==1,'missing text base')
    tries=[c for k,_,c in cs if k==0x80000033]
    if tries: require(len(tries)==1,'duplicate export trie');trie=linkedit_blob(b,tries[0])
    else: trie=linkedit_blob(b,find_cmd(cs,0x80000022),40)
    addr=texts[0][1]+export_address(trie,EXPORT)
    require(any(s[5]&4 and s[1]<=addr< s[1]+s[4] for s in segs),'export is not executable/file-backed')
    return dict(sha256=SHA(b),install_id=PATH,platform='iPhoneOS',minos=hex(minos),dependencies=deps,export=EXPORT,export_va=hex(addr))

def baseline(p):
    inspect(p)
    with zipfile.ZipFile(p) as z: b=z.read(ENTRY);require(LIB not in z.namelist(),'library exists')
    require(SHA(b)==EXE_HASH,'wrong exe');return b

def loader_plan(b):
    require(SHA(b)==EXE_HASH,'wrong exact R42 executable')
    cs,end=commands(b,2);require(end==0x10b0,'unexpected header end')
    require(not any(b[end:0x1100]) and b[0x1100]!=0,'header slot mismatch')
    command=load_cmd(PATH);require(end+len(command)<=0x1100,'load command exceeds reserved interval')
    original_deps=[dylib_name(c) for k,_,c in cs if k in LOADS]
    require(PATH not in original_deps,'already loaded')
    # Check existing dlsym stub and its chained import (DYLD_CHAINED_PTR_64).
    require(b[0x23bd278:0x23bd284].hex()=='b0290090101e47f900021fd6','dlsym stub mismatch')
    fx=linkedit_blob(b,find_cmd(cs,0x80000034));version,starts,imports,symbols,count,fmt,symfmt=struct.unpack_from('<7I',fx)
    require((version,fmt,symfmt)==(0,1,0) and imports+4*count<=symbols<len(fx),'unexpected chained import layout')
    # Prove the pointer is reachable in the existing __DATA_CONST page chain,
    # rather than merely finding bytes that look like a bind record.
    require(starts+24<=len(fx) and struct.unpack_from('<I',fx,starts)[0]==5,'bad chain segment count')
    st=starts+struct.unpack_from('<I',fx,starts+4+2*4)[0]
    require(st+22<=len(fx),'bad chain segment info')
    size,page,fmt,seg_off,maxptr,pages=struct.unpack_from('<IHHQIH',fx,st)
    require(page==0x4000 and fmt==6 and seg_off==0x2760000 and st+size<=len(fx) and 22+2*pages<=size,'unexpected chain page layout')
    got=0x28f1e38;pg,within=divmod(got-seg_off,page)
    require(0<=pg<pages,'GOT page missing');start=struct.unpack_from('<H',fx,st+22+pg*2)[0]
    require(start<page,'unsupported multi-start/empty page');off=seg_off+pg*page+start;end_page=seg_off+(pg+1)*page;hops=0
    while off!=got:
        require(off+8<=end_page and off<got,'GOT is not a chained bind')
        q=struct.unpack_from('<Q',b,off)[0];step=((q>>51)&0xfff)*4;require(step>0,'chain ended before GOT');off+=step;hops+=1
    require(off+8<=end_page,'GOT outside page')
    ptr=struct.unpack_from('<Q',b,got)[0];idx=ptr&0xffffff
    require(ptr>>63==1 and idx<count,'not chained bind');imp=struct.unpack_from('<I',fx,imports+idx*4)[0];ordinal=imp&255
    require(0<ordinal<=len(original_deps) and cstr(fx,symbols+(imp>>9))=='_dlsym' and original_deps[ordinal-1]==SYSTEM,'unexpected dlsym import')
    out=bytearray(b);struct.pack_into('<II',out,16,len(cs)+1,end-32+len(command));out[end:end+len(command)]=command;out=bytes(out)
    newcs,newend=commands(out,2);require(newcs[:-1]==cs and newcs[-1][0]==0xc and dylib_name(newcs[-1][2])==PATH,'old commands changed')
    require(out[:16]==b[:16] and out[24:end]==b[24:end] and out[newend:]==b[newend:] and len(out)==len(b),'non-loader bytes changed')
    report=dict(status='LOADER_ONLY_STATIC_VERIFIED_NO_HOOK',input_sha256=SHA(b),candidate_sha256=SHA(out),new_load_command_range=[hex(end),hex(newend)],remaining_header_bytes=0x1100-newend,original_dependencies=len(original_deps),new_dependency_ordinal=len(original_deps)+1,dlsym_import_ordinal=ordinal,dlsym_import_index=idx,dlsym_chain_hops=hops,dlsym_stub_va=hex(0x1023bd278),chained_fixups_sha256=SHA(fx),original_fixups_unchanged=True,signature='requires re-signing',installed=False)
    return out,report

def stage(p,dylib,dst):
    require(p.resolve()!=dst.resolve() and not dst.exists(),'output must be new file');lib=dylib.read_bytes();info=validate_dylib(lib);b=baseline(p);out,r=loader_plan(b)
    tmp=dst.with_suffix(dst.suffix+'.tmp');require(not tmp.exists(),'temporary output exists')
    try:
        with zipfile.ZipFile(p) as z,zipfile.ZipFile(tmp,'x') as q:
            for i in z.infolist():q.writestr(i,out if i.filename==ENTRY else z.read(i.filename))
            q.writestr(LIB,lib,compress_type=zipfile.ZIP_DEFLATED);q.comment=z.comment
        with zipfile.ZipFile(p) as z,zipfile.ZipFile(tmp) as q:
            require(q.namelist()==z.namelist()+[LIB] and q.testzip() is None,'bad ZIP')
            require(q.read(ENTRY)==out and q.read(LIB)==lib,'new content mismatch')
            require(all(SHA(z.read(i))==SHA(q.read(i)) for i in z.namelist() if i!=ENTRY),'unrelated entry changed')
        tmp.rename(dst)
    finally:
        if tmp.exists():tmp.unlink()
    return dict(r,dylib=info,output=str(dst),status='UNSIGNED_LOADER_ONLY_NO_GAMEPLAY')
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('ipa',type=Path);p.add_argument('--stage',nargs=2,type=Path,metavar=('DYLIB','OUTPUT_IPA'));a=p.parse_args();print(json.dumps(stage(a.ipa,*a.stage) if a.stage else loader_plan(baseline(a.ipa))[1],indent=2))
