#ifndef BRIDGE49_H
#define BRIDGE49_H
#include "game48.h"
#define RP49_INTERVAL 250u
#define RP49_VIEW_TTL 3000u
/* Single verified game thread. The UI must confirm that the exact action was
 * actually rendered; no implicit consent, no state-changing auto press. */
typedef struct {void*arg;int(*collect)(void*,const RP46Roster*,RP48Frame*);int(*frame)(void*,RP47*,const RP48Frame*,uint32_t);int(*show)(void*,const RP47View*,uint32_t);void(*clear)(void*);} RP49Ops;
typedef struct {RP47 rp;RP46Roster roster;RP47View shown;uint32_t next_tick,shown_at,serial,token,last_now;uint8_t armed,busy;} RP49;
int rp49_arm(RP49*,const RP49Ops*,const RP46Roster*,int explicit_consent,uint32_t);
int rp49_tick(RP49*,const RP49Ops*,int consent_still_valid,uint32_t);
int rp49_confirm(RP49*,const RP49Ops*,uint32_t displayed_token,int explicit_press,uint32_t);
int rp49_rx(RP49*,const RP49Ops*,uint64_t authenticated_sender,const char*,size_t,uint32_t);
void rp49_stop(RP49*,const RP49Ops*);
#endif
