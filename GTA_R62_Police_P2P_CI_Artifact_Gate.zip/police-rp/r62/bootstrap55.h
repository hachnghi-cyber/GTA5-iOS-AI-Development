#ifndef BOOTSTRAP55_H
#define BOOTSTRAP55_H
#include "api53.h"
/* Process-lifetime config. Only the separately verified tick-hook owner may
 * call bootstrap; these flags are installer preconditions, not evidence.
 * clock must return monotonic milliseconds (non-reentrant), and UI callbacks
 * and their context must live as long as the published API. No automatic arm. */
typedef struct {
 uintptr_t base;
 int exact_build,verified_tick_site;
 void *ui;
 int (*show)(void*,const RP47View*,uint32_t);
 void (*clear)(void*);
 void *clock_arg;
 int (*clock_ms)(void*,uint64_t*);
} RP55Config;
enum { RP55_COLD, RP55_INITIALIZING, RP55_READY, RP55_DISABLED };
int rp55_bootstrap(const RP55Config*);
unsigned rp55_status(void);
int rp55_arm(const RP46Roster*,int explicit_consent);
int rp55_tick(int consent_still_valid);
int rp55_confirm(uint32_t displayed_token,int explicit_press,int consent_still_valid);
int rp55_stop(void);
#endif
