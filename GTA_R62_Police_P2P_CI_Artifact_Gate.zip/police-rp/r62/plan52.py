#!/usr/bin/env python3
"""Read-only R42 hook planner. No binary writes, no runtime memory permission changes."""
import hashlib, json, struct, sys, zipfile
from pathlib import Path
BASE=0x100000000
IPA_HASH='ca4f80bbcf8227932ba80a26fda9e1ba99cd46069709a1da402d8c1b79ca9ff6'
EXE_HASH='13f9ec3ff9466914016f570c28fe109648d8e48ab27a0310a673f7cd8dd56689'
SITES=[('receive',0x1a009e4,0x1a01ab8,True,'rp52_receive_entry'),('decode',0x1a01b10,0x1a01c14,True,'rp52_decode_entry'),('dispatch',0x1a01bdc,0x1a01d0c,True,'rp52_dispatch_entry'),('post',0x1732584,0x2e40,False,'post_island52')]
def branch(src,dst,link=False):
    if any(not isinstance(x,int) or x<0 or x>=2**64 or x%4 for x in (src,dst)): raise ValueError('unaligned or invalid VA')
    d=dst-src
    if not -2**27<=d<2**27: raise ValueError('branch range')
    return (0x94000000 if link else 0x14000000)|((d//4)&0x3ffffff)
def target(src,w):
    if w>>26 not in (5,37): raise ValueError('not B/BL')
    d=w&0x3ffffff
    return src+4*(d-2**26 if d&2**25 else d)
def island(va,shim,old):
    # Preserve LR across BL; shim preserves x0..17, full SIMD and flags.
    # SP always aligned. All branch targets must be within direct B/BL range.
    return struct.pack('<6I',0xd10043ff,0xf90007fe,branch(va+8,shim,True),0xf94007fe,0x910043ff,branch(va+20,old))
def inspect(p):
    with p.open('rb') as f:
        if hashlib.file_digest(f,'sha256').hexdigest()!=IPA_HASH: raise ValueError('wrong IPA SHA256')
    with zipfile.ZipFile(p) as z:
        if len(z.infolist())!=61: raise ValueError('wrong ZIP entry count')
        b=z.read('Payload/GTAV.app/GTA5')
    if hashlib.sha256(b).hexdigest()!=EXE_HASH: raise ValueError('wrong executable SHA256')
    magic,cpu,sub,ft,ncmd,sz,flags,res=struct.unpack_from('<8I',b)
    if magic!=0xfeedfacf or cpu!=0x100000c or ft!=2: raise ValueError('unexpected Mach-O')
    segments=[]; sections=[]; pos=32
    for _ in range(ncmd):
        cmd,size=struct.unpack_from('<II',b,pos)
        if size<8 or pos+size>32+sz: raise ValueError('invalid load command')
        if cmd==0x19:
            name,va,vs,fo,fs,mp,ip,ns,fl=struct.unpack_from('<16sQQQQiiII',b,pos+8)
            name=name.split(b'\0')[0].decode();segments.append((name,va,vs,fo,fs,ip))
            if 72+80*ns>size: raise ValueError('invalid sections')
            for j in range(ns):
                sn,sg,a,n,o,_,_,_,sf,*_=struct.unpack_from('<16s16sQQIIIIIIII',b,pos+72+j*80)
                sections.append((sn.split(b'\0')[0].decode(),a,n,o,sf))
        pos+=size
    def word(va):
        for _,a,_,off,n,prot in segments:
            if prot&4 and a<=va and va+4<=a+n:return struct.unpack_from('<I',b,off+va-a)[0]
        raise ValueError('not executable mapped bytes')
    result=[]
    for label,o,t,link,symbol in SITES:
        va=BASE+o;expected=branch(va,BASE+t,link)
        if word(va)!=expected: raise ValueError('branch mismatch '+label)
        result.append(dict(site=label,va=hex(va),old_word=hex(expected),old_target=hex(BASE+t),new_symbol=symbol,kind='BL' if link else 'B',new_word=None))
    for o,t,l in [(0x173257c,0x1734438,True),(0x2e74,0x1732588,False),(0x2040,0x3000,False),(0x3208,0x3e70,False)]:
        # Tick and Custom branches may be BL/B; verify destination and retain exact word.
        w=word(BASE+o)
        if target(BASE+o,w)!=BASE+t:raise ValueError('existing branch mismatch')
        if o in (0x173257c,0x2e74) and w!=branch(BASE+o,BASE+t,l):raise ValueError('permission/resume mismatch')
    if word(BASE+0x1732580)!=0x34000140 or word(BASE+0x2e70)!=0x910182c0:raise ValueError('permission/resume instruction mismatch')
    return dict(status='BLOCKED_NO_PROVEN_PLACEMENT_OR_LOADER',ipa_sha256=IPA_HASH,executable_sha256=EXE_HASH,sites=result,executable_segments=[dict(name=n,va=hex(a),fileoff=hex(o),filesize=hex(f)) for n,a,_,o,f,p in segments if p&4],text_section=[dict(va=hex(a),size=hex(n)) for s,a,n,o,f in sections if s=='__text'],installed=False,reason='No approved mapped island, cross-image dyld binding, or code-signing integration. Existing tick/Custom and permission/resume retained. No guessed cave.')
if __name__=='__main__': print(json.dumps(inspect(Path(sys.argv[1])),indent=2))
