#ifndef THREAD50_H
#define THREAD50_H
#include "native49.h"
#include <stdatomic.h>
/* Initialized once by the verified tick owner before publication; lifetime
 * must extend past all callbacks. Never copy or reinitialize a published gate. */
#if defined(RP50_FREESTANDING_IOS)
typedef struct _opaque_pthread_t *rp50_thread_t;
#else
#include <pthread.h>
typedef pthread_t rp50_thread_t;
#endif
typedef struct {
    rp50_thread_t owner;
    RP49Native native;
    RP49 bridge;
    _Atomic unsigned rejected_thread, rejected_span, rx_calls;
} RP50;
int rp50_init(RP50*, uintptr_t, int exact_build, int verified_tick_site, void*,int(*)(void*,const RP47View*,uint32_t),void(*)(void*));
int rp50_on_owner(RP50*);
int rp50_arm(RP50*,const RP46Roster*,int,uint32_t);
int rp50_tick(RP50*,int,uint32_t);
int rp50_confirm(RP50*,uint32_t,int,uint32_t);
int rp50_stop(RP50*);
/* readable is a PROVEN readable extent from the engine buffer owner, NOT a
 * guessed capacity or strlen on an unbounded pointer. Hook not installed. */
int rp50_copy_wire(const char*,size_t readable,char out[89],size_t*);
int rp50_rx(RP50*,int native_allowed,const void* sender,const char* text,size_t readable,uint32_t now);
#endif
