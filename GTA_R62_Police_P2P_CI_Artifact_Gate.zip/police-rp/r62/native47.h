#ifndef NATIVE47_H
#define NATIVE47_H
#include "integration47.h"
#include "native45.h"
/* All entry points are opt-in, called by a separately verified game-thread
 * integration. No constructor, no patch installation, no remote writes. */
int native47_frame(RP47*,const RP46Roster*,const RP47Observation*,size_t,uintptr_t image_base,int exact_build,int game_thread,uint32_t now);
int native47_rx(RP47*,const RP46Roster*,uintptr_t image_base,int exact_build,int game_thread,int native_allowed,const void*sender_handle,const char*text,size_t readable_len,uint32_t now);
#endif
