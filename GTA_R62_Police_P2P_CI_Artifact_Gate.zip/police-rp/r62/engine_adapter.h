#ifndef RP_ENGINE_ADAPTER_H
#define RP_ENGINE_ADAPTER_H
#include "rp43.h"
/* These functions must be provided by the engine integration, not packet data.
 * Only call on a verified game/network thread after native CanReceiveFrom. */
typedef struct {void *(*player_from_handle)(const void *);uint64_t (*handle_id)(const void *);uint64_t (*player_id)(const void *);unsigned (*player_slot)(const void *);} RPEngine;
int rp_ingest(RPRoom*,const RPEngine*,const void *sender_handle,const char *text,size_t len,uint32_t observed_epoch,uint64_t observed_local_host,int private_room,int opted_in,uint32_t now);
#endif
