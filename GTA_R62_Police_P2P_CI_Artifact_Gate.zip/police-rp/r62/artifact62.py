#!/usr/bin/env python3
"""Verify build metadata and binary; never claims runtime proof or cryptographic CI attestation."""
import argparse, hashlib, json, os, re, sys, subprocess
from pathlib import Path
from validate56 import validate
from loader53 import require, stage, baseline, loader_plan
HERE=Path(__file__).resolve().parent
NAME='libRP53.dylib'
FIELDS={'build-target.txt','dependencies.txt','exports.txt','lifecycle-validation.json','toolchain.txt','SHA256SUMS.txt',NAME}
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def inputs():
    names=set((HERE/'SOURCES_R61.txt').read_text().splitlines())|{p.name for p in HERE.glob('*.h')}|{'BUILD_MACOS_R61.sh','EXPORTS_R61.txt','SOURCES_R61.txt','loader53.py','plan52.py','validate56.py','artifact62.py'}
    return {n:digest(HERE/n) for n in sorted(names)}
def metadata(d):
    require(d.is_dir() and all((d/n).is_file() and not (d/n).is_symlink() for n in FIELDS),'missing or symlink artifact files')
    b=d/NAME; h=digest(b)
    require((d/'SHA256SUMS.txt').read_text().split()==[h,NAME],'SHA256SUMS mismatch')
    info=validate(b.read_bytes())
    require(json.loads((d/'lifecycle-validation.json').read_text())==info,'lifecycle metadata mismatch')
    expected=set((HERE/'EXPORTS_R61.txt').read_text().splitlines())
    actual={s.split()[-1] for s in (d/'exports.txt').read_text().splitlines() if len(s.split())>=3}
    require(expected==actual,'export set mismatch')
    require(re.search(r'(?im)^\s*platform\s+IOS\s*$',(d/'build-target.txt').read_text()) is not None,'vtool iOS platform not reported')
    require('Xcode ' in (d/'toolchain.txt').read_text() and 'Apple clang version' in (d/'toolchain.txt').read_text(),'Apple SDK build report absent')
    return {'artifact_sha256':h,'source_files':inputs(),'files':{n:digest(d/n) for n in sorted(FIELDS)},'static_validation':info,'runtime_verified':False}
def record(d):
    m=metadata(d); commit=os.environ.get('GITHUB_SHA',''); run=os.environ.get('GITHUB_RUN_ID',''); repo=os.environ.get('GITHUB_REPOSITORY','')
    require(re.fullmatch('[0-9a-f]{40}',commit) and run.isdigit() and re.fullmatch(r'[\w.-]+/[\w.-]+',repo),'CI environment missing')
    require(subprocess.check_output(['git','rev-parse','HEAD'],cwd=HERE,text=True).strip()==commit,'checkout SHA mismatch')
    m.update(commit=commit,run_id=run,repository=repo)
    p=d/'BUILD_R62.json'; require(not p.exists(),'stale build manifest'); p.write_text(json.dumps(m,indent=2)+'\n'); return m
def verify(d,commit,run,repo):
    require(re.fullmatch('[0-9a-f]{40}',commit) and run.isdigit() and re.fullmatch(r'[\w.-]+/[\w.-]+',repo),'invalid expected run identity')
    p=d/'BUILD_R62.json'; require(p.is_file() and not p.is_symlink(),'missing CI manifest'); m=json.loads(p.read_text())
    expected=metadata(d); expected.update(commit=commit,run_id=run,repository=repo)
    require(m==expected,'source, run identity or artifact manifest mismatch'); return m
if __name__=='__main__':
    p=argparse.ArgumentParser(); sub=p.add_subparsers(dest='cmd',required=True)
    a=sub.add_parser('record'); a.add_argument('directory',type=Path)
    for name in ('verify','stage-loader-only'):
        a=sub.add_parser(name); a.add_argument('directory',type=Path); a.add_argument('--commit',required=True); a.add_argument('--run',required=True); a.add_argument('--repo',required=True)
        if name=='stage-loader-only': a.add_argument('ipa',type=Path); a.add_argument('output',type=Path)
    a=p.parse_args()
    if a.cmd=='record': result=record(a.directory)
    else:
        result=verify(a.directory,a.commit,a.run,a.repo)
        if a.cmd=='stage-loader-only': result={'verified_metadata':result,'stage':stage(a.ipa,a.directory/NAME,a.output),'warning':'unsigned; loader-only; no RP hooks or gameplay enabled'}
    print(json.dumps(result,indent=2))
