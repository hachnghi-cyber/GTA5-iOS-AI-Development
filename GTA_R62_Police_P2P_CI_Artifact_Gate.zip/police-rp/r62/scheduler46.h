#ifndef SCHEDULER46_H
#define SCHEDULER46_H
#include "runtime45.h"
#include "transport44.h"
/* Pilot: 2–4 explicitly opted-in members, immutable roster per fresh epoch.
 * Trusted engine adapter supplies roster, actual sender identity and positions.
 * No direct engine writes or automatic acceptance. Single game thread only. */
#define RP46_MAX 4
#define RP46_TX_INTERVAL 500u
#define RP46_RETRY 1000u
#define RP46_TIMEOUT 4500u
typedef struct {uint64_t id; uint8_t slot,opted;} RP46Member;
typedef struct {RP45Context ctx; uint8_t count; RP46Member members[RP46_MAX];} RP46Roster;
typedef int (*RP46Send)(void*,const char*,size_t); /* TX44_*; queued != received */
typedef struct {RP45Runtime rt;RP46Roster roster;uint32_t started,last_now,next_tx,retry_at,expires,pending_seq;uint8_t cursor,pending,failed;char request[RP_WIRE];} RP46;
int rp46_begin(RP46*,const RP46Roster*,uint32_t now);
int rp46_live(RP46*,const RP46Roster*,uint32_t now);
int rp46_observe(RP46*,const RP46Roster*,unsigned slot,uint64_t id,const int32_t xyz[3],int alive,uint32_t now);
int rp46_admin(RP46*,const RP46Roster*,unsigned op,unsigned target,int explicit_press,uint32_t now);
int rp46_receive(RP46*,const RP46Roster*,uint64_t authenticated_sender,const char*,size_t,uint32_t now);
int rp46_press(RP46*,const RP46Roster*,unsigned op,unsigned target,int explicit_press,uint32_t now);
int rp46_tick(RP46*,const RP46Roster*,RP46Send,void*,uint32_t now);
int rp46_tick_chat(RP46*,const RP46Roster*,const RP44Transport*,void *network_chat,void *text_chat,const void *local_info,uint32_t now);
void rp46_stop(RP46*);
#endif
