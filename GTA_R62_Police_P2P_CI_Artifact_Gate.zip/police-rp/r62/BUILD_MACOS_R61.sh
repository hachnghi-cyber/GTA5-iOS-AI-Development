#!/bin/sh
set -eu
cd "$(dirname "$0")"
[ ! -e dist-r61 ] || { echo 'Refusing stale dist-r61; use a fresh checkout or move it away.' >&2; exit 2; }
SDK=$(xcrun --sdk iphoneos --show-sdk-path)
[ -d "$SDK" ]
TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT
mkdir "$TMP/output"
# Explicit allowlist; obsolete post52.S is not referenced by the public API.
while IFS= read -r src; do
    xcrun --sdk iphoneos clang -isysroot "$SDK" -arch arm64 -miphoneos-version-min=15.0 -std=c11 -O2 -Wall -Wextra -Werror -c "$src" -o "$TMP/${src%.c}.o"
done < SOURCES_R61.txt
xcrun --sdk iphoneos clang -isysroot "$SDK" -arch arm64 -miphoneos-version-min=15.0 -dynamiclib \
    -Wl,-install_name,@executable_path/Frameworks/libRP53.dylib \
    -Wl,-undefined,error -Wl,-dead_strip -Wl,-exported_symbols_list,EXPORTS_R61.txt \
    "$TMP"/*.o -o "$TMP/output/libRP53.dylib"
xcrun lipo "$TMP/output/libRP53.dylib" -verify_arch arm64
xcrun vtool -show-build "$TMP/output/libRP53.dylib" > "$TMP/output/build-target.txt"
xcrun otool -L "$TMP/output/libRP53.dylib" > "$TMP/output/dependencies.txt"
xcrun nm -gU "$TMP/output/libRP53.dylib" > "$TMP/output/exports.txt"
python3 validate56.py "$TMP/output/libRP53.dylib" > "$TMP/output/lifecycle-validation.json"
python3 - "$TMP/output/exports.txt" <<'PY'
import sys
from pathlib import Path
actual={line.split()[-1] for line in Path(sys.argv[1]).read_text().splitlines() if len(line.split())>=3}
expected=set(Path('EXPORTS_R61.txt').read_text().splitlines())
if actual!=expected:raise SystemExit('unexpected export set: '+str(sorted(actual^expected)))
PY
xcodebuild -version > "$TMP/output/toolchain.txt"
xcrun --sdk iphoneos clang --version >> "$TMP/output/toolchain.txt"
xcrun --sdk iphoneos --show-sdk-version >> "$TMP/output/toolchain.txt"
(cd "$TMP/output" && shasum -a 256 libRP53.dylib > SHA256SUMS.txt)
mv "$TMP/output" dist-r61
