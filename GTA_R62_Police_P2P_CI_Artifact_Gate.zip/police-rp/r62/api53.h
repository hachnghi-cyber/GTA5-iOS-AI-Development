#ifndef API53_H
#define API53_H
#include "entry52.h"
#include <stddef.h>
#define RP53_ABI_MAGIC 0x52503533u
#define RP53_ABI_VERSION 1u
/* Public ABI is read-only for life of the image; getter returns NULL until
 * the verified owner publishes a complete native binding. Caller must run
 * original engine target if lookup/getter/ABI validation fails. */
typedef struct {
 uint32_t magic,version,size,reserved;
 void (*receive)(void*,const void*);
 int (*decode)(void*,const void*,unsigned,void*);
 void (*dispatch)(void*,void*,const void*,const char*,unsigned);
 void (*post)(const void*,const char*);
} RP53API;
int rp53_publish(RP51Native*);
const RP53API*rp53_get_api(void);
int rp53_api_valid(const RP53API*);
#endif
