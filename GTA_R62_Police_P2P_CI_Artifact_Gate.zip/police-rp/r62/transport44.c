#include "transport44.h"
int transport44_send(const RP44Transport*t,void*n,void*x,const void*g,const char*w,size_t len,int priv,int opt,int host,int allowed){if(!t||!n||!x||!g||!w||!priv||!opt||!allowed||!t->initialized||!t->typing||!t->pending||!t->local||!t->local_index||!t->gamer_id||!t->privileges||!t->have_typer||!t->submit)return TX44_DENIED;
 RPMessage m;RP44State s;if(len==56){if(!rp_decode(w,len,&m))return TX44_DENIED;}else if(len==88){if(!host||!state44_decode(w,len,&s))return TX44_DENIED;}else if(len==20){if(host||w[0]!='R'||w[1]!='P'||w[2]!='4'||w[3]!='7')return TX44_DENIED;unsigned a=0,b=0;for(unsigned i=4;i<20;i++){unsigned c=(unsigned char)w[i];if(c>='0'&&c<='9')c-='0';else if(c>='A'&&c<='F')c=c-'A'+10;else return TX44_DENIED;if(i<12)a=(a<<4)|c;else b=(b<<4)|c;}if(!a||!b)return TX44_DENIED;}else return TX44_DENIED;
 if(!t->initialized(x)||!t->local(g))return TX44_NOT_READY;
 int idx=t->local_index(g);const void*id=t->gamer_id(g);if(idx<0||!id||!t->privileges(x,idx)||!t->have_typer(x,id))return TX44_NOT_READY;
 if(t->typing()||t->pending(x))return TX44_BUSY;
 char text[RP44_WIRE];for(size_t i=0;i<len;i++)text[i]=w[i];text[len]=0;
 return t->submit(n,g,text,0)?TX44_QUEUED:TX44_REJECTED;
}
