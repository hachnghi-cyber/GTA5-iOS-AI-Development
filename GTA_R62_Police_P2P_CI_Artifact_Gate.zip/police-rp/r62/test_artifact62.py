"""Synthetic metadata tests. The fixture is NOT an iOS SDK binary."""
import tempfile,sys,json,hashlib
from pathlib import Path
from artifact62 import metadata,verify,NAME
from test_validate56 import fixture
from validate56 import validate,EXPORTS
sha='a'*40; rid='123'; repo='owner/repo'
def write(d):
 b=fixture(); (d/NAME).write_bytes(b); h=hashlib.sha256(b).hexdigest()
 (d/'SHA256SUMS.txt').write_text(h+'  '+NAME+'\n'); (d/'lifecycle-validation.json').write_text(json.dumps(validate(b)))
 (d/'exports.txt').write_text(''.join('00000000 T '+x+'\n' for x in EXPORTS)); (d/'build-target.txt').write_text('platform IOS\n')
 (d/'dependencies.txt').write_text('/usr/lib/libSystem.B.dylib\n'); (d/'toolchain.txt').write_text('Xcode 16.4\nApple clang version 17.0.0\n')
 m=metadata(d); m.update(commit=sha,run_id=rid,repository=repo); (d/'BUILD_R62.json').write_text(json.dumps(m))
def reject(f):
 try:f()
 except (ValueError,FileNotFoundError):return
 raise AssertionError('unexpected accept')
with tempfile.TemporaryDirectory() as tmp:
 d=Path(tmp);write(d);assert verify(d,sha,rid,repo)['runtime_verified'] is False
 reject(lambda:verify(d,'b'*40,rid,repo)); reject(lambda:verify(d,sha,'456',repo)); reject(lambda:verify(d,sha,rid,'other/repo'))
 for name in (NAME,'SHA256SUMS.txt','exports.txt','toolchain.txt','build-target.txt','dependencies.txt','lifecycle-validation.json','BUILD_R62.json'):
  write(d); p=d/name; p.write_bytes(p.read_bytes()+b'X');reject(lambda:verify(d,sha,rid,repo))
 write(d);(d/'exports.txt').unlink();reject(lambda:verify(d,sha,rid,repo))
 print('PASS 13 synthetic artifact gate cases (one acceptance, 12 rejection); not a real SDK build')
