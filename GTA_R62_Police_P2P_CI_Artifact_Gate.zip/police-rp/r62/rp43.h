#ifndef RP43_H
#define RP43_H
#include <stdint.h>
#include <stddef.h>
#define RP_MAX 32
#define RP_WIRE 57 /* 56 ASCII bytes + NUL */
#define RP_NONE 255u
#define RP_POS_TTL 4000u
#define RP_PEER_TTL 10000u
enum {RP_GRANT=1,RP_REVOKE,RP_VIOLATION,RP_DUTY,RP_OFF,RP_ARREST,RP_ACCEPT,RP_CANCEL,RP_DELIVER};
enum {RP_FREE,RP_PENDING,RP_ESCORT};
typedef struct {uint32_t epoch,seq,generation,case_id,sender_generation,attempt;uint8_t op,target;} RPMessage;
typedef struct {uint64_t id;uint32_t generation,seq,seen,pos_ms,deadline,case_id,rewards,attempt;int32_t xyz[3];uint8_t present,has_seq,has_pos,alive,officer,duty,wanted,state,partner,grace;} RPPeer;
typedef struct {uint32_t epoch,now,next_gen,next_case,next_attempt;uint64_t host;uint8_t closed;RPPeer peers[RP_MAX];} RPRoom;
int rp_encode(const RPMessage*,char out[RP_WIRE]);
int rp_decode(const char*,size_t,RPMessage*);
int rp_init(RPRoom*,uint32_t epoch,uint64_t host,uint32_t now);
int rp_tick(RPRoom*,uint32_t now);
int rp_join(RPRoom*,unsigned slot,uint64_t id,uint32_t now);
int rp_leave(RPRoom*,unsigned slot,uint64_t id,uint32_t now);
int rp_observe(RPRoom*,unsigned slot,uint64_t id,const int32_t xyz[3],int alive,uint32_t now);
int rp_receive(RPRoom*,uint64_t authenticated_id,const char *wire,size_t len,uint32_t now);
#endif
