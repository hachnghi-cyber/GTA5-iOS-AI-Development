#include "scope51.h"
#define TARGET(c,o,t) ((t)((c)->base+(uintptr_t)(o)))
static void receive(void*v,void*self,const void*event){RP51Native*c=v;TARGET(c,0x1a01ab8,void(*)(void*,const void*))(self,event);}
static int decode(void*v,void*out,const void*input,unsigned len,void*extra){RP51Native*c=v;return TARGET(c,0x1a01c14,int(*)(void*,const void*,unsigned,void*))(out,input,len,extra);}
static void dispatch(void*v,void*self,void*chat,const void*h,const char*text,unsigned flag){RP51Native*c=v;TARGET(c,0x1a01d0c,void(*)(void*,void*,const void*,const char*,unsigned))(self,chat,h,text,flag);}
static int deliver(void*v,const void*h,const char*s,size_t span,uint32_t now){RP51Native*c=v;return rp50_rx(c->gate,1,h,s,span,now);}
static int owner(void*v){return rp50_on_owner(((RP51Native*)v)->gate);}
static uint32_t now(void*v){RP51Native*c=v;return c->clock(c->clock_arg);}
int rp51_native_init(RP51Native*c,RP50*p,uint32_t(*clock)(void*),void*arg){
 if(!c||!p||!clock||!rp50_on_owner(p)||!p->native.base||!p->native.exact)return 0;
 c->gate=p;c->base=p->native.base;c->clock=clock;c->clock_arg=arg;
 RP51Ops o={c,receive,decode,dispatch,deliver,owner,now};return rp51_init(&c->binding,&o);
}
