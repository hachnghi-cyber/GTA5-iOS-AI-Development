#ifndef GAME48_H
#define GAME48_H
#include "native47.h"
/* Engine read interface. A slot returns 0 for absent, 1 for present, -1 for
 * indeterminate. No engine pointer is retained. Consent is never inferred
 * from membership. All calls must run on a verified game thread. */
typedef struct {void *arg;int (*identity)(void*,RP45Identity*);int (*slot)(void*,unsigned,uint64_t*);int (*position)(void*,unsigned,int32_t[3],int*);} RP48Read;
typedef struct {RP46Roster roster;RP47Observation obs[RP46_MAX];int nearest,dist,station;} RP48Frame;
int rp48_collect(const RP48Read*,const RP46Roster* agreed,RP48Frame*);
int rp48_native_collect(uintptr_t base,int exact,int thread,const RP46Roster*,RP48Frame*);
/* Calls from actual hook/UI are still required. No automatic start or accept. */
int rp48_native_start(RP47*,uintptr_t,int,int,const RP46Roster*,int explicit_start,uint32_t);
int rp48_native_tick(RP47*,uintptr_t,int,int,const RP46Roster*,RP47View*,uint32_t);
int rp48_native_press(RP47*,uintptr_t,int,int,const RP46Roster*,const RP47View*,int explicit_press,uint32_t);
#endif
