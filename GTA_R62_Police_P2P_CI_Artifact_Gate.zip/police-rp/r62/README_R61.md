# R61 — real SDK build preparation and object closure

Continues R60 (same R42 original IPA). Source-only; no new IPA, installed hook, device execution or successful iPhoneOS SDK link. For explicitly consenting private RP sessions only. All existing game behavior is unchanged.

## New actual work
- `SOURCES_R61.txt`: explicit list of all 18 C translation units needed by the R60 API and bootstrap. `post52.S` remains in history but is not linked by R61: the R60 island calls `rp52_post_entry` via the API table; the old `_rp52_post_preserve` entry has no C/assembly references in that path.
- `preflight61.py`: validates fresh ARM64 iPhoneOS object platform/minOS, symbol bounds, expected object set, duplicate definitions, internal symbol closure, seven required API definitions and permitted SDK-free external symbols. It does not prove Apple ABI or SDK linkage.
- `verify61.sh [R42.ipa]`: fresh iOS-target objects with Clang freestanding headers; strict host ELF shared link, ctypes load and cold state checks, negative object tests and eight inherited synthetic dylib metadata tests. The host library is a Linux test and is not shipped as an iOS artifact. R43–R60 logs remain inherited.
- `BUILD_MACOS_R61.sh`: actual Apple SDK compilation and strict link script with a clean output requirement, seven-symbol export allowlist, iPhoneOS platform/section/dependency gate, toolchain log and SHA-256. `build-rp-r61-native.yml`: manual GitHub Actions macos-15 workflow. No IPA or Apple credentials needed for the library build. No automatic game installation.

## Run on CI
Copy the 18 C sources listed in SOURCES_R61.txt, headers, BUILD_MACOS_R61.sh, SOURCES_R61.txt, EXPORTS_R61.txt, loader53.py, plan52.py and validate56.py into `police-rp/r61/`. Copy `build-rp-r61-native.yml` to `.github/workflows/build-rp-r61-native.yml`. Run the workflow manually and download the RP61-iphoneos-dylib artifact only after success. The separate CI-only ZIP has this layout ready for a repository checkout. Do not upload game binaries or device logs. No workflow has been committed, dispatched or completed in this turn.

Local environment: xcrun absent; ld64.lld 17 rejects platform iOS. No attempt to relabel a macOS/ELF binary as iOS. See actual TEST_R61.txt and PREFLIGHT_R61.json. The SDK must still successfully compile, link and validate the library before any integration attempt.

## Remaining blockers
- Verify actual SDK output and loader resolution on iOS.
- No installed or approved game-thread/bootstrap caller, UI consent or hook installation; R60 candidate section/unwind only. RX/TX delivery has not been tested with two iPhones. Old TX hook still has unverified unwind.
- Only after actual SDK build should a staged loader-only startup test be considered, before enabling native hooks. No existing IPA changes in this release.
