#include "bootstrap55.h"
/* Do not use constructors, runtime patching or a network thread to publish. */
static _Atomic unsigned state;
static RP50 gate;
static RP51Native native;
static RP55Config cfg;
static uint64_t origin,last;
static int fault;
unsigned rp55_status(void){return atomic_load_explicit(&state,memory_order_acquire);}
/* Same clock for frame, action and scoped RX. No wrap, no recovery from a
 * broken clock. UINT32_MAX intentionally fails the existing R49 time gate. */
static uint32_t clock32(void*unused){
 (void)unused;uint64_t n=0;
 if(fault||!cfg.clock_ms(cfg.clock_arg,&n)||n<last||n-origin>UINT32_MAX-15001u){fault=1;return UINT32_MAX;}
 last=n;return (uint32_t)(n-origin);
}
int rp55_bootstrap(const RP55Config*c){
 if(!c||!c->base||!c->exact_build||!c->verified_tick_site||!c->show||!c->clear||!c->clock_ms)return 0;
 unsigned expected=RP55_COLD;
 if(!atomic_compare_exchange_strong_explicit(&state,&expected,RP55_INITIALIZING,memory_order_acq_rel,memory_order_acquire))return 0;
 cfg=*c;
 if(!cfg.clock_ms(cfg.clock_arg,&origin))goto fail;
 last=origin;
 if(!rp50_init(&gate,cfg.base,cfg.exact_build,cfg.verified_tick_site,cfg.ui,cfg.show,cfg.clear)||
    !rp51_native_init(&native,&gate,clock32,0)||!rp53_publish(&native))goto fail;
 atomic_store_explicit(&state,RP55_READY,memory_order_release);return 1;
fail:
 atomic_store_explicit(&state,RP55_DISABLED,memory_order_release);return 0;
}
static int owner(void){return rp55_status()==RP55_READY&&rp50_on_owner(&gate);}
int rp55_arm(const RP46Roster*r,int yes){
 if(!owner()||!yes||!r||gate.bridge.armed||gate.bridge.busy||r->count<2||r->count>RP46_MAX||!r->ctx.private_room||!r->ctx.local_opted||!r->ctx.all_opted||!r->ctx.epoch)return 0;
 uint32_t now=clock32(0);if(fault)return 0;
 return rp50_arm(&gate,r,1,now);
}
int rp55_tick(int consent){
 if(!owner()||gate.bridge.busy)return 0;
 uint32_t now=clock32(0);if(fault||!consent){if(gate.bridge.armed)(void)rp50_stop(&gate);return 0;}
 if(!gate.bridge.armed)return 0;
 return rp50_tick(&gate,1,now);
}
int rp55_confirm(uint32_t token,int press,int consent){
 if(!owner()||gate.bridge.busy)return 0;
 uint32_t now=clock32(0);if(fault||!consent){if(gate.bridge.armed)(void)rp50_stop(&gate);return 0;}
 if(!gate.bridge.armed||!token||!press||token!=gate.bridge.token)return 0;
 return rp50_confirm(&gate,token,1,now);
}
int rp55_stop(void){if(!owner()||gate.bridge.busy)return 0;return !gate.bridge.armed||rp50_stop(&gate);}
