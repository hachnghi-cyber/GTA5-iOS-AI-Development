#ifndef ENTRY52_H
#define ENTRY52_H
#include "scope51.h"
/* Publish once before redirecting any callsite. Both objects must remain
 * alive for the process lifetime. No unpublish/reconfiguration. */
int rp52_publish(RP51Native *n);
void rp52_receive_entry(void *self,const void *event);
int rp52_decode_entry(void *out,const void *input,unsigned len,void *extra);
void rp52_dispatch_entry(void *self,void *chat,const void *h,const char *text,unsigned flag);
void rp52_post_entry(const void *h,const char *text);
#endif
