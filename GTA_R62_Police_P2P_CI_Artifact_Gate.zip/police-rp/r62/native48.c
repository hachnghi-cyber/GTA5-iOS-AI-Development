#include "game48.h"
#include "probe.h"
#define A(b,o,t) ((t)((b)+(uintptr_t)(o)))
typedef struct{uintptr_t b;int exact,thread;} Context;
static int identity(void*v,RP45Identity*i){Context*c=v;return native45_identity(c->b,c->exact,c->thread,i);}
static int slot(void*v,unsigned s,uint64_t*i){Context*c=v;return native45_slot_identity(c->b,c->exact,c->thread,s,i);}
static int cmd(Native f,uint64_t a,uint64_t b){uint64_t r=0,p[2]={a,b};NativeInfo n={&r,0,p};f(&n);return (int)r;}
static int position(void*v,unsigned s,int32_t p[3],int*alive){Context*c=v;uintptr_t b=c->b;if(!c->exact||!c->thread||s>=32)return 0;int ped=cmd(A(b,0xd83648,Native),s,0);if(!ped||!cmd(A(b,0xc63560,Native),ped,0))return 0;uint64_t r[3]={0},args[2]={(uint32_t)ped,0};NativeInfo n={r,0,args};A(b,0xc63d98,Native)(&n);for(int i=0;i<3;i++){union{uint32_t u;float f;} t={.u=(uint32_t)r[i]};if(!(t.f>=-20000.f&&t.f<=20000.f))return 0;p[i]=(int32_t)(t.f*100.f);}*alive=!cmd(A(b,0xc65b58,Native),ped,0);return cmd(A(b,0xd83648,Native),s,0)==ped&&cmd(A(b,0xc63560,Native),ped,0);}
int rp48_native_collect(uintptr_t b,int exact,int thread,const RP46Roster*r,RP48Frame*f){Context c={b,exact,thread};RP48Read e={&c,identity,slot,position};return rp48_collect(&e,r,f);}
int rp48_native_start(RP47*p,uintptr_t b,int exact,int thread,const RP46Roster*r,int press,uint32_t now){RP48Frame f;return p&&press&&rp48_native_collect(b,exact,thread,r,&f)&&rp47_start(p,&f.roster,now);}
int rp48_native_tick(RP47*p,uintptr_t b,int exact,int thread,const RP46Roster*r,RP47View*view,uint32_t now){if(!view||!p||!p->active)return 0;*view=(RP47View){0};RP48Frame f;if(!rp48_native_collect(b,exact,thread,r,&f)||!native47_frame(p,&f.roster,f.obs,f.roster.count,b,exact,thread,now)){rp47_stop(p);return 0;}return rp47_view(p,&f.roster,f.station!=0,f.nearest,f.dist,view,now);}
int rp48_native_press(RP47*p,uintptr_t b,int exact,int thread,const RP46Roster*r,const RP47View*shown,int press,uint32_t now){if(!p||!p->active||!shown||!press)return 0;RP48Frame f;if(!rp48_native_collect(b,exact,thread,r,&f)){rp47_stop(p);return 0;}/* Do not silently redirect a displayed arrest to a different person or accept it after leaving range. */if(shown->op==RP_ARREST&&(shown->target!=f.nearest||f.dist<0||f.dist>300))return 0;if((shown->op==RP_DUTY||shown->op==RP_OFF)&&!f.station)return 0;return rp47_press(p,&f.roster,shown,1,now);}
