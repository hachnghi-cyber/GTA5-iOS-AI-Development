#ifndef NATIVE45_H
#define NATIVE45_H
#include "runtime45.h"
/* Only main/game thread, exact build verified externally. image_base is the
 * loaded Mach-O header, not an unslid address. No pointer retained. */
typedef struct {uint64_t session,host,local;unsigned host_slot,local_slot;int is_host;} RP45Identity;
int native45_identity(uintptr_t image_base,int exact_build,int game_thread,RP45Identity*);
int native45_sender(uintptr_t image_base,int exact_build,int game_thread,const void*handle,unsigned*slot,uint64_t*id);
int native45_slot_identity(uintptr_t,int,int,unsigned,uint64_t*);
#endif
