#ifndef NATIVE49_H
#define NATIVE49_H
#include "bridge49.h"
/* Adapter must be initialized on verified game thread by the hook owner.
 * exact_build is not a runtime hash; caller must verify the executable. */
typedef struct {uintptr_t base;int exact,thread;void*ui;int(*show)(void*,const RP47View*,uint32_t);void(*clear)(void*);} RP49Native;
RP49Ops rp49_native_ops(RP49Native*);
int rp49_native_rx(RP49*,RP49Native*,int native_allowed,const void*sender_handle,const char*,size_t,uint32_t);
#endif
