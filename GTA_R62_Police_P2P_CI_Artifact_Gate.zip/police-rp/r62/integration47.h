#ifndef INTEGRATION47_H
#define INTEGRATION47_H
#include "scheduler46.h"
/* Engine-facing contract. All callbacks on the verified game thread. The
 * roster is an explicit, independently agreed private-session membership;
 * never derive consent or sender identity from chat text. No engine writes. */
#define RP47_HEARTBEAT_LEN 20u
#define RP47_LEASE 5500u
#define RP47_PULSE 1500u
#define RP47_NONE 0u
#define RP47_WAIT 101u
typedef struct {uint64_t id; int32_t xyz[3]; uint8_t slot,alive;} RP47Observation;
typedef struct {uint32_t epoch,revision,attempt,target_case,target_generation;uint64_t target_id;uint8_t op,target,flags,state;uint32_t reward;} RP47View;
typedef struct {RP46 scheduler;uint32_t seen[RP46_MAX],rx_seq[RP46_MAX],pulse_seq,next_pulse;uint8_t heard[RP46_MAX],active;RP47View displayed;uint8_t displayed_valid;uint64_t closed_session;uint32_t closed_epoch;} RP47;
int rp47_start(RP47*,const RP46Roster*,uint32_t now);
void rp47_stop(RP47*);
int rp47_frame(RP47*,const RP46Roster*,const RP47Observation*,size_t count,RP46Send,void*,uint32_t now);
int rp47_frame_chat(RP47*,const RP46Roster*,const RP47Observation*,size_t count,const RP44Transport*,void *network_chat,void *text_chat,const void *local_info,uint32_t now);
int rp47_receive(RP47*,const RP46Roster*,uint64_t authenticated_sender,const char*,size_t,uint32_t now);
int rp47_view(RP47*,const RP46Roster*,int at_station,int nearest,int dist_cm,RP47View*,uint32_t now);
int rp47_press(RP47*,const RP46Roster*,const RP47View* shown,int explicit_press,uint32_t now);
int rp47_admin(RP47*,const RP46Roster*,unsigned op,unsigned slot,uint64_t id,int explicit_press,uint32_t now);
#endif
