#include "scope51.h"
struct RP51Scope {
 const void *decoded_buffer,*dispatch_handle;
 char wire[89]; size_t length;
 unsigned attempted,valid,dispatching,consumed,decode_conflict;
};
int rp51_init(RP51*p,const RP51Ops*o){
 if(!p||!o||!o->receive||!o->decode||!o->dispatch||!o->deliver||!o->owner||!o->now)return 0;
 *p=(RP51){.ops=*o};return 1;
}
void rp51_receive(RP51*p,void*self,const void*event){
 if(!p||!p->ops.receive)return;
 if(!p->ops.owner(p->ops.arg)){p->ops.receive(p->ops.arg,self,event);return;}
 RP51Scope s={0},*outer=p->scope;
 p->scope=&s;
 p->ops.receive(p->ops.arg,self,event);
 p->scope=outer;
}
int rp51_decode(RP51*p,void*out,const void*input,unsigned len,void*extra){
 if(!p||!p->ops.decode)return 0;
 if(!p->ops.owner(p->ops.arg))return p->ops.decode(p->ops.arg,out,input,len,extra);
 RP51Scope*s=p->scope;
 int eligible=s&&!s->attempted&&!s->dispatching&&out&&!extra;
 if(s){if(s->attempted)s->decode_conflict=1;s->attempted=1;s->valid=0;}
 int ret=p->ops.decode(p->ops.arg,out,input,len,extra);
 /* At this exact call site only, the original decoder is given a 256-byte
  * output by ReceiveText. Its success is mandatory, not inferred from NUL. */
 if(eligible&&ret==1&&p->scope==s&&!s->decode_conflict&&rp50_copy_wire(out,256,s->wire,&s->length)){
  s->decoded_buffer=out;s->valid=1;
 }
 return ret;
}
void rp51_dispatch(RP51*p,void*self,void*chat,const void*h,const char*text,unsigned flag){
 if(!p||!p->ops.dispatch)return;
 if(!p->ops.owner(p->ops.arg)){p->ops.dispatch(p->ops.arg,self,chat,h,text,flag);return;}
 RP51Scope*s=p->scope;
 if(!s){p->ops.dispatch(p->ops.arg,self,chat,h,text,flag);return;}
 if(s->dispatching){ /* suppress reentrant delegate paths, even same pointers */
  unsigned old=s->dispatching;s->dispatching=2;
  p->ops.dispatch(p->ops.arg,self,chat,h,text,flag);s->dispatching=old;return;
 }
 int eligible=s->valid&&!s->consumed&&h&&text&&text==s->decoded_buffer;
 s->dispatch_handle=eligible?h:0;s->dispatching=1;
 p->ops.dispatch(p->ops.arg,self,chat,h,text,flag);
 s->dispatch_handle=0;s->dispatching=0;s->valid=0;
}
int rp51_post_permission(RP51*p,const void*h,const char*text){
 if(!p||!p->ops.owner(p->ops.arg))return 0;
 RP51Scope*s=p->scope;
 if(!s||s->dispatching!=1||!s->valid||s->consumed||!h||!text||h!=s->dispatch_handle||text!=s->decoded_buffer)return 0;
 s->consumed=1;
 /* Reject if buffer has changed since successful decode. Bounded read; the
  * exact buffer is still live under the synchronous ReceiveText frame. */
 for(size_t i=0;i<=s->length;i++)if(text[i]!=s->wire[i])return 0;
 return p->ops.deliver(p->ops.arg,h,s->wire,s->length+1,p->ops.now(p->ops.arg));
}
