#include "rp43.h"
/* All arithmetic in centimeters. This module has no sockets, heap, game writes,
 * persistent wallet or native engine calls. Trusted adapter supplies identity,
 * private-room epoch and observation on a single host game-thread. */
static void zero(void *p,size_t n){unsigned char *b=p;while(n--)*b++=0;}
static int valid_msg(const RPMessage*m){return m&&m->epoch&&m->seq&&m->generation&&m->sender_generation&&m->op>=RP_GRANT&&m->op<=RP_DELIVER&&m->target<RP_MAX;}
static void hex(char*p,uint32_t v,unsigned n){static const char h[]="0123456789ABCDEF";while(n){p[--n]=h[v&15];v>>=4;}}
static int unhex(const char*p,unsigned n,uint32_t*v){uint32_t x=0;for(unsigned i=0;i<n;i++){unsigned c=(unsigned char)p[i],d;if(c>='0'&&c<='9')d=c-'0';else if(c>='A'&&c<='F')d=c-'A'+10;else return 0;x=(x<<4)|d;}*v=x;return 1;}
int rp_encode(const RPMessage*m,char o[RP_WIRE]){if(!o||!valid_msg(m))return 0;o[0]='R';o[1]='P';o[2]='4';o[3]='3';hex(o+4,m->epoch,8);hex(o+12,m->seq,8);hex(o+20,m->op,2);hex(o+22,m->target,2);hex(o+24,m->generation,8);hex(o+32,m->case_id,8);hex(o+40,m->sender_generation,8);hex(o+48,m->attempt,8);o[56]=0;return 1;}
int rp_decode(const char*p,size_t n,RPMessage*m){RPMessage q;uint32_t op,t;if(!p||!m||n!=56||p[0]!='R'||p[1]!='P'||p[2]!='4'||p[3]!='3'||!unhex(p+4,8,&q.epoch)||!unhex(p+12,8,&q.seq)||!unhex(p+20,2,&op)||!unhex(p+22,2,&t)||!unhex(p+24,8,&q.generation)||!unhex(p+32,8,&q.case_id)||!unhex(p+40,8,&q.sender_generation)||!unhex(p+48,8,&q.attempt))return 0;q.op=(uint8_t)op;q.target=(uint8_t)t;if(!valid_msg(&q))return 0;*m=q;return 1;}
static int find(const RPRoom*r,uint64_t id){if(id)for(unsigned i=0;i<RP_MAX;i++)if(r->peers[i].present&&r->peers[i].id==id)return (int)i;return -1;}
static void reset_pair(RPPeer*p){p->state=RP_FREE;p->partner=RP_NONE;p->deadline=0;p->grace=0;p->attempt=0;}
static void release(RPRoom*r,unsigned i){RPPeer*p=&r->peers[i];unsigned j=p->partner;if(j<RP_MAX&&r->peers[j].present&&r->peers[j].partner==i)reset_pair(&r->peers[j]);reset_pair(p);}
static void close_room(RPRoom*r){r->closed=1;for(unsigned i=0;i<RP_MAX;i++){reset_pair(&r->peers[i]);r->peers[i].duty=0;}}
static int fresh(const RPRoom*r,const RPPeer*p){return p->present&&p->alive&&p->has_pos&&r->now-p->pos_ms<=RP_POS_TTL;}
static int within(const int32_t*a,const int32_t*b,int64_t rad){int64_t d=0;for(int i=0;i<3;i++){int64_t v=(int64_t)a[i]-b[i];if(v< -rad||v>rad)return 0;d+=v*v;}return d<=rad*rad;}
static int near(const RPRoom*r,const RPPeer*p,const RPPeer*q,int rad){return fresh(r,p)&&fresh(r,q)&&within(p->xyz,q->xyz,rad);}
static const int32_t stations[3][3]={{43349,-98191,3071},{185575,368252,3427},{-44271,601703,3172}};
static int station(const RPRoom*r,const RPPeer*p){if(fresh(r,p))for(int i=0;i<3;i++)if(within(p->xyz,stations[i],1200))return i;return -1;}
int rp_init(RPRoom*r,uint32_t epoch,uint64_t host,uint32_t now){if(!r||!epoch||!host)return 0;zero(r,sizeof(*r));r->epoch=epoch;r->host=host;r->now=now;for(unsigned i=0;i<RP_MAX;i++)r->peers[i].partner=RP_NONE;return 1;}
static void remove_peer(RPRoom*r,unsigned i){RPPeer*p=&r->peers[i];uint64_t id=p->id;release(r,i);zero(p,sizeof(*p));p->partner=RP_NONE;if(id==r->host)close_room(r);}
int rp_tick(RPRoom*r,uint32_t now){if(!r||r->closed||!r->epoch||now<r->now||now>UINT32_MAX-15000u){if(r)close_room(r);return 0;}r->now=now;
 for(unsigned i=0;i<RP_MAX;i++){RPPeer*p=&r->peers[i];if(!p->present)continue;if(now-p->seen>RP_PEER_TTL){remove_peer(r,i);if(r->closed)return 0;continue;}if(p->state==RP_PENDING&&now>=p->deadline)release(r,i);}
 for(unsigned i=0;i<RP_MAX;i++){RPPeer*p=&r->peers[i];if(!p->present||!p->duty||p->state!=RP_ESCORT)continue;unsigned j=p->partner;if(j>=RP_MAX||!r->peers[j].present){release(r,i);continue;}if(!near(r,p,&r->peers[j],3500)){if(!p->grace){p->grace=1;p->deadline=now+5000;}else if(now>=p->deadline)release(r,i);}else {p->grace=0;p->deadline=0;}}
 return !r->closed;}
int rp_join(RPRoom*r,unsigned s,uint64_t id,uint32_t now){if(!rp_tick(r,now)||s>=RP_MAX||!id||r->peers[s].present||find(r,id)>=0||r->next_gen==UINT32_MAX)return 0;RPPeer*p=&r->peers[s];zero(p,sizeof(*p));p->present=1;p->id=id;p->seen=now;p->generation=++r->next_gen;p->partner=RP_NONE;return 1;}
int rp_leave(RPRoom*r,unsigned s,uint64_t id,uint32_t now){if(!rp_tick(r,now)||s>=RP_MAX||!id||!r->peers[s].present||r->peers[s].id!=id)return 0;remove_peer(r,s);return 1;}
int rp_observe(RPRoom*r,unsigned s,uint64_t id,const int32_t xyz[3],int alive,uint32_t now){if(!rp_tick(r,now)||s>=RP_MAX||!xyz||!id||!r->peers[s].present||r->peers[s].id!=id||(alive!=0&&alive!=1))return 0;for(int i=0;i<3;i++)if(xyz[i]<-2000000||xyz[i]>2000000)return 0;RPPeer*p=&r->peers[s];for(int i=0;i<3;i++)p->xyz[i]=xyz[i];p->alive=(uint8_t)alive;p->has_pos=1;p->seen=p->pos_ms=now;if(!alive){release(r,s);p->duty=0;}return 1;}
int rp_receive(RPRoom*r,uint64_t id,const char*w,size_t n,uint32_t now){RPMessage m;if(!rp_tick(r,now)||!rp_decode(w,n,&m)||m.epoch!=r->epoch||find(r,r->host)<0)return 0;int si=find(r,id);if(si<0)return 0;unsigned s=(unsigned)si;RPPeer*p=&r->peers[s],*q=&r->peers[m.target];if(p->generation!=m.sender_generation||!q->present||q->generation!=m.generation||(p->has_seq&&m.seq<=p->seq))return 0;
 /* Sequence bound to authenticated sender and its current membership. A
  * rejected but well-formed current-generation request consumes sequence. */
 p->has_seq=1;p->seq=m.seq;if(m.op!=RP_ACCEPT&&m.op!=RP_CANCEL&&m.op!=RP_DELIVER&&m.attempt)return 0;int host=id==r->host;
 switch(m.op){
 case RP_GRANT:if(host&&!m.case_id&&!q->wanted){q->officer=1;return 1;}break;
 case RP_REVOKE:if(host&&!m.case_id){release(r,m.target);q->officer=q->duty=0;return 1;}break;
 case RP_VIOLATION:if(host&&!m.case_id&&!q->duty&&!q->wanted&&q->state==RP_FREE&&r->next_case<UINT32_MAX){q->wanted=1;q->case_id=++r->next_case;return 1;}break;
 case RP_DUTY:if(p==q&&!m.case_id&&p->officer&&!p->wanted&&!p->duty&&p->state==RP_FREE&&station(r,p)>=0){p->duty=1;return 1;}break;
 case RP_OFF:if(p==q&&!m.case_id&&p->duty&&p->state==RP_FREE&&station(r,p)>=0){p->duty=0;return 1;}break;
 case RP_ARREST:if(p!=q&&p->officer&&p->duty&&p->state==RP_FREE&&q->wanted&&q->case_id==m.case_id&&m.case_id&&!q->duty&&q->state==RP_FREE&&near(r,p,q,300)&&r->next_attempt<UINT32_MAX){p->attempt=q->attempt=++r->next_attempt;p->state=q->state=RP_PENDING;p->partner=m.target;q->partner=(uint8_t)s;p->deadline=q->deadline=now+15000;return 1;}break;
 case RP_ACCEPT:if(p!=q&&p->wanted&&p->case_id==m.case_id&&m.case_id&&!p->duty&&q->officer&&q->duty&&p->state==RP_PENDING&&q->state==RP_PENDING&&p->partner==m.target&&q->partner==s&&m.attempt&&p->attempt==m.attempt&&q->attempt==m.attempt&&near(r,p,q,300)){p->state=q->state=RP_ESCORT;p->deadline=q->deadline=0;return 1;}break;
 case RP_CANCEL:if(p==q&&!m.case_id&&p->attempt==m.attempt){release(r,s);return 1;}break;
 case RP_DELIVER:if(host&&m.case_id&&m.attempt&&q->attempt==m.attempt&&q->officer&&q->duty&&q->state==RP_ESCORT&&q->partner<RP_MAX){RPPeer*c=&r->peers[q->partner];int st=station(r,q);if(c->state==RP_ESCORT&&c->partner==m.target&&c->attempt==m.attempt&&c->wanted&&c->case_id==m.case_id&&st>=0&&station(r,c)==st&&near(r,q,c,1200)&&q->rewards<=UINT32_MAX-1800){c->wanted=0;c->case_id=0;q->rewards+=1800;release(r,m.target);return 1;}}break;
 }
 return 0;}
