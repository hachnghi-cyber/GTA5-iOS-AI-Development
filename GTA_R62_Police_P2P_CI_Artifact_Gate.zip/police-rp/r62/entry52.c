#include "entry52.h"
static _Atomic(RP51Native*) binding;
int rp52_publish(RP51Native*n){
 if(!n||!n->gate||!n->clock||!n->base||!rp50_on_owner(n->gate)||n->base!=n->gate->native.base||!n->gate->native.exact||!n->binding.ops.receive||!n->binding.ops.decode||!n->binding.ops.dispatch||!n->binding.ops.deliver||!n->binding.ops.owner||!n->binding.ops.now||n->binding.ops.arg!=n)return 0;
 RP51Native*expected=0;
 return atomic_compare_exchange_strong_explicit(&binding,&expected,n,memory_order_release,memory_order_relaxed);
}
/* Activation before publication is a fatal installer contract violation,
 * never silently skip an original engine call. */
static RP51*get(void){RP51Native*n=atomic_load_explicit(&binding,memory_order_acquire);if(!n)__builtin_trap();return &n->binding;}
void rp52_receive_entry(void*self,const void*event){rp51_receive(get(),self,event);}
int rp52_decode_entry(void*out,const void*input,unsigned len,void*extra){return rp51_decode(get(),out,input,len,extra);}
void rp52_dispatch_entry(void*self,void*chat,const void*h,const char*text,unsigned flag){rp51_dispatch(get(),self,chat,h,text,flag);}
void rp52_post_entry(const void*h,const char*text){(void)rp51_post_permission(get(),h,text);}
