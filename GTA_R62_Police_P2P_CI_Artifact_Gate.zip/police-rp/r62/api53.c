#include "api53.h"
_Static_assert(sizeof(void*)==8,"RP53 requires 64-bit ABI");
_Static_assert(sizeof(RP53API)==48 && offsetof(RP53API,receive)==16 && offsetof(RP53API,post)==40,"RP53 ABI mismatch");
static const RP53API table={RP53_ABI_MAGIC,RP53_ABI_VERSION,sizeof(RP53API),0,rp52_receive_entry,rp52_decode_entry,rp52_dispatch_entry,rp52_post_entry};
static _Atomic(const RP53API*) published;
int rp53_publish(RP51Native*n){
 if(!rp52_publish(n))return 0;
 atomic_store_explicit(&published,&table,memory_order_release);return 1;
}
const RP53API*rp53_get_api(void){return atomic_load_explicit(&published,memory_order_acquire);}
/* For a readable table from the specific verified export only. Not a pointer
 * validity check. Caller must preserve stock handling for unavailable API. */
int rp53_api_valid(const RP53API*p){return p&&p->magic==RP53_ABI_MAGIC&&p->version==RP53_ABI_VERSION&&p->size==sizeof(RP53API)&&!p->reserved&&p->receive&&p->decode&&p->dispatch&&p->post;}
