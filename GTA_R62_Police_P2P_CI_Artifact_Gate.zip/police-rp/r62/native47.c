#include "native47.h"
#define A(b,o,t) ((t)((b)+(uintptr_t)(o)))
typedef void*(*Ptr1)(const void*);
typedef struct {uintptr_t base;const RP46Roster*r;void*net;void*text;const void*local_info;} Native47;
static int idle_checked(void){return 0;} /* prechecked on the same game thread */
static int pending(void*x){return !x||*((const unsigned char*)x+0x90)!=0;}
static int match(uintptr_t b,int exact,int thread,const RP46Roster*r){RP45Identity id;if(!r||!r->ctx.private_room||!r->ctx.all_opted||!r->ctx.local_opted||!native45_identity(b,exact,thread,&id))return 0;return id.session==r->ctx.session&&id.host==r->ctx.host&&id.local==r->ctx.local&&id.local_slot==r->ctx.slot;}
static int tx_native(void*arg,const char*w,size_t n){Native47*c=arg;uintptr_t b=c->base;
 /* Singleton pointer verified in binary. UpdateInput branches to typing
  * on bit 0 at +0x14; also yield while IME update flag +0x17 is set. */
 const unsigned char*ui=*(const unsigned char*const*)(b+0x2906930);if(!ui)return TX44_NOT_READY;if((ui[0x14]&1)||ui[0x17])return TX44_BUSY;
 RP44Transport t={.initialized=A(b,0x1a00d18,int(*)(void*)),.typing=idle_checked,.pending=pending,.local=A(b,0x1d93fc4,int(*)(const void*)),.local_index=A(b,0x1d93030,int(*)(const void*)),.gamer_id=A(b,0x1d97d9c,const void*(*)(const void*)),.privileges=A(b,0x1a015c4,int(*)(void*,int)),.have_typer=A(b,0x1a013dc,int(*)(void*,const void*)),.submit=A(b,0x1733b30,int(*)(void*,const void*,const char*,int))};
 return transport44_send(&t,c->net,c->text,c->local_info,w,n,1,1,c->r->ctx.host==c->r->ctx.local,1);}
int native47_frame(RP47*p,const RP46Roster*r,const RP47Observation*o,size_t count,uintptr_t b,int exact,int thread,uint32_t now){if(!p||!p->active)return 0;if(!match(b,exact,thread,r)){rp47_stop(p);return 0;}void*net=*(void**)(b+0x286a570);void*mgr=*(void**)(b+0x286a540);if(!net||!mgr){rp47_stop(p);return 0;}const void*player=A(b,0x18766f0,Ptr1)(mgr);if(!player){rp47_stop(p);return 0;}const void*const*vt=*(const void*const*const*)player;if(!vt||!vt[7]){rp47_stop(p);return 0;}const void*info=((Ptr1)vt[7])(player);if(!info){rp47_stop(p);return 0;}const void*h=A(b,0x1d93b8c,Ptr1)(info);unsigned slot;uint64_t id;if(!native45_sender(b,exact,thread,h,&slot,&id)||id!=r->ctx.local||slot!=r->ctx.slot){rp47_stop(p);return 0;}
 Native47 c={b,r,net,(unsigned char*)net+0x88,info};return rp47_frame(p,r,o,count,tx_native,&c,now);}
int native47_rx(RP47*p,const RP46Roster*r,uintptr_t b,int exact,int thread,int allowed,const void*h,const char*text,size_t len,uint32_t now){if(!p||!p->active||!allowed||!text||!h||!exact||!thread)return 0;if(len!=20&&len!=56&&len!=88)return 0;/* Only called after native CanReceiveFrom; no bypass, no hidden chat. */if(!match(b,exact,thread,r)){rp47_stop(p);return 0;}unsigned s;uint64_t id;if(!native45_sender(b,exact,thread,h,&s,&id))return 0;int found=0;for(unsigned i=0;i<r->count&&i<RP46_MAX;i++)if(r->members[i].id==id&&r->members[i].slot==s)found=1;if(!found)return 0;return rp47_receive(p,r,id,text,len,now);}
