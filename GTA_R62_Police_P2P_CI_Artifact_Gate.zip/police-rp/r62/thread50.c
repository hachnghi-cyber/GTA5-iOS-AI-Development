#include "thread50.h"
#if defined(RP50_FREESTANDING_IOS)
extern rp50_thread_t pthread_self(void);
extern int pthread_equal(rp50_thread_t,rp50_thread_t);
#endif
int rp50_init(RP50*p,uintptr_t b,int exact,int tick,void*ui,int(*show)(void*,const RP47View*,uint32_t),void(*clear)(void*)){
    if(!p||!b||!exact||!tick||!show||!clear)return 0;
    p->owner=pthread_self();p->native=(RP49Native){b,1,1,ui,show,clear};p->bridge=(RP49){0};
    atomic_init(&p->rejected_thread,0);atomic_init(&p->rejected_span,0);atomic_init(&p->rx_calls,0);return 1;
}
int rp50_on_owner(RP50*p){if(!p)return 0;if(pthread_equal(pthread_self(),p->owner))return 1;atomic_fetch_add_explicit(&p->rejected_thread,1,memory_order_relaxed);return 0;}
int rp50_arm(RP50*p,const RP46Roster*r,int yes,uint32_t now){if(!rp50_on_owner(p))return 0;RP49Ops o=rp49_native_ops(&p->native);return rp49_arm(&p->bridge,&o,r,yes,now);}
int rp50_tick(RP50*p,int yes,uint32_t now){if(!rp50_on_owner(p))return 0;RP49Ops o=rp49_native_ops(&p->native);return rp49_tick(&p->bridge,&o,yes,now);}
int rp50_confirm(RP50*p,uint32_t t,int yes,uint32_t now){if(!rp50_on_owner(p))return 0;RP49Ops o=rp49_native_ops(&p->native);return rp49_confirm(&p->bridge,&o,t,yes,now);}
int rp50_stop(RP50*p){if(!rp50_on_owner(p)||p->bridge.busy)return 0;RP49Ops o=rp49_native_ops(&p->native);rp49_stop(&p->bridge,&o);return 1;}
int rp50_copy_wire(const char*s,size_t span,char out[89],size_t*n){
    if(!n)return 0;*n=0;if(!s||!out||span<21)return 0;
    /* Never read beyond the engine-proven span; never copy >88 bytes. */
    size_t limit=span<89?span:89,i=0;
    for(;i<limit;i++){unsigned char ch=(unsigned char)s[i];if(!ch)break;if(ch<0x21||ch>0x7e)return 0;out[i]=(char)ch;}
    if(i==limit||(i!=20&&i!=56&&i!=88))return 0;
    if(out[0]!='R'||out[1]!='P')return 0;
    out[i]=0;*n=i;return 1;
}
int rp50_rx(RP50*p,int allowed,const void*h,const char*s,size_t span,uint32_t now){
    /* On wrong thread: no sender dereference, no RP state access, no UI. */
    if(!rp50_on_owner(p)||!allowed||!h||!p->bridge.armed||p->bridge.busy)return 0;
    atomic_fetch_add_explicit(&p->rx_calls,1,memory_order_relaxed);
    char w[89];size_t n;if(!rp50_copy_wire(s,span,w,&n)){atomic_fetch_add_explicit(&p->rejected_span,1,memory_order_relaxed);return 0;}
    return rp49_native_rx(&p->bridge,&p->native,allowed,h,w,n,now);
}
