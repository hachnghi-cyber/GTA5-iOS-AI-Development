#ifndef RP_PROBE_H
#define RP_PROBE_H
#include <stdint.h>
typedef struct { uint64_t *result; uint64_t unused; uint64_t *params; } NativeInfo;
typedef void (*Native)(NativeInfo *);
typedef struct { Native session, player_id, player_ped, active, get_ped, exists, dead, coords, context, pause, held, disabled_held, disabled_just; int (*key_state)(int); } RPApi;
typedef struct { int session, slot, alive, xcm, ycm, zcm; uint32_t mask; int nearest, distance_cm, pressed; } RPSnapshot;
int rp_snapshot(const RPApi*,int pressed,RPSnapshot*);
int rp_context(const RPApi*);
typedef int (*XInput)(unsigned,void*);
unsigned rp_custom_step(uint32_t*,int,uint16_t,int,uint32_t);
int rp_custom_input(const RPApi*,XInput,uint32_t*,uint32_t);
#endif
