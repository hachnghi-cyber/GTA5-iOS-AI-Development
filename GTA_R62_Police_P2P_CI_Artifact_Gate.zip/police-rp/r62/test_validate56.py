"""Synthetic metadata tests, never a real linked dylib."""
import struct
from validate56 import validate,EXPORTS
from loader53 import PATH,SYSTEM,load_cmd

def leb(v):
    out=bytearray()
    while v>=128:out.append((v&127)|128);v>>=7
    out.append(v);return bytes(out)
def fixture(names=EXPORTS,addrs=None,flags=0x80000400,platform=2,zero=False):
    if addrs is None:addrs=[0x400+4*i for i in range(len(names))]
    leaves=[];edges=[n.encode()+b'\0' for n in names]
    for a in addrs:
        payload=b'\0'+leb(a);leaves.append(leb(len(payload))+payload+b'\0')
    base=2+sum(len(e)+1 for e in edges)
    while True:
        offsets=[];p=base
        for leaf in leaves:offsets.append(p);p+=len(leaf)
        trie=b'\0'+bytes([len(names)])+b''.join(e+leb(o) for e,o in zip(edges,offsets))
        if len(trie)==base:break
        base=len(trie)
    trie+=b''.join(leaves)
    seg=struct.pack('<II16sQQQQiiII',0x19,152,b'__TEXT',0,0x4000,0,0x4000,5,5,1,0)
    sec=struct.pack('<16s16sQQ8I',b'__text',b'__TEXT',0x400,0x100,0x400,2,0,0,flags,0,0,0)
    def cmd(k,s):return struct.pack('<I',k)+load_cmd(s)[4:]
    cmds=[seg+sec,struct.pack('<6I',0x32,24,platform,0xf0000,0xf0000,0),cmd(0xd,PATH),cmd(0xc,SYSTEM),struct.pack('<4I',0x80000033,16,0x1000,len(trie))]
    b=bytearray((struct.pack('<8I',0xfeedfacf,0x100000c,0,6,len(cmds),sum(map(len,cmds)),0,0)+b''.join(cmds)).ljust(0x4000,b'\0'))
    b[0x1000:0x1000+len(trie)]=trie
    if not zero:b[0x400:0x500]=struct.pack('<I',0xd65f03c0)*64
    return bytes(b)
def rejects(**kw):
    try:validate(fixture(**kw))
    except ValueError:return
    raise AssertionError(kw)
assert len(validate(fixture())['lifecycle_exports'])==7
rejects(names=EXPORTS[:-1]);rejects(addrs=[0x400]*7);rejects(addrs=[0x401]+[0x404+4*i for i in range(6)])
rejects(addrs=[0x600]+[0x404+4*i for i in range(6)]);rejects(flags=0);rejects(platform=7);rejects(zero=True)
print('PASS 8 synthetic dylib metadata cases: 7 lifecycle exports, missing, alias, unaligned, non-code, no instruction section, simulator, zero entry rejected')
