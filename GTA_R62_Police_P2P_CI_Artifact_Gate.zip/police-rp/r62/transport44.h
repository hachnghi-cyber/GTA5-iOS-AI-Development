#ifndef TRANSPORT44_H
#define TRANSPORT44_H
#include "state44.h"
/* All callbacks must resolve against exact R42 build, game thread only.
 * No caller-supplied pointers from the network, no registration mutation. */
typedef struct {int (*initialized)(void*);int (*typing)(void);int (*pending)(void*);int (*local)(const void*);int (*local_index)(const void*);const void*(*gamer_id)(const void*);int (*privileges)(void*,int);int (*have_typer)(void*,const void*);int (*submit)(void*,const void*,const char*,int);} RP44Transport;
enum {TX44_DENIED=0,TX44_QUEUED=1,TX44_NOT_READY=-1,TX44_BUSY=-2,TX44_REJECTED=-3};
int transport44_send(const RP44Transport*,void *network_chat,void *text_chat,const void *local_info,const char *wire,size_t len,int private_room,int opted_in,int is_host,int authorized_send);
#endif
