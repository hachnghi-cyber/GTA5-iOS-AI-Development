#!/usr/bin/env python3
"""Build gate for real iPhoneOS RP library. Metadata validation only."""
import json,struct,sys
from pathlib import Path
from loader53 import validate_dylib,commands,find_cmd,linkedit_blob,export_address,require
EXPORTS=('_rp53_get_api','_rp55_bootstrap','_rp55_status','_rp55_arm','_rp55_tick','_rp55_confirm','_rp55_stop')
def validate(b):
    report=validate_dylib(b);cs,_=commands(b,6);textbase=None;execsecs=[]
    for k,_,c in cs:
        if k!=0x19:continue
        name,va,vs,fo,fs,mp,ip,ns,fl=struct.unpack_from('<16sQQQQiiII',c,8)
        if name.rstrip(b'\0')==b'__TEXT' and fo==0:textbase=va
        for i in range(ns):
            sn,sg,a,n,o,al,ro,nr,f,*_=struct.unpack_from('<16s16sQQ8I',c,72+i*80)
            if not f&0x80000000 or f&255!=0:continue
            require(ip&4 and not ip&2 and f&255==0 and n>0 and va<=a and a+n<=va+fs and o==fo+a-va and o+n<=len(b),'invalid file-backed instruction section')
            execsecs.append((a,a+n,o))
    require(textbase is not None and execsecs,'missing instruction section')
    tries=[c for k,_,c in cs if k==0x80000033]
    trie=linkedit_blob(b,tries[0]) if tries else linkedit_blob(b,find_cmd(cs,0x80000022),40)
    exports={}
    for name in EXPORTS:
        a=textbase+export_address(trie,name);matches=[s for s in execsecs if s[0]<=a and a+4<=s[1]]
        require(a%4==0 and len(matches)==1,'export outside instruction section: '+name)
        lo,_,o=matches[0];require(any(b[o+a-lo:o+a-lo+4]),'zero export entry: '+name);exports[name]=hex(a)
    require(len(set(exports.values()))==len(exports),'aliased lifecycle entrypoints')
    return dict(report,lifecycle_exports=exports,validation='STATIC_DYLIB_METADATA_ONLY',runtime_verified=False)
if __name__=='__main__':print(json.dumps(validate(Path(sys.argv[1]).read_bytes()),indent=2))
