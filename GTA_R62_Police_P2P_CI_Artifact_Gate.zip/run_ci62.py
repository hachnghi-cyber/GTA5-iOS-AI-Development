#!/usr/bin/env python3
"""Explicit source-only push to a new branch; watch that exact commit, fetch its dylib artifact."""
import argparse, json, shutil, subprocess, tempfile, time, uuid
from pathlib import Path
HERE=Path(__file__).resolve().parent
REPO='hachnghi-cyber/GTA5-iOS-AI-Development'
WORKFLOW='build-rp-r62-native.yml'
def call(args,cwd=None): subprocess.run(args,cwd=cwd,check=True)
def out(args,cwd=None): return subprocess.check_output(args,cwd=cwd,text=True).strip()
def main():
    p=argparse.ArgumentParser(); p.add_argument('--repo',default=REPO); p.add_argument('--publish-source',action='store_true',help='explicitly approve uploading generated source to this repository'); p.add_argument('--output',type=Path,default=Path('RP62-artifact')); a=p.parse_args()
    if not a.publish_source:p.error('review the source and pass --publish-source; the default repository is public')
    dst=a.output.resolve()
    if dst.exists():p.error('output already exists')
    for x in ('git','gh'):
        if not shutil.which(x):p.error(x+' not installed')
    call(['gh','auth','status']); call(['gh','auth','setup-git'])
    branch='rp/r62-ci-'+uuid.uuid4().hex[:12]
    with tempfile.TemporaryDirectory(prefix='rp62-') as td:
        repo=Path(td)/'repo'; call(['gh','repo','clone',a.repo,str(repo),'--','--depth','1'])
        call(['git','switch','-c',branch],repo)
        dest=repo/'police-rp/r62'; dest.parent.mkdir(parents=True,exist_ok=True)
        shutil.copytree(HERE/'police-rp/r62',dest,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
        flow=repo/'.github/workflows'/WORKFLOW; flow.parent.mkdir(parents=True,exist_ok=True)
        if flow.exists():raise RuntimeError('workflow already exists; no overwrite')
        shutil.copy2(HERE/'.github/workflows'/WORKFLOW,flow)
        call(['git','add','--','police-rp/r62','.github/workflows/'+WORKFLOW],repo)
        call(['git','commit','-m','R62 isolated iPhoneOS SDK build'],repo)
        sha=out(['git','rev-parse','HEAD'],repo)
        call(['git','push','origin',f'HEAD:refs/heads/{branch}'],repo)
        print('Pushed',branch,sha,flush=True)
        runs=[]
        for _ in range(24):
            raw=out(['gh','run','list','--repo',a.repo,'--branch',branch,'--commit',sha,'--json','databaseId,headSha,event,workflowName','--limit','10'])
            runs=[r for r in json.loads(raw) if r['headSha']==sha and r['event']=='push' and r['workflowName']=='Build Police RP R62 iPhoneOS dylib']
            if runs:break
            time.sleep(5)
        if len(runs)!=1:raise RuntimeError('no unique run; check Actions for '+branch)
        rid=str(runs[0]['databaseId']); print('Run:',rid,flush=True)
        call(['gh','run','watch',rid,'--repo',a.repo,'--exit-status'])
        call(['gh','run','download',rid,'--repo',a.repo,'--name','RP62-iphoneos-dylib','--dir',str(dst)])
        call([__import__('sys').executable,str(HERE/'police-rp/r62/artifact62.py'),'verify',str(dst),'--commit',sha,'--run',rid,'--repo',a.repo])
        print('SDK artifact validated, no IPA or hooks installed:',dst)
if __name__=='__main__': main()
