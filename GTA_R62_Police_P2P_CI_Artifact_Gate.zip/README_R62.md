# R62 — isolated CI build and artifact acceptance gate

Continues R61 with unchanged 18 C sources and 7 exported API definitions. This release does not contain an iPhoneOS SDK dylib, a new IPA, installed hooks, a successful CI run, or on-device RP gameplay.

## Root cause and correction
- Local Swift ld64.lld reports platform iOS unsupported. An alternate upstream LLVM linker was investigated, but the download could not be obtained in this environment. `xcrun` and `gh` are not installed locally.
- GitHub connector confirmed repository access; repository is public. No source uploaded, branch created, or CI run started from this environment. The connector does not directly accept a local ZIP for a git push or expose workflow dispatch. The existing R61 workflow uses workflow_dispatch only, which GitHub requires to be on the default branch. R62 uses a push trigger restricted to fresh `rp/r62-ci-*` branches instead, so no main branch edits are needed.
- `run_ci62.py` is a local Python launcher using authenticated GitHub CLI and git. It makes a fresh temporary clone and unique branch, copies source only, pushes, watches the exact commit/run and downloads the named artifact. Explicit `--publish-source` approval is required, since default repository is public. No game IPA, game binary, device logs, or credentials included. Run from an extracted ZIP after Git and GitHub CLI are installed, `gh auth login` completed, workflow push permission granted, and Git author configured.

```
python run_ci62.py --publish-source
```

If repository authorization rejects workflow file creation, review GitHub CLI workflow permission (`gh auth refresh -s workflow` for an OAuth token) and repository Actions policy. If a run is started but cannot be found by CLI, inspect the printed branch under Actions; do not launch repeated builds blindly. The launcher has not been executed against GitHub in this turn.

## Artifact gate
`artifact62.py` verifies source hashes, build output file hashes, exact seven exports, Mach-O platform/device metadata, executable-section entrypoints, and expected commit/run/repository values. The CI runner records the checkout commit and build reports; the local launcher compares against the specific run obtained from GitHub. This is consistency checking, not cryptographic provenance attestation and not proof of runtime safety. `test_artifact62.py` uses synthetic binaries only.

## Optional loader-only staging after real SDK success
The artifact gate wraps the R53 loader-only staging path. It does not install hooks or enable RP; the R57-R60 island path remains uninstalled. A successfully linked dylib can first be checked via an unsigned loader-only IPA, rather than enabling everything at once. Do not run with synthetic test fixtures. No IPA is created by R62.

```
python police-rp/r62/artifact62.py stage-loader-only RP62-artifact --commit <exact-commit> --run <exact-run-id> --repo hachnghi-cyber/GTA5-iOS-AI-Development /path/to/R42.ipa /path/to/new-loader-only.ipa
```

R42 must match the exact prior SHA-256. Output must be re-signed before installation. Device startup, loader and RP gameplay remain unverified. Only consenting private rooms are intended for later RP tests.
