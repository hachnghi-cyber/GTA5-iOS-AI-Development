/* Police RP ONLY v1.7 - read-only 32-slot visual-tag probe.
 * Raw tag/blip slots are NOT verified player IDs, player counts or arrest targets.
 * Never calls RAGE functions, never hooks game thread, never sends network data.
 * Samples globally visible 1/4-byte integers once per second on main queue.
 * Only the exact GTA5 UUID is accepted. Do not redistribute as a generic patch.
 */
#include <dispatch/dispatch.h>
#include <mach-o/dyld.h>
#include <mach-o/loader.h>
#include <mach/vm_prot.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

#define V12_ONLINE_MODE     ((uintptr_t)0x1027B1AE8ULL)
#define V12_JOB             ((uintptr_t)0x1027B1B2CULL)
#define V12_SHIFT           ((uintptr_t)0x10355EE34ULL)
#define V12_SESSION_STARTED ((uintptr_t)0x10355577DULL)
#define V12_JOB_PLAYERS_RAW ((uintptr_t)0x103555794ULL)
#define V12_WAS_IN_GAME     ((uintptr_t)0x1035501FCULL)
#define V12_P2P_JOINING     ((uintptr_t)0x103550204ULL)
/* 32 entries each, backed by two contiguous 128-byte static arrays. */
#define V12_TAG_PED_RAW     ((uintptr_t)0x10356504CULL)
#define V12_BLIP_RAW        ((uintptr_t)0x1035650CCULL)
#define PRP_SLOTS           32U
#define PRP_FILE            "PoliceRPRoster-v17.txt"
#define PRP_MAX_LINES       200
#define PRP_HEARTBEAT_SEC   20U

static const uint8_t kUuid[16] = {0x6a,0x49,0x8e,0x32,0xe7,0x0c,0x33,0x4c,
                                 0xbc,0xa3,0xaf,0xfd,0x35,0xe8,0xd1,0x71};
static dispatch_source_t gTimer;
static const int32_t *gJob, *gMode;
static const uint32_t *gJobPlayers;
static const int32_t *gTagPed, *gBlip;
static const uint8_t *gShift, *gSessionStarted, *gWasInGame, *gP2pJoining;
static unsigned gTicks, gLines;
static uint32_t gLastSig;
static int gHavePrev=0;

static void write_log(const char *line,int reset) {
    if (!reset && gLines >= PRP_MAX_LINES) return;
    fprintf(stderr,"%s\n",line);
    const char *home=getenv("HOME");
    if (!home || !*home) return;
    char path[1024];
    int n=snprintf(path,sizeof(path),"%s/Documents/" PRP_FILE,home);
    if (n<=0 || (size_t)n>=sizeof(path)) return;
    FILE *f=fopen(path,reset?"w":"a");
    if (!f) return;
    int ok=fputs(line,f)>=0 && fputc('\n',f)!=EOF;
    if (fclose(f)!=0) ok=0;
    if (ok) gLines=reset?1:gLines+1;
}

static int address_in_rw_data(const struct mach_header_64 *h,uintptr_t address,size_t size) {
    const uint8_t *cmds=(const uint8_t *)(h+1);
    size_t off=0;
    for (uint32_t i=0;i<h->ncmds;i++) {
        if (off>h->sizeofcmds || h->sizeofcmds-off<sizeof(struct load_command)) return 0;
        const struct load_command *c=(const struct load_command *)(cmds+off);
        if (c->cmdsize<sizeof(struct load_command) || c->cmdsize>h->sizeofcmds-off) return 0;
        if (c->cmd==LC_SEGMENT_64 && c->cmdsize>=sizeof(struct segment_command_64)) {
            const struct segment_command_64 *s=(const struct segment_command_64 *)c;
            if ((s->initprot & VM_PROT_READ) && (s->initprot & VM_PROT_WRITE) &&
                address >= s->vmaddr && size<=s->vmsize && address-s->vmaddr<=s->vmsize-size)
                return 1;
        }
        off+=c->cmdsize;
    }
    return 0;
}

static int validate_image(const struct mach_header_64 *h) {
    if (!h || h->magic!=MH_MAGIC_64 || h->filetype!=MH_EXECUTE ||
        h->cputype!=CPU_TYPE_ARM64 || h->ncmds>512 || h->sizeofcmds>1024*1024)
        return 0;
    size_t off=0;
    const uint8_t *cmds=(const uint8_t *)(h+1);
    int uuid_ok=0;
    for (uint32_t i=0;i<h->ncmds;i++) {
        if (off>h->sizeofcmds || h->sizeofcmds-off<sizeof(struct load_command)) return 0;
        const struct load_command *c=(const struct load_command *)(cmds+off);
        if (c->cmdsize<sizeof(struct load_command) || c->cmdsize>h->sizeofcmds-off) return 0;
        if (c->cmd==LC_UUID && c->cmdsize>=sizeof(struct uuid_command)) {
            const struct uuid_command *u=(const struct uuid_command *)c;
            uuid_ok=(memcmp(u->uuid,kUuid,sizeof(kUuid))==0);
        }
        off+=c->cmdsize;
    }
    if (!uuid_ok) return 0;
    return address_in_rw_data(h,V12_JOB,4) && address_in_rw_data(h,V12_SHIFT,1) &&
           address_in_rw_data(h,V12_ONLINE_MODE,4) &&
           address_in_rw_data(h,V12_SESSION_STARTED,1) &&
           address_in_rw_data(h,V12_JOB_PLAYERS_RAW,4) &&
           address_in_rw_data(h,V12_WAS_IN_GAME,1) &&
           address_in_rw_data(h,V12_P2P_JOINING,1) &&
           address_in_rw_data(h,V12_TAG_PED_RAW,PRP_SLOTS * sizeof(int32_t)) &&
           address_in_rw_data(h,V12_BLIP_RAW,PRP_SLOTS * sizeof(int32_t));
}

static int resolve_addresses(void) {
    uint32_t n=_dyld_image_count();
    for (uint32_t i=0;i<n;i++) {
        const char *name=_dyld_get_image_name(i);
        if (!name) continue;
        const char *base=strrchr(name,'/');
        if (strcmp(base?base+1:name,"GTA5")!=0) continue;
        const struct mach_header_64 *h=(const struct mach_header_64 *)_dyld_get_image_header(i);
        if (!validate_image(h)) return 0;
        intptr_t slide=_dyld_get_image_vmaddr_slide(i);
#define RESOLVE(addr,T) ((const T *)((uintptr_t)(addr)+(uintptr_t)slide))
        gJob=RESOLVE(V12_JOB,int32_t);
        gShift=RESOLVE(V12_SHIFT,uint8_t);
        gMode=RESOLVE(V12_ONLINE_MODE,int32_t);
        gSessionStarted=RESOLVE(V12_SESSION_STARTED,uint8_t);
        gJobPlayers=RESOLVE(V12_JOB_PLAYERS_RAW,uint32_t);
        gWasInGame=RESOLVE(V12_WAS_IN_GAME,uint8_t);
        gP2pJoining=RESOLVE(V12_P2P_JOINING,uint8_t);
        gTagPed=RESOLVE(V12_TAG_PED_RAW,int32_t);
        gBlip=RESOLVE(V12_BLIP_RAW,int32_t);
#undef RESOLVE
        return 1;
    }
    return 0;
}

/* Non-cryptographic change marker; never used for authorization. */
static uint32_t signature(int32_t job,uint8_t shift,int32_t mode,uint8_t started,
                          uint32_t players,uint8_t ingame,uint8_t joining,
                          uint32_t tagPos,uint32_t tagNeg,uint32_t blipPos) {
    uint32_t h=2166136261u;
#define MIX(v) do { h^=(uint32_t)(v); h*=16777619u; } while(0)
    MIX(job);MIX(shift);MIX(mode);MIX(started);MIX(players);MIX(ingame);MIX(joining);MIX(tagPos);MIX(tagNeg);MIX(blipPos);
#undef MIX
    return h;
}

static void tick(void *ctx) {
    (void)ctx;
    if (!gJob || !gShift || !gMode || !gSessionStarted || !gJobPlayers ||
        !gWasInGame || !gP2pJoining || !gTagPed || !gBlip) return;
    gTicks++;
    int32_t job=__atomic_load_n(gJob,__ATOMIC_RELAXED);
    uint8_t shift=__atomic_load_n(gShift,__ATOMIC_RELAXED);
    int32_t mode=__atomic_load_n(gMode,__ATOMIC_RELAXED);
    uint8_t started=__atomic_load_n(gSessionStarted,__ATOMIC_RELAXED);
    uint32_t players=__atomic_load_n(gJobPlayers,__ATOMIC_RELAXED);
    uint8_t was=__atomic_load_n(gWasInGame,__ATOMIC_RELAXED);
    uint8_t joining=__atomic_load_n(gP2pJoining,__ATOMIC_RELAXED);
    /* We do NOT infer the player count, remote identity, or host from these fields. */
    if (job < -1 || job > 64 || shift > 1 || started > 1 || was > 1 || joining > 1) {
        if (gTicks==1 || gTicks%PRP_HEARTBEAT_SEC==0)
            write_log("[PRP_ROSTER_V17] invalid_snapshot=1 observe_only=1",0);
        return;
    }
    /* Handles/markers can be 0 or negative sentinels. Positive values are
     * observed without dereferencing them or treating them as network IDs. */
    uint32_t tagPos=0, tagNeg=0, blipPos=0;
    for (unsigned i=0;i<PRP_SLOTS;i++) {
        int32_t tag=__atomic_load_n(gTagPed+i,__ATOMIC_RELAXED);
        int32_t blip=__atomic_load_n(gBlip+i,__ATOMIC_RELAXED);
        if (tag>0) tagPos|=UINT32_C(1)<<i;
        else if (tag<0) tagNeg|=UINT32_C(1)<<i;
        if (blip>0) blipPos|=UINT32_C(1)<<i;
    }
    uint32_t sig=signature(job,shift,mode,started,players,was,joining,
                           tagPos,tagNeg,blipPos);
    if (!gHavePrev || sig!=gLastSig || gTicks%PRP_HEARTBEAT_SEC==0) {
        char line[450];
        int active=(job<=2 && job>=0 && shift==1);
        snprintf(line,sizeof(line),
            "[PRP_ROSTER_V17] tick=%u job=%d shift=%u police_active=%d online_mode_raw=%d "
            "session_started_raw=%u was_in_game_raw=%u p2p_joining_raw=%u job_players_raw=%u "
            "tag_positive_mask=%08x tag_negative_mask=%08x blip_positive_mask=%08x "
            "tag_positive_slots=%u blip_positive_slots=%u "
            "roster_verified=0 remote_id_verified=0 player_count_verified=0 hooks=0 network_events=0",
            gTicks,job,shift,active,mode,(unsigned)started,(unsigned)was,(unsigned)joining,players,
            tagPos,tagNeg,blipPos,(unsigned)__builtin_popcount(tagPos),
            (unsigned)__builtin_popcount(blipPos));
        write_log(line,0);
        gLastSig=sig;
        gHavePrev=1;
    }
}

__attribute__((constructor))
static void start_probe(void) {
    int verified=resolve_addresses();
    char header[220];
    snprintf(header,sizeof(header),
       "[PRP_DIAG_V17] dylib_loaded=1 gta5_uuid_verified=%d hooks=0 "
       "network_events=0 police_gameplay=0 timer=main_queue_1s",verified);
    write_log(header,1);
    if (!verified) return;
    gTimer=dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER,0,0,dispatch_get_main_queue());
    if (!gTimer) { write_log("[PRP_ROSTER_V17] timer_create_failed=1",0); return; }
    dispatch_source_set_event_handler_f(gTimer,tick);
    dispatch_source_set_timer(gTimer,dispatch_time(DISPATCH_TIME_NOW,1*NSEC_PER_SEC),
                              NSEC_PER_SEC,100*NSEC_PER_MSEC);
    dispatch_resume(gTimer);
}
