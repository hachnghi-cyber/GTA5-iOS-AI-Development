# GTA V iOS v12 – Police RP ONLY v1.7 (chỉ đọc, không tác động game)

Mục tiêu: kiểm tra các vùng dữ liệu **32 ô** liên quan biểu tượng và thẻ hiển thị nhân vật trong Online, so sánh lúc vào phòng một người và phòng có thêm người.

## Kết quả xác nhận trước đó
- v1.5 trên iPhone: nhận ca và kết thúc ca được nhận diện.
- v1.6 trên iPhone: `online_mode_raw=3`, `session_started_raw=1`, `job=0 shift=1` trong phòng Online.
- **v1.6 không xác nhận Player ID hoặc số người**: `remote_id_verified=0`, `player_count_verified=0`.

## v1.7 bổ sung
- Đọc `s_aiTagPed` (32 số nguyên) và `s_aiBlip` (32 số nguyên) của **chính GTA5 v12** từ bộ nhớ chỉ-đọc.
- Ghi số **ô có giá trị dương** và mặt nạ bit ô khác không. Ghi ô âm riêng vì có thể là sentinel.
- **Các ô này KHÔNG được coi là Player ID, Ped handle hợp lệ, số người trong phòng, hay mục tiêu còng tay.** Biểu tượng có thể không hiện khi người chơi ở xa hoặc chưa spawn.
- Giữ cả 7 trạng thái của v1.6 để đối chiếu.
- Không gọi RAGE, không hook, không gửi mạng, không ghi bộ nhớ game, không bật Menyoo hoặc các mod trong Online.

## Cách dùng trên iPhone
1. Đưa `PoliceRP_v17_Source.zip` lên thư mục gốc repo; đặt workflow `build-prp-v17-roster-ios.yml` trong `.github/workflows/` (xem file riêng `import-police-rp-v17-IPHONE.yml`).
2. GitHub → Actions → **Police RP v1.7 - Build visual roster OBSERVE ONLY** → Run workflow.
3. Gửi artifact `PRP-v17-iPhone-ARM64-ROSTER-OBSERVE-ONLY.zip` để ghép vào bản sao IPA v12 bằng công cụ đã kiểm chứng từ v1.6. **Chưa ghép IPA trong gói này.**
4. Sau khi ký cài bản chẩn đoán: thử Story Mode → Online chỉ 1 người → thêm người → người kia rời → thoát Online.
5. Vào Files → GTA V → Documents → `PoliceRPRoster-v17.txt`. Chạy `python3 Tools/check_roster_v17.py PoliceRPRoster-v17.txt` để xem chuyển trạng thái.

**Không cần người khác cài probe.** Chưa có bất kỳ tính năng bắt giữ người Online nào. Nếu không thấy thay đổi mặt nạ thì chưa thể kết luận game thiếu người chơi.

## Yêu cầu tương thích
GTA5 SHA-256 `d252115585d8f81987fa88138e89e190d42a7ca8134421f0a5f639af27c8585b`, UUID `6a498e32-e70c-334c-bca3-affd35e8d171`, iOS >=16.3. Thư viện không áp dụng cho các bản khác.
