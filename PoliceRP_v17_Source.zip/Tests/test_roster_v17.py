import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'Tools'))
from check_roster_v17 import analyze
H='[PRP_DIAG_V17] dylib_loaded=1 gta5_uuid_verified=1 hooks=0 network_events=0 police_gameplay=0 timer=main_queue_1s\n'
def s(t,job=-1,shift=0,online=-1,session=0,join=0,tag=0,neg=0,blip=0,active=None):
    if active is None:active=int(job in (0,1,2) and shift==1)
    return (f'[PRP_ROSTER_V17] tick={t} job={job} shift={shift} police_active={active} '
            f'online_mode_raw={online} session_started_raw={session} was_in_game_raw=0 '
            f'p2p_joining_raw={join} job_players_raw=0 '
            f'tag_positive_mask={tag:08x} tag_negative_mask={neg:08x} blip_positive_mask={blip:08x} '
            f'tag_positive_slots={tag.bit_count()} blip_positive_slots={blip.bit_count()} '
            'roster_verified=0 remote_id_verified=0 player_count_verified=0 hooks=0 network_events=0\n')
class TestRoster(unittest.TestCase):
    def test_no_header(self):self.assertEqual(analyze(s(1))['status'],'LIBRARY_NOT_VERIFIED')
    def test_uuid_bad(self):self.assertEqual(analyze(H.replace('verified=1','verified=0')+s(1))['status'],'LIBRARY_NOT_VERIFIED')
    def test_header_only(self):self.assertEqual(analyze(H)['status'],'TIMER_NO_SAMPLES')
    def test_static(self):self.assertEqual(analyze(H+s(1)+s(21))['status'],'SAMPLES_OK_NO_CHANGE')
    def test_2_to_3_slot_transition(self):
        r=analyze(H+s(1,online=3,session=1,tag=0b11)+s(2,online=3,session=1,tag=0b111))
        self.assertEqual(r['status'],'SLOT_MASK_TRANSITION_OBSERVED')
        self.assertTrue(r['transitions']['tag_slots_changed'])
        self.assertFalse(r['verified_remote_player_ids'])
    def test_blip_transition(self):self.assertTrue(analyze(H+s(1)+s(2,blip=1))['transitions']['blip_slots_changed'])
    def test_only_session_transition(self):self.assertEqual(analyze(H+s(1)+s(2,online=3,session=1))['status'],'STATE_CHANGE_OBSERVED')
    def test_duty_transition(self):self.assertTrue(analyze(H+s(1)+s(2,job=0,shift=1))['transitions']['police_duty_changed'])
    def test_negative_sentinel(self):self.assertEqual(analyze(H+s(1,neg=0xffffffff))['last']['tag_negative_mask'],0xffffffff)
    def test_overlap(self):self.assertEqual(analyze(H+s(1,neg=1,tag=1))['status'],'BAD_SAMPLE')
    def test_bad_active(self):self.assertEqual(analyze(H+s(1,job=0,shift=1,active=0))['status'],'BAD_SAMPLE')
    def test_count_bad(self):self.assertEqual(analyze(H+s(1,tag=3).replace('tag_positive_slots=2','tag_positive_slots=1'))['status'],'BAD_SAMPLE')
    def test_tick_repeat(self):self.assertEqual(analyze(H+s(1)+s(1,tag=2))['status'],'TICK_NOT_INCREASING')
    def test_reject_identity_claim(self):self.assertEqual(analyze(H+s(1).replace('remote_id_verified=0','remote_id_verified=1'))['status'],'MALFORMED_SAMPLE')
    def test_corrupted_hex(self):self.assertEqual(analyze(H+s(1).replace('tag_positive_mask=00000000','tag_positive_mask=!!!!!!!0'))['status'],'MALFORMED_SAMPLE')
    def test_invalid_snapshot(self):self.assertEqual(analyze(H+'[PRP_ROSTER_V17] invalid_snapshot=1 observe_only=1\n')['status'],'INVALID_SNAPSHOT')
    def test_ignore_noise(self):self.assertEqual(analyze(H+'noise\n'+s(1))['samples'],1)
if __name__=='__main__':unittest.main()
