#!/usr/bin/env python3
"""Analyze v1.7 read-only GTA visual tag/blip slot probe. These are NOT player IDs."""
import argparse
import json
import re
from pathlib import Path

HEADER = re.compile(r'^\[PRP_DIAG_V17\] dylib_loaded=1 gta5_uuid_verified=([01]) hooks=0 network_events=0 police_gameplay=0 timer=main_queue_1s$')
DATA = re.compile(
    r'^\[PRP_ROSTER_V17\] tick=(\d+) job=(-?\d+) shift=([01]) police_active=([01]) '
    r'online_mode_raw=(-?\d+) session_started_raw=([01]) was_in_game_raw=([01]) '
    r'p2p_joining_raw=([01]) job_players_raw=(\d+) '
    r'tag_positive_mask=([0-9a-f]{8}) tag_negative_mask=([0-9a-f]{8}) '
    r'blip_positive_mask=([0-9a-f]{8}) tag_positive_slots=(\d+) blip_positive_slots=(\d+) '
    r'roster_verified=0 remote_id_verified=0 player_count_verified=0 hooks=0 network_events=0$'
)
KEYS = ('tick','job','shift','police_active','online_mode_raw','session_started_raw',
        'was_in_game_raw','p2p_joining_raw','job_players_raw',
        'tag_positive_mask','tag_negative_mask','blip_positive_mask',
        'tag_positive_slots','blip_positive_slots')


def analyze(blob: str) -> dict:
    lines=[s.strip() for s in blob.splitlines() if s.strip()]
    headers=[m for s in lines if (m:=HEADER.fullmatch(s))]
    if not headers or headers[-1].group(1)!='1':
        return {'status':'LIBRARY_NOT_VERIFIED','samples':0}
    samples=[]
    for line in lines:
        if line.startswith('[PRP_ROSTER_V17] invalid_snapshot=1'):
            return {'status':'INVALID_SNAPSHOT','samples':len(samples)}
        if not line.startswith('[PRP_ROSTER_V17] tick='):
            continue
        m=DATA.fullmatch(line)
        if not m:
            return {'status':'MALFORMED_SAMPLE','samples':len(samples)}
        vals=[]
        for k,v in zip(KEYS,m.groups()):
            vals.append(int(v,16) if k.endswith('_mask') else int(v))
        s=dict(zip(KEYS,vals))
        invalid=(s['tick']<1 or s['tick']>10000000 or not -1<=s['job']<=64
                 or s['police_active']!=int(0<=s['job']<=2 and s['shift']==1)
                 or (s['tag_positive_mask'] & s['tag_negative_mask'])!=0
                 or s['tag_positive_slots']!=s['tag_positive_mask'].bit_count()
                 or s['blip_positive_slots']!=s['blip_positive_mask'].bit_count())
        if invalid: return {'status':'BAD_SAMPLE','samples':len(samples)}
        if samples and s['tick']<=samples[-1]['tick']:
            return {'status':'TICK_NOT_INCREASING','samples':len(samples)}
        samples.append(s)
    if not samples: return {'status':'TIMER_NO_SAMPLES','samples':0}
    pairs=list(zip(samples,samples[1:]))
    changed=lambda k:any(a[k]!=b[k] for a,b in pairs)
    changes={
        'online_mode_changed':changed('online_mode_raw'),
        'session_started_changed':changed('session_started_raw'),
        'joining_changed':changed('p2p_joining_raw'),
        'police_duty_changed':changed('police_active'),
        'tag_slots_changed':changed('tag_positive_mask'),
        'blip_slots_changed':changed('blip_positive_mask'),
        'negative_sentinel_changed':changed('tag_negative_mask'),
    }
    return {
        'status': 'SLOT_MASK_TRANSITION_OBSERVED' if (changes['tag_slots_changed'] or changes['blip_slots_changed'])
                  else 'STATE_CHANGE_OBSERVED' if any(changes.values()) else 'SAMPLES_OK_NO_CHANGE',
        'samples':len(samples), 'first':samples[0], 'last':samples[-1],
        'transitions':changes,
        'verified_remote_player_ids':False,
        'verified_player_count':False,
        'verified_arrest_targets':False,
        'warning':'These masks represent game-managed visual-tag/blip slots, not a validated network roster. Never use as remote Player IDs.'
    }

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('log',type=Path)
    args=p.parse_args()
    print(json.dumps(analyze(args.log.read_text('utf-8',errors='replace')),indent=2,ensure_ascii=False))
