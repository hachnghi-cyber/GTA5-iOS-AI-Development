#!/usr/bin/env python3
"""Read-only gate for exactly GTA V iOS v12. Reads no user data and patches nothing."""
import argparse
import hashlib
import json
import struct
import zipfile
from pathlib import Path

EXPECTED_SHA='d252115585d8f81987fa88138e89e190d42a7ca8134421f0a5f639af27c8585b'
EXPECTED_UUID='6a498e32e70c334cbca3affd35e8d171'
EXPECTED={'job':(0x1027B1B2C,4),'shift':(0x10355EE34,1),
          'mode':(0x1027B1AE8,4),'session':(0x10355577D,1),
          'job_players_unverified':(0x103555794,4),'was_in_game':(0x1035501FC,1),
          'p2p_joining':(0x103550204,1),
          'tag_ped_32x4':(0x10356504C,128),'blip_32x4':(0x1035650CC,128)}

def verify(data:bytes)->dict:
    sha=hashlib.sha256(data).hexdigest()
    if sha!=EXPECTED_SHA:
        return {'ok':False,'reason':'SHA256_MISMATCH','sha256':sha}
    if len(data)<32 or struct.unpack_from('<I',data)[0]!=0xfeedfacf:
        return {'ok':False,'reason':'NOT_MACHO64'}
    _,cpu,_,kind,ncmds,szcmds,_,_=struct.unpack_from('<8I',data)
    if cpu!=0x100000c or kind!=2 or ncmds>512 or 32+szcmds>len(data):
        return {'ok':False,'reason':'BAD_MACHO_HEADER'}
    off=32; uuid=None; segments=[]
    for _ in range(ncmds):
        cmd,cmdsz=struct.unpack_from('<II',data,off)
        if cmdsz<8 or off+cmdsz>32+szcmds:
            return {'ok':False,'reason':'BAD_LOAD_COMMAND'}
        if cmd==0x1b and cmdsz>=24:uuid=data[off+8:off+24].hex()
        if cmd==0x19 and cmdsz>=72:
            name=data[off+8:off+24].split(b'\x00')[0].decode('ascii','replace')
            vmaddr,vmsize=struct.unpack_from('<QQ',data,off+24)
            maxprot,initprot=struct.unpack_from('<II',data,off+56)
            segments.append({'name':name,'addr':vmaddr,'size':vmsize,'prot':initprot})
        off+=cmdsz
    if uuid!=EXPECTED_UUID:
        return {'ok':False,'reason':'UUID_MISMATCH','uuid':uuid}
    for key,(addr,size) in EXPECTED.items():
        if not any((seg['prot']&3)==3 and addr>=seg['addr'] and
                   addr+size<=seg['addr']+seg['size'] for seg in segments):
            return {'ok':False,'reason':'UNMAPPED_OR_NONWRITABLE','variable':key}
    return {'ok':True,'gta5_sha256':sha,'gta5_uuid':uuid,
            'variables_checked':len(EXPECTED),
            'tag_array_span':'0x10356504c..0x1035650cb',
            'blip_array_span':'0x1035650cc..0x10356514b',
            'static_semantics':'Visual tag/blip slot arrays only, not proven player IDs or counts',
            'gameplay_hooks':False,'network_operations':False}

def main():
    p=argparse.ArgumentParser()
    p.add_argument('gta5_or_ipa',type=Path)
    a=p.parse_args()
    if a.gta5_or_ipa.suffix.lower()=='.ipa':
        with zipfile.ZipFile(a.gta5_or_ipa) as z:
            names=[name for name in z.namelist() if name.endswith('.app/GTA5')]
            if len(names)!=1:raise SystemExit('Expected exactly one GTA5 binary')
            data=z.read(names[0])
    else:data=a.gta5_or_ipa.read_bytes()
    r=verify(data)
    print(json.dumps(r,ensure_ascii=False,indent=2))
    if not r['ok']:raise SystemExit(1)
if __name__=='__main__':main()
