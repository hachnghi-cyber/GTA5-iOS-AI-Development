#include "rp.h"
#include <math.h>
#include <string.h>
#include <limits.h>
static uint32_t get32(const uint8_t *p){return (uint32_t)p[0]|(uint32_t)p[1]<<8|(uint32_t)p[2]<<16|(uint32_t)p[3]<<24;}
static uint64_t get64(const uint8_t *p){return get32(p)|(uint64_t)get32(p+4)<<32;}
static void put32(uint8_t*p,uint32_t v){for(int i=0;i<4;i++)p[i]=(uint8_t)(v>>(8*i));}
static void put64(uint8_t*p,uint64_t v){put32(p,(uint32_t)v);put32(p+4,(uint32_t)(v>>32));}
static uint64_t later(uint64_t a,uint64_t b){return UINT64_MAX-a<b?UINT64_MAX:a+b;}
static void change(rp_host*h,rp_player*p){if(p->revision<UINT32_MAX)p->revision++;p->changed_ms=h->now_ms;}
static void release(rp_host*h,rp_player*p){p->state=RP_FREE;p->owner=RP_NONE;p->until_ms=0;p->surrender=false;change(h,p);}
void rp_host_init(rp_host*h,uint64_t e){memset(h,0,sizeof *h);h->epoch=e;for(int i=0;i<RP_MAX;i++)h->p[i].owner=RP_NONE;}
void rp_leave(rp_host*h,uint8_t s){
 if(s>=RP_MAX)return;
 uint32_t generation=h->p[s].generation;
 for(int i=0;i<RP_MAX;i++)if(h->p[i].joined&&h->p[i].owner==s)release(h,&h->p[i]);
 memset(&h->p[s],0,sizeof h->p[s]);h->p[s].generation=generation;h->p[s].owner=RP_NONE;
}
bool rp_join(rp_host*h,uint8_t s,uint32_t g,bool consent){
 if(!h->epoch||s>=RP_MAX||!g||g<=h->p[s].generation)return false;
 rp_leave(h,s);rp_player*p=&h->p[s];p->joined=true;p->consent=consent;p->generation=g;p->revision=1;return true;
}
void rp_tick(rp_host*h,uint64_t now){
 if(now<h->now_ms)return;
 h->now_ms=now;
 for(int i=0;i<RP_MAX;i++){
  rp_player*p=&h->p[i];if(!p->joined)continue;
  bool stale=!p->observed||now-p->observed_ms>1000;
  bool owner_bad=p->owner<RP_MAX&&(!h->p[p->owner].joined||h->p[p->owner].role!=RP_POLICE||!h->p[p->owner].observed||now-h->p[p->owner].observed_ms>1000||!h->p[p->owner].obs.alive);
  if(p->state!=RP_FREE&&(stale||!p->obs.alive||owner_bad||(p->until_ms&&now>=p->until_ms)))release(h,p);
 }
}
bool rp_observe(rp_host*h,uint8_t s,rp_role role,rp_observation o){
 if(s>=RP_MAX||!h->p[s].joined||role>RP_EMS||role<RP_CIV||!isfinite(o.x)||!isfinite(o.y)||!isfinite(o.z)||fabsf(o.x)>100000||fabsf(o.y)>100000||fabsf(o.z)>100000)return false;
 rp_player*p=&h->p[s];p->obs=o;p->observed=true;p->observed_ms=h->now_ms;p->role=(uint8_t)role;
 if(role!=RP_POLICE)for(int i=0;i<RP_MAX;i++)if(h->p[i].joined&&h->p[i].owner==s)release(h,&h->p[i]);
 if(!o.alive&&(p->state!=RP_FREE||p->surrender))release(h,p);
 return true;
}
bool rp_encode(const rp_request*r,uint8_t b[RP_WIRE]){
 if(!r||!b||r->action<RP_SURRENDER||r->action>RP_REVIVE||r->actor>=RP_MAX||r->target>=RP_MAX)return false;
 memset(b,0,RP_WIRE);memcpy(b,"RP13",4);b[4]=1;b[5]=r->action;b[6]=r->actor;b[7]=r->target;
 put64(b+8,r->epoch);put32(b+16,r->actor_generation);put32(b+20,r->target_generation);put32(b+24,r->seq);put32(b+28,r->arg);return true;
}
bool rp_decode(const uint8_t*b,size_t n,rp_request*r){
 if(!b||!r||n!=RP_WIRE||memcmp(b,"RP13",4)||b[4]!=1||b[5]<RP_SURRENDER||b[5]>RP_REVIVE||b[6]>=RP_MAX||b[7]>=RP_MAX||get64(b+32))return false;
 *r=(rp_request){b[5],b[6],b[7],get32(b+16),get32(b+20),get32(b+24),get32(b+28),get64(b+8)};return true;
}
rp_result rp_handle(rp_host*h,uint8_t peer,const uint8_t*b,size_t n){
 rp_request r;if(!rp_decode(b,n,&r))return RP_BAD_WIRE;
 if(!h->epoch||r.epoch!=h->epoch)return RP_SESSION;
 if(peer!=r.actor)return RP_IDENTITY;
 rp_player*a=&h->p[r.actor],*t=&h->p[r.target];
 if(!a->joined||!t->joined||!a->consent||!t->consent||a->generation!=r.actor_generation||t->generation!=r.target_generation)return RP_IDENTITY;
 if(!r.seq||r.seq<=a->seq)return RP_REPLAY;
 a->seq=r.seq; /* Consume even rejected commands: replay cannot become valid later. */
 if(!a->observed||!t->observed||h->now_ms-a->observed_ms>1000||h->now_ms-t->observed_ms>1000)return RP_STALE;
 if(h->now_ms<a->next_action_ms)return RP_RATE;
 if(!a->obs.alive||a->state!=RP_FREE)return RP_PERMISSION;
 if((r.action==RP_SURRENDER&&r.arg>1)||(r.action!=RP_SURRENDER&&r.action!=RP_JAIL&&r.arg))return RP_BAD_WIRE;
 if(r.action==RP_SURRENDER){
  if(r.actor!=r.target)return RP_PERMISSION;
  a->surrender=r.arg!=0;change(h,a);a->next_action_ms=later(h->now_ms,250);return RP_OK;
 }
 if(r.actor==r.target)return RP_PERMISSION;
 if(a->obs.in_vehicle||t->obs.in_vehicle)return RP_PERMISSION;
 double dx=(double)a->obs.x-t->obs.x,dy=(double)a->obs.y-t->obs.y,dz=(double)a->obs.z-t->obs.z;
 if(dx*dx+dy*dy+dz*dz>9.0)return RP_RANGE;
 if(r.action==RP_REVIVE){
  /* This is an accepted intent; game adapter MUST re-observe actual life state.
     No resurrection or health write is performed by this portable core. */
  if(a->role!=RP_EMS||t->obs.alive)return RP_PERMISSION;
  release(h,t);a->next_action_ms=later(h->now_ms,1000);return RP_OK;
 }
 if(a->role!=RP_POLICE||!t->obs.alive)return RP_PERMISSION;
 switch(r.action){
 case RP_CUFF:
  if(t->state!=RP_FREE||!t->surrender)return RP_TRANSITION;
  t->state=RP_CUFFED;t->owner=r.actor;t->until_ms=later(h->now_ms,120000);break;
 case RP_UNCUFF:
  if(t->state==RP_FREE||t->owner!=r.actor)return RP_TRANSITION;
  release(h,t);a->next_action_ms=later(h->now_ms,250);return RP_OK;
 case RP_ESCORT:
  if(t->state!=RP_CUFFED||t->owner!=r.actor)return RP_TRANSITION;
  t->state=RP_ESCORTED;break;
 case RP_STOP_ESCORT:
  if(t->state!=RP_ESCORTED||t->owner!=r.actor)return RP_TRANSITION;
  t->state=RP_CUFFED;break;
 case RP_JAIL:
  if(t->state!=RP_ESCORTED||t->owner!=r.actor||!a->obs.jail_zone||!t->obs.jail_zone||r.arg<1||r.arg>120)return RP_TRANSITION;
  t->state=RP_JAILED;t->owner=RP_NONE;t->until_ms=later(h->now_ms,(uint64_t)r.arg*1000);break;
 default:return RP_BAD_WIRE;
 }
 change(h,t);a->next_action_ms=later(h->now_ms,250);return RP_OK;
}
bool rp_snapshot(rp_host*h,uint8_t s,uint8_t b[RP_WIRE]){
 if(s>=RP_MAX||!h->p[s].joined||!h->p[s].consent||h->snapshot_seq==UINT64_MAX)return false;
 const rp_player*p=&h->p[s];memset(b,0,RP_WIRE);memcpy(b,"RS13",4);b[4]=2;b[5]=p->state;b[6]=s;b[7]=p->owner;
 put64(b+8,h->epoch);put32(b+16,p->generation);put32(b+20,p->revision);put32(b+24,p->owner<RP_MAX?h->p[p->owner].generation:0);b[28]=p->surrender;put64(b+32,++h->snapshot_seq);return true;
}
void rp_client_init(rp_client*c,uint64_t e,uint8_t s,uint32_t g){memset(c,0,sizeof *c);c->epoch=e;c->slot=s;c->generation=g;c->owner=RP_NONE;}
bool rp_client_apply(rp_client*c,bool host,const uint8_t*b,size_t n,uint64_t now){
 if(!host||!b||n!=RP_WIRE||memcmp(b,"RS13",4)||b[4]!=2||b[5]>RP_JAILED||b[6]!=c->slot||get64(b+8)!=c->epoch||!c->epoch||get32(b+16)!=c->generation||!get32(b+20)||get32(b+20)<c->revision||b[28]>1)return false;
 for(int i=29;i<32;i++)if(b[i])return false;
 if(get64(b+32)<=c->snapshot_seq)return false;
 if((b[5]==RP_CUFFED||b[5]==RP_ESCORTED)?(b[7]>=RP_MAX||b[7]==c->slot||!get32(b+24)):(b[7]!=RP_NONE||get32(b+24)))return false;
 /* Equal revision snapshots may refresh only identical state. A strictly increasing snapshot serial rejects old transport envelopes. */
 if(c->valid&&c->revision==get32(b+20)&&(c->state!=b[5]||c->owner!=b[7]||c->owner_generation!=get32(b+24)||c->surrender!=(b[28]!=0)))return false;
 c->snapshot_seq=get64(b+32);c->revision=get32(b+20);c->state=b[5];c->owner=b[7];c->owner_generation=get32(b+24);c->surrender=b[28]!=0;c->valid=true;c->expires_ms=later(now,RP_LEASE_MS);return true;
}
void rp_client_tick(rp_client*c,uint64_t now){if(c->valid&&now>=c->expires_ms){c->valid=false;c->state=RP_FREE;c->owner=RP_NONE;c->owner_generation=0;c->surrender=false;}}
