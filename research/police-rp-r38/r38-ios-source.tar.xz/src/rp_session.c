#include "rp_session.h"
#include <string.h>
static bool same(rp_session_identity a,rp_session_identity b) {
 return a.session_id==b.session_id && a.host_peer==b.host_peer && a.local_peer==b.local_peer;
}
static bool once(rp_read_memory read,void *ctx,uintptr_t p,rp_session_identity *s) {
 uint32_t state;
 /* snSession embeds rlSession at +168. GetId reads rlSession+1312;
    IsEstablished tests (u32[+8] & ~1)==2. Local rlPeerInfo is +3144
    and GetPeerId reads +464. Host is snSession+3920. */
 return read(ctx,p+176,&state,4) && (state&~UINT32_C(1))==2 &&
   read(ctx,p+1480,&s->session_id,8) && read(ctx,p+3920,&s->host_peer,8) &&
   read(ctx,p+3608,&s->local_peer,8) && s->session_id!=0 &&
   s->session_id!=UINT64_MAX && s->host_peer!=UINT64_MAX && s->local_peer!=UINT64_MAX;
}
bool rp_session_read_v13(rp_read_memory read,void *ctx,uintptr_t p,rp_session_identity *out) {
 rp_session_identity a={0},b={0};
 if(out) memset(out,0,sizeof *out);
 if(!read || !out || !p || (p&7u) || p>UINTPTR_MAX-3928) return false;
 if(!once(read,ctx,p,&a) || !once(read,ctx,p,&b) || !same(a,b)) return false;
 *out=b;return true;
}
bool rp_session_pin(rp_session_guard *g,rp_read_memory read,void *ctx,uintptr_t p) {
 if(!g)return false;
 memset(g,0,sizeof *g);
 if(!rp_session_read_v13(read,ctx,p,&g->identity))return false;
 g->address=p;g->pinned=true;return true;
}
bool rp_session_audit(rp_session_guard *g,rp_read_memory read,void *ctx,uintptr_t p,rp_lifecycle *life) {
 rp_session_identity now;
 if(g && g->pinned && g->address==p && rp_session_read_v13(read,ctx,p,&now) && same(g->identity,now))return true;
 if(g)g->pinned=false;
 rp_lifecycle_stop(life,RP_LIFE_PROVENANCE_LOST);
 return false;
}
