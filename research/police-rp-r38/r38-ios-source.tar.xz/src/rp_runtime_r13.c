#include "rp_runtime_r13.h"
#include <string.h>

static bool same(rp_engine_peer a,rp_engine_peer b) {
    return a.verified && b.verified && a.slot==b.slot &&
           a.generation==b.generation && a.epoch==b.epoch;
}
static bool valid(const rp_runtime_r13 *r) {
    return r && r->armed && r->runtime.active &&
           !r->runtime.quarantined && r->runtime.engine_pinned;
}
static bool thread_ok(const rp_runtime_r13 *r) {
    return r && r->provider.on_game_thread &&
           r->provider.on_game_thread(r->provider.context);
}
void rp_r13_stop(rp_runtime_r13 *r) {
    if(!r)return;
    if(r->armed)++r->sessions_stopped;
    r->armed=false;
    rp_r12_stop(&r->runtime);
}
static bool reject(rp_runtime_r13 *r) {
    if(r){++r->rejected;rp_r13_stop(r);}
    return false;
}
static bool peer_from_engine(rp_runtime_r13 *r,uintptr_t player,
                              rp_engine_peer *peer,bool *consent,uint64_t *peer_id) {
    if(!r || !player || !r->provider.resolve || !r->provider.read ||
       !peer || !consent || !peer_id)return false;
    memset(peer,0,sizeof *peer);*consent=false;*peer_id=UINT64_MAX;
    if(!r->provider.resolve(r->provider.context,player,peer,consent) ||
       !peer->verified || peer->slot>=RP_MAX || !peer->generation ||
       !peer->epoch || peer->epoch!=r->engine.fresh_epoch ||
       !r->runtime.roster.usable ||
       r->runtime.roster.snapshot.player[peer->slot]!=player ||
       !rp_peer_id_v13(r->provider.read,r->provider.context,player,
                        r->engine.gamer_info_getter,peer_id))return false;
    if(player==r->engine.local_player &&
       *peer_id!=r->runtime.session.identity.local_peer)return false;
    if(player==r->engine.host_player &&
       *peer_id!=r->runtime.session.identity.host_peer)return false;
    return true;
}
static bool audit(rp_runtime_r13 *r) {
    if(!valid(r) || !thread_ok(r))return reject(r);
    if(!rp_r12_audit_engine(&r->runtime))return reject(r);
    rp_engine_peer p;bool consent;uint64_t id;
    if(!peer_from_engine(r,r->engine.local_player,&p,&consent,&id) ||
       !same(p,r->local) || !consent ||
       !peer_from_engine(r,r->engine.host_player,&p,&consent,&id) ||
       !same(p,r->host) || !consent)return reject(r);
    return true;
}
bool rp_r13_start(rp_runtime_r13 *r,const rp_r13_provider *provider,
                  const rp_r13_engine_start *engine) {
    if(!r)return false;
    memset(r,0,sizeof *r);
    if(!provider || !engine || !provider->resolve || !provider->read ||
       !provider->on_game_thread || !provider->world ||
       !provider->is_on_duty || !provider->send ||
       !engine->manager || !engine->session || !engine->gamer_info_getter ||
       !engine->local_player || !engine->host_player || !engine->fresh_epoch)return false;
    r->provider=*provider;r->engine=*engine;
    if(!thread_ok(r))return false;
    rp_session_identity sess;rp_roster_snapshot roster;
    if(!rp_session_read_v13(provider->read,provider->context,engine->session,&sess) ||
       !rp_roster_read_v13(provider->read,provider->context,engine->manager,&roster) ||
       roster.local!=engine->local_player)return false;
    /* Pin before exposing peer_from_engine: start of R12 will re-read the same
     * session/roster and fail if either no longer matches. */
    rp_engine_peer local={0},host={0};bool local_opt=false,host_opt=false;
    uint64_t local_id=UINT64_MAX,host_id=UINT64_MAX;
    if(!provider->resolve(provider->context,engine->local_player,&local,&local_opt) ||
       !provider->resolve(provider->context,engine->host_player,&host,&host_opt) ||
       !local_opt || !host_opt || !local.verified || !host.verified ||
       local.slot>=RP_MAX || host.slot>=RP_MAX || !local.generation ||
       !host.generation || local.epoch!=engine->fresh_epoch ||
       host.epoch!=engine->fresh_epoch ||
       roster.player[local.slot]!=engine->local_player ||
       roster.player[host.slot]!=engine->host_player ||
       !rp_peer_id_v13(provider->read,provider->context,engine->local_player,
                       engine->gamer_info_getter,&local_id) ||
       !rp_peer_id_v13(provider->read,provider->context,engine->host_player,
                       engine->gamer_info_getter,&host_id) ||
       local_id!=sess.local_peer || host_id!=sess.host_peer)return false;
    bool is_host=same(local,host) && engine->local_player==engine->host_player;
    if(!rp_r12_begin(&r->runtime,local,host,is_host,provider->send,provider->context) ||
       !rp_r12_pin_engine(&r->runtime,provider->read,provider->context,
                          engine->manager,engine->session,engine->gamer_info_getter) ||
       !rp_r12_bind_player(&r->runtime,local,engine->local_player,
                           r->runtime.roster.generation[local.slot],local_id) ||
       !rp_r12_bind_player(&r->runtime,host,engine->host_player,
                           r->runtime.roster.generation[host.slot],host_id)) {
        rp_r12_stop(&r->runtime);return false;
    }
    /* Consistent source resolution was attested by the caller. This check is
     * repeated on each frame/event; never trusts the event sender field. */
    if(r->runtime.session.identity.session_id!=sess.session_id ||
       r->runtime.session.identity.host_peer!=sess.host_peer ||
       r->runtime.session.identity.local_peer!=sess.local_peer ||
       memcmp(&r->runtime.roster.snapshot,&roster,sizeof roster)!=0) {
        rp_r12_stop(&r->runtime);return false;
    }
    r->local=local;r->host=host;r->armed=true;
    if(!audit(r))return false;
    return true;
}
bool rp_r13_admit(rp_runtime_r13 *r,uintptr_t player) {
    if(!audit(r))return false;
    rp_engine_peer p;bool consent;uint64_t id;
    if(!peer_from_engine(r,player,&p,&consent,&id) || !consent)return reject(r);
    if(!rp_r12_register_peer(&r->runtime,p,true) ||
       !rp_r12_bind_player(&r->runtime,p,player,
             r->runtime.roster.generation[p.slot],id))return reject(r);
    return true;
}
bool rp_r13_observe_host(rp_runtime_r13 *r,uint8_t slot) {
    if(!audit(r))return false;
    if(!r->runtime.core.local_is_host || slot>=RP_MAX ||
       !r->runtime.peers[slot].registered)return reject(r);
    rp_role role;rp_observation obs;
    if(!r->provider.world(r->provider.context,slot,&role,&obs) ||
       !rp_r12_observe(&r->runtime,slot,role,obs))return reject(r);
    return true;
}
bool rp_r13_frame(rp_runtime_r13 *r,uint64_t now_ms) {
    if(!audit(r))return false;
    if(r->runtime.core.local_is_host) {
        for(uint8_t i=0;i<RP_MAX;++i)if(r->runtime.peers[i].registered) {
            rp_role role;rp_observation obs;
            if(!r->provider.world(r->provider.context,i,&role,&obs) ||
               !rp_r12_observe(&r->runtime,i,role,obs))return reject(r);
        }
    }
    if(!rp_r12_frame(&r->runtime,now_ms))return reject(r);
    ++r->frames;return true;
}
bool rp_r13_submit(rp_runtime_r13 *r,rp_action action,uint8_t target,
                   uint32_t generation,uint32_t arg,uint64_t now_ms) {
    if(!audit(r))return false;
    /* Only the verified on-duty police can request police actions. Civilian
     * surrender remains voluntary; all requests are rechecked by the host. */
    if(action!=RP_SURRENDER &&
       !r->provider.is_on_duty(r->provider.context,r->local.slot))return false;
    if(target>=RP_MAX || !r->runtime.peers[target].registered)return false;
    return rp_r12_action(&r->runtime,action,target,generation,arg,now_ms);
}
bool rp_r13_decide_observe(rp_runtime_r13 *r,uintptr_t event,uintptr_t player) {
    if(!audit(r))return false;
    rp_engine_peer p;bool consent;uint64_t id;
    if(!peer_from_engine(r,player,&p,&consent,&id) || !consent ||
       p.slot==r->local.slot || !r->runtime.binding_valid[p.slot]) {
        /* A known participant losing consent or transport provenance ends
         * the session. An unrelated Online sender is simply ignored, so a
         * stranger cannot force RP teardown with a non-RP event. */
        for(unsigned i=0;i<RP_MAX;++i)
            if(r->runtime.binding_valid[i] &&
               r->runtime.binding[i].player==player)
                return reject(r);
        ++r->rejected;return false;
    }
    if(!same(p,r->runtime.binding[p.slot].wire) ||
       id!=r->runtime.binding[p.slot].peer_id)return reject(r);
    /* R16: event+0x224 identifies a vanilla scripted-event kind, NOT a wire
     * length. Keep this routine for peer/lifecycle auditing but NEVER queue
     * a vanilla Decide packet as RPE3. The original GTA handler must run. */
    (void)event;
    ++r->rejected;
    return false;
}
void rp_r13_after_assignment(rp_runtime_r13 *r,uintptr_t touched) {
    if(!r || !r->armed)return;
    if(!thread_ok(r)){(void)reject(r);return;}
    rp_roster_snapshot next;
    if(!rp_roster_read_v13(r->provider.read,r->provider.context,
                           r->engine.manager,&next) ||
       !rp_roster_after_assignment(&r->runtime.roster,touched,&next)) {
        (void)reject(r);return;
    }
    /* Any touched admitted slot needs a new authorized identity handshake;
     * no silent re-use of stale peer generations / binding is allowed. */
    for(unsigned i=0;i<RP_MAX;++i)if(r->runtime.binding_valid[i] &&
       (r->runtime.binding[i].player==touched ||
        !rp_roster_matches(&r->runtime.roster,r->engine.fresh_epoch,(uint8_t)i,
            r->runtime.binding[i].player,r->runtime.binding[i].local_generation))) {
        (void)reject(r);return;
    }
}
