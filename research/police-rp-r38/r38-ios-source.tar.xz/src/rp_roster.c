#include "rp_roster.h"
#include <string.h>
#include <limits.h>
_Static_assert(sizeof(uintptr_t)==8,"v13 requires 64-bit pointers");
static bool valid(const rp_roster_snapshot *s) {
    if(!s || !s->local) return false;
    bool local=false;
    for(unsigned i=0;i<32;i++) {
        uintptr_t p=s->player[i];
        if(p && (p&7u)) return false;
        if(p==s->local) local=true;
        for(unsigned j=0;j<i;j++) if(p && p==s->player[j]) return false;
    }
    return local;
}
static bool same(const rp_roster_snapshot *a,const rp_roster_snapshot *b) {
    return a->local==b->local && !memcmp(a->player,b->player,sizeof a->player);
}
static bool read_one(rp_read_memory read,void *ctx,uintptr_t m,rp_roster_snapshot *s) {
    uint8_t init=0;
    if(!read(ctx,m+RP_V13_INITIALIZED,&init,1) || !(init&1) ||
       !read(ctx,m+RP_V13_LOCAL_PLAYER,&s->local,8) ||
       !read(ctx,m+RP_V13_PHYSICAL_TABLE,s->player,sizeof s->player) || !valid(s)) return false;
    for(unsigned i=0;i<32;i++) if(s->player[i]) {
        uint8_t index=255;
        if(s->player[i]>UINTPTR_MAX-RP_V13_PHYSICAL_INDEX ||
           !read(ctx,s->player[i]+RP_V13_PHYSICAL_INDEX,&index,1) || index!=i) return false;
    }
    return true;
}
bool rp_roster_read_v13(rp_read_memory read,void *ctx,uintptr_t manager,rp_roster_snapshot *out) {
    rp_roster_snapshot a={0},b={0};
    if(out) memset(out,0,sizeof *out);
    if(!out || !read || !manager || (manager&7u) || manager>UINTPTR_MAX-RP_V13_INITIALIZED) return false;
    if(!read_one(read,ctx,manager,&a) || !read_one(read,ctx,manager,&b) || !same(&a,&b)) return false;
    *out=b; return true;
}
void rp_roster_invalidate(rp_roster *r) { if(r) r->usable=false; }
bool rp_roster_begin(rp_roster *r,uint64_t epoch,const rp_roster_snapshot *s) {
    if(!r) return false;
    memset(r,0,sizeof *r);
    if(!epoch || !valid(s)) return false;
    r->snapshot=*s; r->epoch=epoch; r->usable=true;
    for(unsigned i=0;i<32;i++) r->generation[i]=1;
    return true;
}
bool rp_roster_after_assignment(rp_roster *r,uintptr_t touched,const rp_roster_snapshot *s) {
    if(!r || !r->usable) return false;
    if(!touched || !valid(s) || s->local!=r->snapshot.local) {r->usable=false; return false;}
    for(unsigned i=0;i<32;i++) {
        if(s->player[i]!=r->snapshot.player[i] && s->player[i]!=touched &&
           r->snapshot.player[i]!=touched) {r->usable=false; return false;}
    }
    for(unsigned i=0;i<32;i++) {
        if(s->player[i]!=r->snapshot.player[i] || s->player[i]==touched || r->snapshot.player[i]==touched) {
            if(r->generation[i]==UINT32_MAX) {r->usable=false; return false;}
            ++r->generation[i];
        }
    }
    r->snapshot=*s; return true;
}
bool rp_roster_audit(rp_roster *r,const rp_roster_snapshot *s) {
    if(!r || !r->usable) return false;
    if(!valid(s) || !same(&r->snapshot,s)) {r->usable=false; return false;}
    return true;
}
bool rp_roster_matches(const rp_roster *r,uint64_t epoch,uint8_t slot,uintptr_t player,uint32_t gen) {
    return r && r->usable && slot<32 && player && epoch==r->epoch &&
           r->snapshot.player[slot]==player && gen==r->generation[slot];
}
