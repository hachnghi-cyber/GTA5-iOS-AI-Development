#include "rp_runtime_r14.h"
#include <string.h>

static bool peer_same(rp_engine_peer a, rp_engine_peer b) {
    return a.verified && b.verified && a.slot==b.slot &&
           a.generation==b.generation && a.epoch==b.epoch;
}
static bool attested(const rp_runtime_r13 *r, const rp_runtime_r14 *e) {
    return r && e && r->armed && r->runtime.active &&
        !r->runtime.quarantined && r->runtime.engine_pinned &&
        r->runtime.session.pinned && r->runtime.roster.usable &&
        r->engine.fresh_epoch==e->epoch && r->local.epoch==e->epoch &&
        r->local.slot==e->local_slot && e->local_slot<RP_MAX &&
        r->local.generation==e->generation &&
        peer_same(r->runtime.core.local,r->local) &&
        r->runtime.binding_valid[e->local_slot] &&
        peer_same(r->runtime.binding[e->local_slot].wire,r->local) &&
        r->provider.on_game_thread && r->provider.on_game_thread(r->provider.context);
}
static bool native_frame(rp_runtime_r14 *e, rp_state state, uint8_t owner,
                          uint64_t now_ms, rp_native_frame *f) {
    if(!e || !e->initialized || !f || !e->provider.frame)return false;
    memset(f,0,sizeof *f);
    if(!e->provider.frame(e->provider.context,e->local_slot,owner,state,f) ||
       !f->game_thread || !f->local_ped_verified || f->local_ped<=0)return false;
    /* Trust is supplied by an independently verified engine adapter.
     * Never infer online/game thread from packet fields. */
    f->now_ms=now_ms;
    return true;
}
bool rp_r14_attach(rp_runtime_r14 *e,const rp_runtime_r13 *r,
                   const rp_native *native,const rp_r14_provider *provider) {
    if(!e)return false;
    /* R14 objects MUST be zero-initialized before their first attach. Never
     * overwrite cleanup ownership left by an earlier, revoked session. */
    if(e->initialized || e->pending_clear || e->effects_owned ||
       e->native.cuff_owned || e->native.follow_owned ||
       e->native.jail_placed)return false;
    memset(e,0,sizeof *e);
    if(!r || !native || !native->bound || !provider || !provider->frame ||
       !r->local.generation || !attested(r,&(rp_runtime_r14){
            .epoch=r->local.epoch,.local_slot=r->local.slot,
            .generation=r->local.generation}))return false;
    e->native=*native;
    /* An external native table cannot bring previous ownership into this
     * session; otherwise a stale ped might be freed in a new session. */
    if(e->native.cuff_owned || e->native.follow_owned || e->native.jail_placed)return false;
    e->provider=*provider;e->epoch=r->local.epoch;
    e->local_slot=r->local.slot;e->generation=r->local.generation;
    e->initialized=true;return true;
}
void rp_r14_revoke(rp_runtime_r14 *e) {
    if(!e)return;
    if(e->effects_owned || e->native.cuff_owned)e->pending_clear=true;
    e->initialized=false; /* no future effects without fresh attach */
}
bool rp_r14_cleanup(rp_runtime_r14 *e,uint64_t now_ms) {
    if(!e)return false;
    if(!e->pending_clear && !e->effects_owned && !e->native.cuff_owned)return true;
    /* Cleanup can run after session revocation; it cannot depend on its stale
     * R13 read callbacks. It still REQUIRES fresh local ped and script thread. */
    rp_native_frame f;
    memset(&f,0,sizeof f);
    if(!e->provider.frame || !e->provider.frame(e->provider.context,e->local_slot,
                            RP_NONE,RP_FREE,&f) || !f.game_thread ||
       !f.local_ped_verified || f.local_ped<=0)return false;
    f.now_ms=now_ms;
    if(!rp_native_clear(&e->native,&f))return false;
    e->effects_owned=false;e->pending_clear=false;++e->cleared;
    return true;
}
/* Every non-local escort owner must have the same transport identity, slot,
 * peer ID, and roster generation as the one acknowledged by the host snapshot.
 * The owner ped itself is only obtained from the separately vetted provider. */
static bool verify_owner(rp_runtime_r13 *r,const rp_client *c) {
    if(c->owner>=RP_MAX || c->owner==r->local.slot || !c->owner_generation ||
       !r->runtime.binding_valid[c->owner] || !r->runtime.peers[c->owner].registered ||
       !r->provider.resolve || !r->provider.read)return false;
    const rp_receive_binding *b=&r->runtime.binding[c->owner];
    rp_engine_peer resolved={0};bool consent=false;
    uint64_t id=UINT64_MAX;
    if(!peer_same(r->runtime.peers[c->owner].peer,b->wire) ||
       b->wire.generation!=c->owner_generation ||
       !rp_roster_matches(&r->runtime.roster,r->engine.fresh_epoch,c->owner,
                          b->player,b->local_generation) ||
       !r->provider.resolve(r->provider.context,b->player,&resolved,&consent) ||
       !consent || !peer_same(resolved,b->wire) ||
       !rp_peer_id_v13(r->provider.read,r->provider.context,b->player,
                        r->engine.gamer_info_getter,&id) || id!=b->peer_id)return false;
    return true;
}
bool rp_r14_frame(rp_runtime_r14 *e,rp_runtime_r13 *r,uint64_t now_ms) {
    if(!e || !r || !e->initialized)return false;
    if(e->pending_clear && !rp_r14_cleanup(e,now_ms))return false;
    if(!attested(r,e) || !rp_r13_frame(r,now_ms)) {
        ++e->rejected;rp_r13_stop(r);rp_r14_revoke(e);
        (void)rp_r14_cleanup(e,now_ms);return false;
    }
    const rp_client *c=&r->runtime.core.client;
    if(c->epoch!=e->epoch || c->slot!=e->local_slot ||
       c->generation!=e->generation) {
        ++e->rejected;rp_r13_stop(r);rp_r14_revoke(e);
        (void)rp_r14_cleanup(e,now_ms);return false;
    }
    /* ACKs, surrender notices and expired/free snapshots never restrain the
     * local character. Only a fresh host snapshot can request effects. */
    if(!c->valid || now_ms>=c->expires_ms || c->state==RP_FREE) {
        if(e->effects_owned || e->native.cuff_owned) {
            e->pending_clear=true;
            return rp_r14_cleanup(e,now_ms);
        }
        return true;
    }
    if(!c->snapshot_seq || !c->revision || c->state>RP_JAILED ||
       ((c->state==RP_CUFFED || c->state==RP_ESCORTED) &&
          (c->owner>=RP_MAX || !c->owner_generation)) ||
       (c->state==RP_ESCORTED && !verify_owner(r,c))) {
        ++e->rejected;rp_r13_stop(r);rp_r14_revoke(e);
        (void)rp_r14_cleanup(e,now_ms);return false;
    }
    rp_native_frame f;
    uint8_t owner=c->state==RP_ESCORTED?c->owner:RP_NONE;
    if(!native_frame(e,(rp_state)c->state,owner,now_ms,&f) || !f.online ||
       (c->state==RP_ESCORTED && (!f.owner_verified || !f.owner_ped ||
        f.owner_generation!=c->owner_generation)) ||
       (c->state==RP_JAILED && !f.jail_verified)) {
        ++e->rejected;rp_r13_stop(r);rp_r14_revoke(e);
        (void)rp_r14_cleanup(e,now_ms);return false;
    }
    /* Ownership is recorded BEFORE issuing the first native call, so partial
     * native operations will be cleaned on the next attested script frame. */
    e->effects_owned=true;
    if(!rp_native_apply(&e->native,&f,(rp_state)c->state)) {
        ++e->rejected;e->pending_clear=true;rp_r13_stop(r);
        rp_r14_revoke(e);(void)rp_r14_cleanup(e,now_ms);return false;
    }
    ++e->applied;return true;
}
