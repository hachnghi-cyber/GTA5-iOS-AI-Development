#include "rp_runtime_r12.h"
#include <string.h>

static bool valid(rp_engine_peer p, uint64_t epoch) {
    return p.verified && p.slot<RP_MAX && p.generation!=0 && p.epoch==epoch && epoch!=0;
}
static bool same(rp_engine_peer a, rp_engine_peer b) {
    return a.verified && b.verified && a.slot==b.slot &&
           a.generation==b.generation && a.epoch==b.epoch;
}
static bool active(const rp_runtime_r12 *r) {
    return r && r->active && !r->quarantined && r->core.initialized;
}
static void wipe_pending(rp_runtime_r12 *r) {
    memset(r->pending,0,sizeof r->pending);
    r->rx_head=r->rx_tail=r->rx_count=0;
}
static void quarantine(rp_runtime_r12 *r) {
    if(!r)return;
    r->quarantined=true;
    r->active=false;
    wipe_pending(r);
    rp_r11_close(&r->core);
    rp_roster_invalidate(&r->roster);
    r->engine_pinned=false;
    r->session.pinned=false;
}
bool rp_r12_begin(rp_runtime_r12 *r,rp_engine_peer local,rp_engine_peer host,
                  bool is_host,rp_r12_send_fn send,void *ctx) {
    if(!r || !send || !valid(local,local.epoch) || !valid(host,local.epoch))return false;
    memset(r,0,sizeof *r);
    if(!rp_r11_begin(&r->core,local,host,is_host))return false;
    r->send=send;r->send_ctx=ctx;r->epoch=local.epoch;
    r->peers[local.slot].peer=local;r->peers[local.slot].registered=true;
    r->peers[host.slot].peer=host;r->peers[host.slot].registered=true;
    r->active=true;
    if(is_host && !rp_r11_host_join(&r->core,local.slot,local.generation,true)) {
        quarantine(r);return false;
    }
    r->life.service=&r->core.service;
    r->life.sender=&r->core.sender;
    r->life.client=&r->core.client;
    r->life.roster=&r->roster;
    return true;
}
void rp_r12_stop(rp_runtime_r12 *r) {
    if(!r)return;
    quarantine(r);
    memset(r->peers,0,sizeof r->peers);
    memset(r->binding_valid,0,sizeof r->binding_valid);
    memset(r->binding,0,sizeof r->binding);
    r->send=NULL;r->send_ctx=NULL;
}
bool rp_r12_register_peer(rp_runtime_r12 *r,rp_engine_peer p,bool opt_in) {
    if(!active(r)||!valid(p,r->epoch))return false;
    rp_r12_peer *slot=&r->peers[p.slot];
    if(slot->registered) {
        if(!same(slot->peer,p) ||
           (r->core.local_is_host &&
            (!r->core.service.host.p[p.slot].joined ||
             r->core.service.host.p[p.slot].consent!=opt_in))) {
            /* Generation/consent change is a new handshake epoch. Never
             * silently replace an already admitted peer or erase RP state. */
            ++r->rejected;quarantine(r);return false;
        }
        return true; /* idempotent roster updates never reset player state */
    }
    if(r->core.local_is_host &&
       !rp_r11_host_join(&r->core,p.slot,p.generation,opt_in))return false;
    slot->peer=p;slot->registered=true;
    return true;
}
bool rp_r12_observe(rp_runtime_r12 *r,uint8_t slot,rp_role role,rp_observation obs) {
    if(!active(r)||slot>=RP_MAX||!r->peers[slot].registered)return false;
    return rp_r11_host_observe(&r->core,slot,role,obs);
}
bool rp_r12_action(rp_runtime_r12 *r,rp_action action,uint8_t target,
                   uint32_t gen,uint32_t arg,uint64_t now) {
    if(!active(r)||target>=RP_MAX||!r->peers[target].registered||
       r->peers[target].peer.generation!=gen)return false;
    return rp_r11_submit(&r->core,action,target,gen,arg,now);
}
bool rp_r12_enqueue_authenticated(rp_runtime_r12 *r,rp_engine_peer peer,
                                   const uint8_t wire[RP_ENGINE_BYTES]) {
    if(!active(r)||!wire||!valid(peer,r->epoch) ||
       !r->peers[peer.slot].registered || !same(peer,r->peers[peer.slot].peer) ||
       peer.slot==r->core.local.slot) {
        if(r)++r->rejected;
        return false;
    }
    rp_engine_kind kind;rp_inbound payload;
    if(!rp_engine_unpack(wire,RP_ENGINE_BYTES,peer,&kind,&payload) ||
       (kind==RP_ENGINE_REQUEST && !r->core.local_is_host) ||
       (kind!=RP_ENGINE_REQUEST && !same(peer,r->core.host))) {
        ++r->rejected;return false;
    }
    if(r->rx_count==RP_R12_RX_CAP) {
        ++r->dropped;quarantine(r);return false;
    }
    rp_r12_event *item=&r->pending[r->rx_tail];
    item->actual=peer;item->kind=kind;
    memcpy(item->wire,wire,RP_ENGINE_BYTES);
    r->rx_tail=(r->rx_tail+1u)%RP_R12_RX_CAP;
    ++r->rx_count;
    return true;
}
static bool emit(rp_runtime_r12 *r,uint8_t target,const uint8_t b[RP_ENGINE_BYTES]) {
    if(target>=RP_MAX || !r->peers[target].registered ||
       !valid(r->peers[target].peer,r->epoch) || !r->send) return false;
    if(!r->send(r->send_ctx,target,b))return false;
    ++r->sent;return true;
}
/* Dispatching a local action on the host bypasses network loopback but still
 * goes through the identical host-authoritative request validation. */
static bool host_request(rp_runtime_r12 *r,rp_engine_peer sender,
                         const uint8_t b[RP_ENGINE_BYTES],uint64_t now) {
    uint8_t ack[RP_ENGINE_BYTES],snap[RP_ENGINE_BYTES],target=RP_NONE;
    if(!rp_r11_host_receive(&r->core,sender,b,ack,snap,&target))return false;
    bool ok=true;
    if(sender.slot==r->core.local.slot)
        ok=rp_r11_client_receive(&r->core,r->core.host,ack,now);
    else ok=emit(r,sender.slot,ack);
    if(target!=RP_NONE) {
        if(target==r->core.local.slot)
            ok=rp_r11_client_receive(&r->core,r->core.host,snap,now) && ok;
        else ok=emit(r,target,snap) && ok;
    }
    return ok;
}
static bool deliver_one(rp_runtime_r12 *r,const rp_r12_event *p,uint64_t now) {
    if(!same(p->actual,r->peers[p->actual.slot].peer))return false;
    if(p->kind==RP_ENGINE_REQUEST)
        return host_request(r,p->actual,p->wire,now);
    return rp_r11_client_receive(&r->core,p->actual,p->wire,now);
}
bool rp_r12_frame(rp_runtime_r12 *r,uint64_t now) {
    if(!active(r))return false;
    if(r->engine_pinned && !rp_r12_audit_engine(r))return false;
    rp_r11_tick(&r->core,now);
    bool ok=true;
    /* All packets enter on a serialized game-thread; never block the frame. */
    unsigned limit=r->rx_count;
    if(limit>RP_R12_RX_CAP) {quarantine(r);return false;}
    for(unsigned i=0;i<limit;++i) {
        rp_r12_event event=r->pending[r->rx_head];
        memset(&r->pending[r->rx_head],0,sizeof event);
        r->rx_head=(r->rx_head+1u)%RP_R12_RX_CAP;
        --r->rx_count;
        if(!deliver_one(r,&event,now)) {++r->rejected;ok=false;}
        else ++r->received;
    }
    uint8_t req[RP_ENGINE_BYTES];
    if(rp_r11_next(&r->core,now,req)) {
        if(r->core.local_is_host)
            ok=host_request(r,r->core.local,req,now) && ok;
        else ok=emit(r,r->core.host.slot,req) && ok;
    }
    return ok;
}
bool rp_r12_pin_engine(rp_runtime_r12 *r,rp_read_memory read,void *ctx,
                       uintptr_t mgr,uintptr_t session,uintptr_t getter) {
    if(!active(r)||!read||!mgr||!session||!getter || r->engine_pinned)return false;
    rp_roster_snapshot snapshot;
    if(!rp_session_pin(&r->session,read,ctx,session) ||
       !rp_roster_read_v13(read,ctx,mgr,&snapshot) ||
       !rp_roster_begin(&r->roster,r->epoch,&snapshot)) {
        r->session.pinned=false;return false;
    }
    r->read=read;r->read_ctx=ctx;r->manager=mgr;
    r->session_ptr=session;r->getter_runtime=getter;
    r->engine_pinned=true;
    return true;
}
bool rp_r12_audit_engine(rp_runtime_r12 *r) {
    if(!active(r)||!r->engine_pinned||!r->read)return false;
    rp_roster_snapshot current;
    if(!rp_session_audit(&r->session,r->read,r->read_ctx,r->session_ptr,&r->life) ||
       !rp_roster_read_v13(r->read,r->read_ctx,r->manager,&current) ||
       !rp_roster_audit(&r->roster,&current)) {
        quarantine(r);return false;
    }
    return true;
}
bool rp_r12_bind_player(rp_runtime_r12 *r,rp_engine_peer p,uintptr_t player,
                        uint32_t local_generation,uint64_t peer_id) {
    if(!active(r)||!r->engine_pinned||!valid(p,r->epoch)||
       !r->peers[p.slot].registered||!same(p,r->peers[p.slot].peer) ||
       !rp_roster_matches(&r->roster,r->epoch,p.slot,player,local_generation) ||
       peer_id==UINT64_MAX)return false;
    rp_receive_binding binding={.wire=p,.player=player,
        .local_generation=local_generation,.peer_id=peer_id,
        .session=r->session.identity};
    r->binding[p.slot]=binding;r->binding_valid[p.slot]=true;
    return true;
}
/* R16 safety correction: Decide's event+0x224 is a script-event TYPE,
 * not the 96-byte RPE3 length. RPE3 must enter ONLY through an explicitly
 * authenticated transport buffer (rp_r16_transport_receive). This legacy
 * API deliberately fails closed, even for a crafted RPE3-looking event. */
bool rp_r12_decide(rp_runtime_r12 *r,uintptr_t event,uintptr_t player,
                    rp_engine_peer actual) {
    (void)event;(void)player;(void)actual;
    if(r)++r->rejected;
    return false;
}
