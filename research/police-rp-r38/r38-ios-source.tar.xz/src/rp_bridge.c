#include "rp_bridge.h"
static bool host_member(const rp_service *s,rp_engine_peer h) {
    return s && h.verified && h.slot<RP_MAX && h.epoch==s->host.epoch && h.generation &&
        s->host.p[h.slot].joined && s->host.p[h.slot].generation==h.generation;
}
bool rp_bridge_host_request(rp_service *s,rp_engine_peer host,rp_engine_peer sender,
                            const uint8_t *b,size_t n,uint8_t ack[RP_ENGINE_BYTES]) {
    if(!host_member(s,host) || !ack)return false;
    rp_engine_kind kind;rp_inbound p;
    if(!rp_engine_unpack(b,n,sender,&kind,&p) || kind!=RP_ENGINE_REQUEST || sender.epoch!=host.epoch)return false;
    uint8_t reply[RP_ACK_WIRE];
    if(!rp_service_receive(s,p.peer,p.generation,p.bytes,p.length,reply))return false;
    return rp_engine_pack(host.slot,RP_ENGINE_ACK,reply,sizeof reply,ack);
}
bool rp_bridge_snapshot(rp_service *s,rp_engine_peer host,uint8_t target,
                        uint8_t out[RP_ENGINE_BYTES]) {
    if(!host_member(s,host))return false;
    uint8_t snapshot[RP_WIRE];
    return rp_snapshot(&s->host,target,snapshot) && rp_engine_pack(host.slot,RP_ENGINE_SNAPSHOT,snapshot,sizeof snapshot,out);
}
bool rp_bridge_client_receive(rp_sender *sender,rp_client *client,rp_engine_peer expected,
                              rp_engine_peer actual,const uint8_t *b,size_t n,uint64_t now) {
    if(!sender || !client || !expected.verified || !actual.verified ||
       actual.slot!=expected.slot || actual.generation!=expected.generation ||
       actual.epoch!=expected.epoch || expected.epoch!=client->epoch ||
       expected.epoch!=sender->epoch)return false;
    rp_engine_kind kind;rp_inbound p;
    if(!rp_engine_unpack(b,n,actual,&kind,&p))return false;
    if(kind==RP_ENGINE_ACK)return rp_sender_ack(sender,true,p.bytes,p.length,now);
    if(kind==RP_ENGINE_SNAPSHOT)return rp_client_apply(client,true,p.bytes,p.length,now);
    return false;
}
bool rp_bridge_local_frame(rp_native *n,rp_client *c,const rp_native_frame *f,bool session) {
    if(!n || !c || !f)return false;
    rp_client_tick(c,f->now_ms);
    if(!session) { c->valid=false; c->epoch=0; }
    if(!session || !c->valid)return rp_native_clear(n,f);
    if((c->state==RP_ESCORTED && (!f->owner_verified || !c->owner_generation ||
        c->owner_generation!=f->owner_generation)) || !rp_native_apply(n,f,(rp_state)c->state)) {
        (void)rp_native_clear(n,f);
        return false;
    }
    return true;
}
