#include "rp_runtime_r15.h"
#include <string.h>

#define RP_R15_INPUT_INTERVAL_MS UINT64_C(300)

void rp_r15_init(rp_runtime_r15 *r) {
    if(r)memset(r,0,sizeof *r);
}

void rp_r15_stop(rp_runtime_r15 *r) {
    if(!r || r->phase==RP_R15_IDLE)return;
    if(r->phase==RP_R15_ACTIVE)++r->stops;
    /* Revoke before stopping the session. The effect ownership must survive
     * the stop because only a fresh local-ped provider may clear a cuff. */
    rp_r14_revoke(&r->effects);
    rp_r13_stop(&r->session);
    r->phase=RP_R15_DRAINING;
}

bool rp_r15_cleanup(rp_runtime_r15 *r,uint64_t now_ms) {
    if(!r)return false;
    if(r->phase==RP_R15_IDLE)return true;
    if(r->phase!=RP_R15_DRAINING)return false;
    if(!rp_r14_cleanup(&r->effects,now_ms)) {
        ++r->cleanup_retries;
        return false;
    }
    r->phase=RP_R15_IDLE;
    r->tick_seen=false;r->input_seen=false;
    r->last_tick_ms=0;r->last_input_ms=0;
    return true;
}

bool rp_r15_open(rp_runtime_r15 *r,const rp_r13_provider *provider,
                 const rp_r13_engine_start *engine,const rp_native *native,
                 const rp_r14_provider *local_native) {
    if(!r || r->phase!=RP_R15_IDLE || !provider || !engine || !native ||
       !local_native || r->effects.initialized || r->effects.pending_clear ||
       r->effects.effects_owned || r->effects.native.cuff_owned ||
       r->effects.native.follow_owned || r->effects.native.jail_placed)
        return false;
    if(!rp_r13_start(&r->session,provider,engine))return false;
    if(!rp_r14_attach(&r->effects,&r->session,native,local_native)) {
        rp_r13_stop(&r->session);
        return false;
    }
    r->phase=RP_R15_ACTIVE;
    r->tick_seen=false;r->input_seen=false;
    r->last_tick_ms=0;r->last_input_ms=0;
    ++r->opens;
    return true;
}

bool rp_r15_admit(rp_runtime_r15 *r,uintptr_t player) {
    if(!r || r->phase!=RP_R15_ACTIVE)return false;
    bool ok=rp_r13_admit(&r->session,player);
    if(!r->session.armed)rp_r15_stop(r);
    return ok;
}

bool rp_r15_observe_decide(rp_runtime_r15 *r,uintptr_t event,uintptr_t player) {
    if(!r || r->phase!=RP_R15_ACTIVE)return false;
    ++r->observed_events;
    bool ok=rp_r13_decide_observe(&r->session,event,player);
    if(ok)++r->accepted_events;
    if(!r->session.armed)rp_r15_stop(r);
    return ok;
}

bool rp_r15_request(rp_runtime_r15 *r,rp_action action,uint8_t target,
                    uint32_t generation,uint32_t arg,uint64_t now_ms) {
    if(!r || r->phase!=RP_R15_ACTIVE)return false;
    if((r->tick_seen && now_ms<r->last_tick_ms) ||
       (r->input_seen && now_ms<r->last_input_ms)) {
        ++r->denied_inputs;rp_r15_stop(r);return false;
    }
    /* The verified input must be an edge, not every held frame; do not allow
     * accidental floods/rapid repeated cuff commands. */
    if(r->input_seen && now_ms-r->last_input_ms<RP_R15_INPUT_INTERVAL_MS) {
        ++r->denied_inputs;return false;
    }
    if(action<RP_SURRENDER || action>RP_REVIVE || target>=RP_MAX ||
       (action==RP_SURRENDER && target!=r->session.local.slot)) {
        ++r->denied_inputs;return false;
    }
    bool ok=rp_r13_submit(&r->session,action,target,generation,arg,now_ms);
    if(!r->session.armed){rp_r15_stop(r);return false;}
    if(!ok){++r->denied_inputs;return false;}
    r->input_seen=true;r->last_input_ms=now_ms;
    ++r->submitted;
    return true;
}

bool rp_r15_frame(rp_runtime_r15 *r,uint64_t now_ms) {
    if(!r)return false;
    if(r->phase==RP_R15_DRAINING)return rp_r15_cleanup(r,now_ms);
    if(r->phase!=RP_R15_ACTIVE)return false;
    if((r->tick_seen && now_ms<=r->last_tick_ms) ||
       (r->input_seen && now_ms<r->last_input_ms)) {
        ++r->rejected_frames;rp_r15_stop(r);
        (void)rp_r15_cleanup(r,now_ms);return false;
    }
    r->last_tick_ms=now_ms;r->tick_seen=true;
    if(!rp_r14_frame(&r->effects,&r->session,now_ms)) {
        ++r->rejected_frames;rp_r15_stop(r);
        (void)rp_r15_cleanup(r,now_ms);
        return false;
    }
    return true;
}

void rp_r15_after_assignment(rp_runtime_r15 *r,uintptr_t player) {
    if(!r || r->phase!=RP_R15_ACTIVE)return;
    rp_r13_after_assignment(&r->session,player);
    if(!r->session.armed)rp_r15_stop(r);
}
