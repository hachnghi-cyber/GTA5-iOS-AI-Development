#include "rp_lifecycle.h"
#include <string.h>
void rp_lifecycle_stop(rp_lifecycle *l,rp_life_reason why) {
    if(!l) return;
    /* Retain the native ownership record for deferred cleanup. Never memset it
       while script context is unavailable. Queue is NOT reset concurrently;
       stale queued envelopes fail epoch/handshake checks after this reset. */
    if(l->service) memset(l->service,0,sizeof *l->service);
    if(l->sender) memset(l->sender,0,sizeof *l->sender);
    if(l->client) memset(l->client,0,sizeof *l->client);
    rp_roster_invalidate(l->roster);
    l->cleanup_pending=true;
    l->reason=why;
}
bool rp_lifecycle_cleanup_frame(rp_lifecycle *l,const rp_native_frame *f) {
    if(!l) return false;
    if(!l->cleanup_pending) return true;
    if(!rp_native_clear(l->native,f)) return false;
    l->cleanup_pending=false;
    return true;
}
static bool player_call(rp_lifecycle *l,rp_original_player_call original,
                        uintptr_t manager,uintptr_t player,rp_life_reason reason) {
    /* Invalidate BEFORE original: it may reenter receive/tick or free/recycle
       player memory. No read of manager/player before or after original. */
    rp_lifecycle_stop(l,reason);
    if(!original) return false;
    original(manager,player);
    return true;
}
bool rp_lifecycle_remove(rp_lifecycle *l,rp_original_player_call o,uintptr_t m,uintptr_t p) {
    return player_call(l,o,m,p,RP_LIFE_REMOVE);
}
bool rp_lifecycle_deallocate(rp_lifecycle *l,rp_original_player_call o,uintptr_t m,uintptr_t p) {
    return player_call(l,o,m,p,RP_LIFE_DEALLOCATE);
}
bool rp_lifecycle_shutdown(rp_lifecycle *l,rp_original_shutdown_call o,uintptr_t m) {
    rp_lifecycle_stop(l,RP_LIFE_SHUTDOWN);
    if(!o) return false;
    o(m);return true;
}
