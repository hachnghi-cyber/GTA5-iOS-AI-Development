#include "rp_capture.h"
#include <stdint.h>
bool rp_capture_v13(rp_read_memory read,void *context,uintptr_t event,
                     uintptr_t net_player,rp_engine_peer peer,
                     rp_engine_kind *kind,rp_inbound *out) {
    if(!read || !event || !net_player || !peer.verified || event>UINTPTR_MAX-552 ||
       net_player>UINTPTR_MAX-34)return false;
    uint8_t size_bytes[4],slot;
    if(!read(context,event+548,size_bytes,4) || !read(context,net_player+33,&slot,1) || slot!=peer.slot)return false;
    uint32_t size=(uint32_t)size_bytes[0]|(uint32_t)size_bytes[1]<<8|(uint32_t)size_bytes[2]<<16|(uint32_t)size_bytes[3]<<24;
    if(size!=RP_ENGINE_BYTES)return false;
    uint8_t envelope[RP_ENGINE_BYTES];
    if(!read(context,event+112,envelope,sizeof envelope))return false;
    /* The constructor would overwrite sender at +8 using the actual peer.
       An observer before the constructor does the same on its private copy. */
    envelope[8]=slot;envelope[9]=envelope[10]=envelope[11]=0;
    return rp_engine_unpack(envelope,sizeof envelope,peer,kind,out);
}
