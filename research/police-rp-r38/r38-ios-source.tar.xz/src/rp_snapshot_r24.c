#include "rp_snapshot_r24.h"
#include "rp_runtime_r18.h"
#include <string.h>

static bool valid_cursor(const rp_r24_cursor *c) {
    return c->read_bit<=c->limit_bit &&
           c->limit_bit<=RP_R24_MAX_EVENT_BITS &&
           c->storage_generation!=0;
}
static bool equal_cursor(const rp_r24_cursor *a,const rp_r24_cursor *b){
    return a->read_bit==b->read_bit && a->limit_bit==b->limit_bit &&
           a->storage_generation==b->storage_generation;
}
/* R34: callbacks may run third-party/native code and mutate their providers.
 * The outer R28 check happens AFTER this function returns, which is too late
 * to revoke a delivery. Freeze both R24 and R23 policies in this invocation.
 */
static bool same_policy(const rp_r24_bridge *b,
                        const rp_r24_provider *provider,
                        const rp_r23_ingress *ingress,
                        const rp_r23_provider *identity,
                        uint64_t bridge_revision,
                        uint64_t ingress_revision) {
    if (!b || !ingress || b->revision!=bridge_revision ||
        b->ingress!=ingress || ingress->revision!=ingress_revision)
        return false;
    const rp_r24_provider *p=&b->provider;
    const rp_r23_provider *r=&ingress->provider;
    return p->cursor==provider->cursor && p->peek==provider->peek &&
           p->isolated==provider->isolated && p->context==provider->context &&
           r->on_game_thread==identity->on_game_thread &&
           r->read_epoch==identity->read_epoch &&
           r->read_event_type==identity->read_event_type &&
           r->verify_native==identity->verify_native &&
           r->deliver==identity->deliver && r->context==identity->context;
}
void rp_r24_init(rp_r24_bridge *b){if(b)memset(b,0,sizeof *b);}
void rp_r24_stop(rp_r24_bridge *b){
    if(!b)return;
    ++b->revision;
    b->armed=false;
    /* busy remains set until in-flight callback finishes */
}
bool rp_r24_arm(rp_r24_bridge *b,rp_r23_ingress *ingress,
                const rp_r24_provider *p){
    if(!b || !ingress || !p || b->armed || b->busy || b->faulted ||
       !ingress->armed || ingress->busy || !p->cursor || !p->peek ||
       !p->isolated || !ingress->provider.on_game_thread ||
       !ingress->provider.read_epoch || !ingress->provider.read_event_type ||
       !ingress->provider.verify_native)return false;
    b->ingress=ingress;
    b->provider=*p;
    ++b->revision;
    b->armed=true;
    return true;
}
static bool lease(rp_r24_bridge *b,uint64_t revision,uint64_t epoch){
    if(!b->busy || !b->armed || revision!=b->revision ||
       !b->ingress || !b->ingress->armed || b->ingress->busy ||
       !b->ingress->provider.on_game_thread ||
       !b->ingress->provider.read_epoch)return false;
    rp_r23_ingress *r=b->ingress;
    rp_r23_thread_check thread=r->provider.on_game_thread;
    void *ctx=r->provider.context;
    if(!thread(ctx))return false;
    if(!b->armed || revision!=b->revision || !r->armed)return false;
    rp_r23_epoch_read read=r->provider.read_epoch;
    uint64_t observed=read(ctx);
    return b->armed && revision==b->revision && r->armed &&
           r->boundary.bound_epoch==epoch && observed==epoch;
}

rp_r20_result rp_r24_snapshot_dispatch(rp_r24_bridge *b,
                                       const rp_r23_native_call *n){
    /* Unknown/unreadable events are left to the game, never consumed. */
    if(!b || !b->armed || b->busy || !b->ingress ||
       !n || !n->native_event || !n->bit_buffer)return RP_R20_PASS_ORIGINAL;
    ++b->attempts;
    b->busy=true;
    rp_r20_result result=RP_R20_PASS_ORIGINAL;
    const uint64_t revision=b->revision;
    const rp_r23_ingress *const ingress=b->ingress;
    const uint64_t ingress_revision=ingress->revision;
    const rp_r24_provider policy=b->provider;
    const rp_r23_provider identity=ingress->provider;
    const uint64_t epoch=ingress->boundary.bound_epoch;
    const rp_r23_native_call copy=*n;
    uint8_t snapshot[RP_R17_JOB_BYTES];
    size_t len=0;
    rp_r24_cursor before={0},after={0};
    bool private_job=false;
    memset(snapshot,0,sizeof snapshot);
    if(!same_policy(b,&policy,ingress,&identity,revision,ingress_revision))
        goto policy_drop;
    if(!lease(b,revision,epoch))goto end;
    if(!same_policy(b,&policy,ingress,&identity,revision,ingress_revision))
        goto policy_drop;
    uint32_t event_type=0;
    bool typed=identity.read_event_type(identity.context,
                                         copy.native_event,&event_type);
    if(!same_policy(b,&policy,ingress,&identity,revision,ingress_revision))
        goto policy_drop;
    if(!typed || !lease(b,revision,epoch) ||
       event_type!=RP_R20_NETWORK_SCRIPT_EVENT_TYPE)goto end;
    if(!same_policy(b,&policy,ingress,&identity,revision,ingress_revision))
        goto policy_drop;
    bool first=policy.cursor(policy.context,copy.bit_buffer,&before);
    if(!same_policy(b,&policy,ingress,&identity,revision,ingress_revision))
        goto policy_drop;
    if(!first || !valid_cursor(&before) || !lease(b,revision,epoch)){
        ++b->decode_failed;goto end;
    }
    if(!same_policy(b,&policy,ingress,&identity,revision,ingress_revision))
        goto policy_drop;
    bool decoded=policy.peek(policy.context,&copy,
                                  snapshot,sizeof snapshot,&len);
    /* Header-only classification is safe ONLY if the decoder explicitly
     * returned success with at least the full 20-byte header. This matters
     * when a private packet is truncated: never feed it into vanilla Jobs. */
    private_job=decoded && len>=20 && len<=sizeof snapshot &&
        rp_r18_early_decision(snapshot,len)!=RP_R18_PASS_ORIGINAL;
    /* Re-read cursor even if decode failed, to detect accidental mutation. */
    /* Check immediately after untrusted decode, BEFORE further callbacks
     * and, crucially, BEFORE the isolation/identity and deliver chain. */
    if(!same_policy(b,&policy,ingress,&identity,revision,ingress_revision))
        goto policy_drop;
    bool second=policy.cursor(policy.context,copy.bit_buffer,&after);
    if(!same_policy(b,&policy,ingress,&identity,revision,ingress_revision))
        goto policy_drop;
    if(!second || !valid_cursor(&after) || !equal_cursor(&before,&after)){
        ++b->cursor_changed;
        /* Stop observing immediately: game cursor may already be corrupted.
         * Known private packets get rejection; unknown/vanilla cannot be
         * silently consumed. Operator must discard the unsafe decoder. */
        b->faulted=true;
        rp_r24_stop(b);
        result=private_job ? RP_R20_PRIVATE_REJECTED : RP_R20_PASS_ORIGINAL;
        goto end;
    }
    if(!lease(b,revision,epoch)){
        ++b->epoch_changed;
        result=private_job ? RP_R20_PRIVATE_REJECTED : RP_R20_PASS_ORIGINAL;
        goto end;
    }
    if(!same_policy(b,&policy,ingress,&identity,revision,ingress_revision))
        goto policy_drop;
    /* A full 244-byte read is needed ONLY for private jobs. A vetted
     * header-only decoder may classify a vanilla job without copying its
     * body. Do not count that as a failed decode. */
    if(decoded && len>=20 && !private_job)goto end;
    if(!decoded || len!=sizeof snapshot){
        ++b->decode_failed;
        /* A truncated but RECOGNIZED private command is never vanilla Jobs.
         * Unknown/vanilla data must follow the original engine path. */
        result=private_job ? RP_R20_PRIVATE_REJECTED : RP_R20_PASS_ORIGINAL;
        goto end;
    }
    if(!private_job)goto end;
    result=RP_R20_PRIVATE_REJECTED;
    bool isolated=policy.isolated(policy.context,&copy);
    if(!same_policy(b,&policy,ingress,&identity,revision,ingress_revision))
        goto policy_drop;
    if(!isolated){
        ++b->isolation_denied;goto end;
    }
    if(!lease(b,revision,epoch)){
        ++b->epoch_changed;goto end;
    }
    if(!same_policy(b,&policy,ingress,&identity,revision,ingress_revision))
        goto policy_drop;
    /* All data used downstream is owned by this stack frame, captured in
     * the SAME native callback. R23 re-verifies sender & delivery ID. */
    result=rp_r23_receive_same_call(b->ingress,&copy,snapshot,len);
    if(!b->armed || b->revision!=revision || !b->ingress->armed)
        result=RP_R20_PRIVATE_REJECTED;
    if(!same_policy(b,&policy,ingress,&identity,revision,ingress_revision))
        goto policy_drop;
    goto end;
policy_drop:
    ++b->policy_changed;
    b->faulted=true;
    rp_r24_stop(b); /* do not silently rearm after unexpected mutation */
    result=private_job ? RP_R20_PRIVATE_REJECTED : RP_R20_PASS_ORIGINAL;
end:
    memset(snapshot,0,sizeof snapshot);
    b->busy=false;
    if(result==RP_R20_PRIVATE_ACCEPTED)++b->accepted;
    else if(result==RP_R20_PASS_ORIGINAL)++b->vanilla;
    else ++b->rejected;
    return result;
}
