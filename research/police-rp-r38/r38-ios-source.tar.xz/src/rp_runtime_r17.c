#include "rp_runtime_r17.h"
#include <string.h>

static uint32_t load32(const uint8_t *p) {
    return (uint32_t)p[0] | ((uint32_t)p[1]<<8) |
           ((uint32_t)p[2]<<16) | ((uint32_t)p[3]<<24);
}
static void store32(uint8_t *p,uint32_t v) {
    p[0]=(uint8_t)v;p[1]=(uint8_t)(v>>8);
    p[2]=(uint8_t)(v>>16);p[3]=(uint8_t)(v>>24);
}
/* A fixed-layout, bounded checksum; not a MAC or a proof of sender. */
static bool separate(const void *a,size_t an,const void *b,size_t bn) {
    uintptr_t x=(uintptr_t)a,y=(uintptr_t)b;
    if(x>UINTPTR_MAX-an || y>UINTPTR_MAX-bn)return false;
    return x+an<=y || y+bn<=x;
}
static uint32_t checksum(const uint8_t *b,size_t n) {
    uint32_t crc=0xffffffffU;
    for(size_t i=0;i<n;++i) {
        crc ^= b[i];
        for(unsigned j=0;j<8;++j)
            crc=(crc>>1)^(0xedb88320U & (0U-(crc&1U)));
    }
    return ~crc;
}
void rp_r17_init(rp_runtime_r17 *r,rp_runtime_r16 *gate,
                 rp_r17_emit_job emit,rp_r17_attest_sender attest,void *context) {
    if(!r)return;
    memset(r,0,sizeof *r);
    r->gate=gate;r->emit=emit;r->attest=attest;r->context=context;
}
bool rp_r17_pack_job(uint8_t out[RP_R17_JOB_BYTES],
                     const uint8_t wire[RP_ENGINE_BYTES]) {
    if(!out || !wire || RP_R17_PAYLOAD_OFFSET+RP_ENGINE_BYTES>RP_R17_JOB_BYTES)
        return false;
    /* The input is never allowed to alias the output (including overlap
       from before its beginning). Check arithmetic bounds before memset. */
    if(!separate(out,RP_R17_JOB_BYTES,wire,RP_ENGINE_BYTES))return false;
    memset(out,0,RP_R17_JOB_BYTES);
    store32(out,RP_R17_MAGIC);
    /* The native sender overwrites kind/seq when actually sending. */
    store32(out+16,RP_R17_CUSTOM_KIND);
    store32(out+RP_R17_EXT_OFFSET,RP_R17_EXTENSION_MAGIC);
    store32(out+RP_R17_EXT_OFFSET+4,checksum(wire,RP_ENGINE_BYTES));
    out[RP_R17_EXT_OFFSET+8]=RP_R17_EXT_VERSION;
    out[RP_R17_EXT_OFFSET+9]=(uint8_t)RP_ENGINE_BYTES;
    memcpy(out+RP_R17_PAYLOAD_OFFSET,wire,RP_ENGINE_BYTES);
    return true;
}
bool rp_r17_unpack_job(const uint8_t *job,size_t len,
                       uint8_t wire[RP_ENGINE_BYTES],uint8_t *slot_hint) {
    if(!job || !wire || len!=RP_R17_JOB_BYTES ||
       load32(job)!=RP_R17_MAGIC ||
       load32(job+16)!=RP_R17_CUSTOM_KIND ||
       load32(job+RP_R17_EXT_OFFSET)!=RP_R17_EXTENSION_MAGIC ||
       job[RP_R17_EXT_OFFSET+8]!=RP_R17_EXT_VERSION ||
       job[RP_R17_EXT_OFFSET+9]!=RP_ENGINE_BYTES ||
       job[RP_R17_EXT_OFFSET+10] || job[RP_R17_EXT_OFFSET+11] ||
       load32(job+RP_R17_EXT_OFFSET+4)!=
           checksum(job+RP_R17_PAYLOAD_OFFSET,RP_ENGINE_BYTES) ||
       /* A replay/tampered trailer must not be mistaken for metadata. */
       job[RP_R17_PAYLOAD_OFFSET+RP_ENGINE_BYTES]!=0)
        return false;
    /* Subprotocol rejects nonzero trailing garbage; no payload aliasing. */
    for(size_t i=RP_R17_PAYLOAD_OFFSET+RP_ENGINE_BYTES;i<len;++i)
        if(job[i]!=0)return false;
    if(!separate(job,len,wire,RP_ENGINE_BYTES))return false;
    /* Validate the sender slot BEFORE writing any caller-owned output.
     * A valid checksum does not imply a valid roster index. */
    const uint32_t claimed_slot=load32(job+8);
    if(claimed_slot>=RP_MAX)return false;
    memcpy(wire,job+RP_R17_PAYLOAD_OFFSET,RP_ENGINE_BYTES);
    if(slot_hint)*slot_hint=(uint8_t)claimed_slot;
    return true;
}
bool rp_r17_send(rp_runtime_r17 *r,uint8_t recipient,
                 const uint8_t wire[RP_ENGINE_BYTES]) {
    if(!r)return false;
    if(r->busy || !r->emit || !r->gate || !wire || recipient>=RP_MAX ||
       !r->gate->runtime || r->gate->runtime->phase!=RP_R15_ACTIVE ||
       !r->gate->runtime->session.provider.on_game_thread ||
       !r->gate->runtime->session.provider.on_game_thread(
           r->gate->runtime->session.provider.context)) {
        ++r->rejected_send;return false;
    }
    r->busy=true;
    uint8_t job[RP_R17_JOB_BYTES];
    bool ok=rp_r17_pack_job(job,wire);
    if(ok)++r->encoded;
    if(ok)ok=r->emit(r->context,job,RP_R17_CUSTOM_KIND,1U<<recipient);
    memset(job,0,sizeof job);
    if(ok)++r->queued;else ++r->rejected_send;
    r->busy=false;
    return ok;
}
bool rp_r17_receive(rp_runtime_r17 *r,const void *cookie,
                    const uint8_t *job,size_t len) {
    if(!r)return false;
    if(r->busy || !r->attest || !r->gate || !cookie || !job ||
       !r->gate->runtime || r->gate->runtime->phase!=RP_R15_ACTIVE ||
       !r->gate->runtime->session.provider.on_game_thread ||
       !r->gate->runtime->session.provider.on_game_thread(
           r->gate->runtime->session.provider.context)) {
        ++r->rejected_receive;return false;
    }
    r->busy=true;
    uint8_t wire[RP_ENGINE_BYTES],slot_hint=0xff;
    uintptr_t player=0;
    bool ok=rp_r17_unpack_job(job,len,wire,&slot_hint);
    if(ok)ok=r->attest(r->context,cookie,&player) && player;
    if(ok) {
        const rp_r13_provider *p=&r->gate->runtime->session.provider;
        uint8_t authenticated_slot=0xff;
        ok=p->on_game_thread && p->read && p->on_game_thread(p->context) &&
           player<=UINTPTR_MAX-33U &&
           p->read(p->context,player+33U,&authenticated_slot,sizeof authenticated_slot) &&
           authenticated_slot==slot_hint;
    }
    if(ok)ok=rp_r16_transport_receive(r->gate,player,wire,RP_ENGINE_BYTES);
    memset(wire,0,sizeof wire);
    if(ok)++r->accepted_receive;else ++r->rejected_receive;
    r->busy=false;
    return ok;
}
