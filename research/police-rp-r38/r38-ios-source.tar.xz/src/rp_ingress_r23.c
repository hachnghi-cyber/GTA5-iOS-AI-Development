#include "rp_ingress_r23.h"
#include "rp_runtime_r18.h"
#include <string.h>

/* Snapshot the entire provider contract instead of inspecting mutable
 * callbacks only when the outer R28 handler returns. Delivery is irreversible.
 */
static bool same_provider(const rp_r23_provider *a,
                          const rp_r23_provider *b) {
    return a->on_game_thread==b->on_game_thread &&
           a->read_epoch==b->read_epoch &&
           a->read_event_type==b->read_event_type &&
           a->verify_native==b->verify_native &&
           a->deliver==b->deliver && a->context==b->context;
}
static bool check_thread(void *context) {
    rp_r23_ingress *r=context;
    return r && r->armed && r->provider.on_game_thread &&
           r->provider.on_game_thread(r->provider.context);
}
static uint64_t read_epoch(void *context) {
    rp_r23_ingress *r=context;
    return r && r->armed && r->provider.read_epoch
        ? r->provider.read_epoch(r->provider.context) : 0;
}
static bool attest_scoped(void *context, const rp_r20_witness *w,
                          uint8_t *verified_slot) {
    rp_r23_ingress *r=context;
    if(!r || !w || !verified_slot || !r->armed || !r->busy ||
       !r->scoped_valid || r->scoped_revision!=r->revision ||
       !same_provider(&r->provider,&r->scoped_policy) ||
       w->event!=r->scoped.event || w->sender!=r->scoped.sender ||
       w->epoch!=r->scoped.epoch ||
       w->delivery_id!=r->scoped.delivery_id ||
       w->event_type!=r->scoped.event_type)return false;
    *verified_slot=r->scoped_slot;
    return true;
}
static bool deliver_scoped(void *context, uintptr_t player,
                           const uint8_t wire[RP_ENGINE_BYTES]) {
    rp_r23_ingress *r=context;
    if(!r || !r->armed || !r->busy || !r->scoped_valid ||
       r->scoped_revision!=r->revision ||
       !same_provider(&r->provider,&r->scoped_policy) ||
       player!=r->scoped.sender ||
       !r->provider.deliver)return false;
    return r->provider.deliver(r->provider.context,player,wire);
}
void rp_r23_init(rp_r23_ingress *r) {if(r)memset(r,0,sizeof *r);}
void rp_r23_stop(rp_r23_ingress *r) {
    if(!r)return;
    ++r->revision;
    r->armed=false;
    r->scoped_valid=false;
    memset(&r->scoped_policy,0,sizeof r->scoped_policy);
    memset(&r->scoped,0,sizeof r->scoped);
    rp_r20_stop(&r->boundary);
    ++r->revoked;
    /* Do not clear busy: nested arming must fail until ingress unwinds. */
}
bool rp_r23_arm(rp_r23_ingress *r,const rp_r23_provider *p) {
    if(!r || !p || r->armed || r->busy ||
       !p->on_game_thread || !p->read_epoch || !p->read_event_type ||
       !p->verify_native || !p->deliver)return false;
    r->provider=*p;
    /* Wrapper callbacks need armed=true. Set it only around arm(), then
     * restore to false on failure, leaving no active R20 boundary. */
    r->armed=true;
    bool ok=rp_r20_arm(&r->boundary,check_thread,read_epoch,
                      attest_scoped,deliver_scoped,r);
    if(!ok){r->armed=false;return false;}
    ++r->revision;
    return true;
}
static bool lease_ok(rp_r23_ingress *r,uint64_t revision,uint64_t epoch) {
    if(!r->armed || !r->busy || r->revision!=revision ||
       !r->provider.on_game_thread || !r->provider.read_epoch ||
       !r->boundary.armed)return false;
    if(!r->provider.on_game_thread(r->provider.context))return false;
    if(!r->armed || r->revision!=revision)return false;
    uint64_t now=r->provider.read_epoch(r->provider.context);
    return r->armed && r->revision==revision && now==epoch &&
           r->boundary.bound_epoch==epoch;
}
rp_r20_result rp_r23_receive_same_call(rp_r23_ingress *r,
    const rp_r23_native_call *n,const uint8_t *job,size_t len) {
    if(rp_r18_early_decision(job,len)==RP_R18_PASS_ORIGINAL){
        if(r)++r->pass_original;
        return RP_R20_PASS_ORIGINAL;
    }
    if(!r)return RP_R20_PRIVATE_REJECTED;
    ++r->attempts;
    if(!r->armed || r->busy || !n || !n->native_event || !n->bit_buffer ||
       !n->candidate_a || !r->provider.verify_native ||
       !r->provider.read_event_type){
        ++r->rejected;return RP_R20_PRIVATE_REJECTED;
    }
    r->busy=true;
    const rp_r23_provider policy=r->provider;
    uint64_t revision=r->revision;
    uint64_t epoch=r->boundary.bound_epoch;
    rp_r20_result result=RP_R20_PRIVATE_REJECTED;
    rp_r23_native_call copy=*n; /* Freeze caller-controlled descriptor. */
    uint32_t type=0;
    uint8_t slot=0xff;
    uint64_t delivery_id=0;
    if(!lease_ok(r,revision,epoch) ||
       !same_provider(&r->provider,&policy))goto done;
    bool read_ok=policy.read_event_type(policy.context,
                                               copy.native_event,&type);
    if(!same_provider(&r->provider,&policy) || !read_ok ||
       !lease_ok(r,revision,epoch) ||
       !same_provider(&r->provider,&policy) ||
       type!=RP_R20_NETWORK_SCRIPT_EVENT_TYPE)goto done;
    bool verified=policy.verify_native(policy.context,&copy,
                                            epoch,&slot,&delivery_id);
    if(!same_provider(&r->provider,&policy) || !verified ||
       !lease_ok(r,revision,epoch) ||
       !same_provider(&r->provider,&policy) ||
       slot>=RP_MAX || !delivery_id)goto done;
    r->scoped=(rp_r20_witness){copy.native_event,copy.candidate_a,
                               epoch,delivery_id,type};
    r->scoped_slot=slot;
    r->scoped_revision=revision;
    r->scoped_policy=policy;
    r->scoped_valid=true;
    /* Retain an independent stack copy: provider callbacks may mutate the
     * runtime object while the R20 lease checks are in progress. */
    const rp_r20_witness frozen=r->scoped;
    result=rp_r20_receive(&r->boundary,&frozen,job,len);
    if(!r->armed || r->revision!=revision)
        result=RP_R20_PRIVATE_REJECTED;
done:
    r->scoped_valid=false;
    memset(&r->scoped_policy,0,sizeof r->scoped_policy);
    memset(&r->scoped,0,sizeof r->scoped);
    r->busy=false;
    if(result==RP_R20_PRIVATE_ACCEPTED)++r->accepted;
    else ++r->rejected;
    return result;
}
