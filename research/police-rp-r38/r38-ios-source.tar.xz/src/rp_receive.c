#include "rp_receive.h"
#include <string.h>
static bool get64(rp_read_memory r,void *c,uintptr_t p,size_t off,uint64_t *v) {
 return p && !(p&7u) && off<=UINTPTR_MAX-8 && p<=UINTPTR_MAX-off-8 && r(c,p+off,v,8);
}
bool rp_peer_id_v13(rp_read_memory r,void *c,uintptr_t p,uintptr_t getter,uint64_t *out) {
 uint64_t vt,fn,data,vt2,data2,id,id2;
 if(out)*out=UINT64_MAX;
 if(!r || !out || !getter || (getter&3u))return false;
 /* GetGamerInfo: *(player+160)+32; GetPeerInfo returns same pointer;
    GetPeerId: *(peerInfo+464), hence data+496. Never call a virtual. */
 if(!get64(r,c,p,0,&vt) || !get64(r,c,vt,56,&fn) || fn!=getter ||
    !get64(r,c,p,160,&data) || !get64(r,c,data,496,&id) || id==UINT64_MAX ||
    !get64(r,c,p,0,&vt2) || vt2!=vt || !get64(r,c,vt2,56,&fn) || fn!=getter ||
    !get64(r,c,p,160,&data2) || data2!=data || !get64(r,c,data2,496,&id2) || id2!=id)return false;
 *out=id;return true;
}
static bool identity_same(rp_session_identity a,rp_session_identity b) {
 return a.session_id==b.session_id && a.host_peer==b.host_peer && a.local_peer==b.local_peer;
}
bool rp_receive_v13(rp_read_memory read,void *ctx,uintptr_t manager,uintptr_t session,
 uintptr_t getter,uintptr_t event,uintptr_t player,const rp_receive_binding *b,
 rp_session_guard *guard,rp_roster *roster,rp_lifecycle *life,rp_engine_kind *kind,rp_inbound *out) {
 if(kind)*kind=0;
 if(out)memset(out,0,sizeof *out);
 if(!read || !b || !guard || !roster || !life || !kind || !out || !b->wire.verified ||
    b->wire.slot>=RP_MAX || !b->wire.epoch || !b->wire.generation || b->player!=player ||
    !player || !b->local_generation || b->peer_id==UINT64_MAX)return false;
 rp_roster_snapshot current;uint64_t id;
 if(!rp_session_audit(guard,read,ctx,session,life))return false;
 if(!identity_same(guard->identity,b->session) ||
    !rp_roster_read_v13(read,ctx,manager,&current) || !rp_roster_audit(roster,&current) ||
    !rp_roster_matches(roster,b->wire.epoch,b->wire.slot,player,b->local_generation) ||
    !rp_peer_id_v13(read,ctx,player,getter,&id) || id!=b->peer_id) {
  rp_lifecycle_stop(life,RP_LIFE_PROVENANCE_LOST);return false;
 }
 rp_engine_kind k;rp_inbound candidate;
 if(!rp_capture_v13(read,ctx,event,player,b->wire,&k,&candidate))return false;
 /* Recheck identity after copying. Not a lock: all reads require serialized
    lifetime-safe integration; double reads do not defeat concurrent ABA. */
 if(!rp_session_audit(guard,read,ctx,session,life) ||
    !rp_roster_read_v13(read,ctx,manager,&current) || !rp_roster_audit(roster,&current) ||
    !rp_peer_id_v13(read,ctx,player,getter,&id) || id!=b->peer_id) {
  rp_lifecycle_stop(life,RP_LIFE_PROVENANCE_LOST);return false;
 }
 *kind=k;*out=candidate;return true;
}
