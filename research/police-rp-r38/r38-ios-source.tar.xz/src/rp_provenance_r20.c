#include "rp_provenance_r20.h"
#include <string.h>

/* R21: fail-closed callback lifecycle hardening on the already-present
 * R20 same-call sender-provenance boundary. No engine hook is installed. */
static uint32_t load32(const uint8_t *p) {
    return (uint32_t)p[0] | ((uint32_t)p[1]<<8) |
           ((uint32_t)p[2]<<16) | ((uint32_t)p[3]<<24);
}
void rp_r20_init(rp_r20_boundary *p) { if(p)memset(p,0,sizeof *p); }
void rp_r20_stop(rp_r20_boundary *p) {
    if(!p)return;
    /* Do NOT clear busy: callback-driven stop must not permit re-arm and
     * nested receive while the original invocation is still executing. */
    ++p->revision;
    p->thread=NULL;p->get_epoch=NULL;p->attest=NULL;p->deliver=NULL;p->ctx=NULL;
    p->bound_epoch=0;p->armed=false;
    memset(p->last_ticket,0,sizeof p->last_ticket);
    memset(p->ticket_used,0,sizeof p->ticket_used);
}
bool rp_r20_arm(rp_r20_boundary *p,rp_r20_on_game_thread thread,
                rp_r20_read_epoch epoch,rp_r20_attest_pair attest,
                rp_r20_deliver_rpe3 deliver,void *ctx) {
    if(!p || p->armed || p->busy || !thread || !epoch || !attest || !deliver)
        return false;
    p->busy=true;
    const uint64_t rev=p->revision;
    bool on_thread=thread(ctx);
    /* Thread callback can stop() and revoke the lease; no further callbacks
     * are allowed in that case. */
    if(!on_thread || p->revision!=rev || p->armed){p->busy=false;return false;}
    uint64_t e=epoch(ctx);
    if(!e || p->revision!=rev || p->armed){p->busy=false;return false;}
    memset(p->last_ticket,0,sizeof p->last_ticket);
    memset(p->ticket_used,0,sizeof p->ticket_used);
    p->thread=thread;p->get_epoch=epoch;p->attest=attest;
    p->deliver=deliver;p->ctx=ctx;p->bound_epoch=e;p->armed=true;
    ++p->revision;
    p->busy=false;
    return true;
}
/* Each callback may recursively revoke the boundary; after every callback
 * recheck revision BEFORE dereferencing the next callback pointer. */
static bool lease_live(rp_r20_boundary *p,uint64_t revision,
                       uint64_t bound_epoch,void *context) {
    if(!p->busy || !p->armed || p->revision!=revision ||
       p->ctx!=context || p->bound_epoch!=bound_epoch ||
       !p->thread || !p->get_epoch || !p->attest || !p->deliver)
        return false;
    rp_r20_on_game_thread on_thread=p->thread;
    if(!on_thread(context))return false;
    if(!p->armed || p->revision!=revision || p->ctx!=context ||
       !p->get_epoch)return false;
    rp_r20_read_epoch epoch=p->get_epoch;
    uint64_t current=epoch(context);
    return p->armed && p->revision==revision && p->ctx==context &&
           p->bound_epoch==bound_epoch && current==bound_epoch;
}
rp_r20_result rp_r20_receive(rp_r20_boundary *p,const rp_r20_witness *w,
                             const uint8_t *job,size_t len) {
    /* PASS_ORIGINAL does not depend on the RP boundary or callbacks. */
    if(!job || len<20 || load32(job)!=RP_R17_MAGIC ||
       load32(job+16)!=RP_R17_CUSTOM_KIND)return RP_R20_PASS_ORIGINAL;
    if(!p)return RP_R20_PRIVATE_REJECTED;
    ++p->attempted;
    if(p->busy){++p->rejected;return RP_R20_PRIVATE_REJECTED;}
    if(!p->armed || !p->thread || !p->get_epoch || !p->attest || !p->deliver ||
       !p->bound_epoch){
        ++p->invalidated;rp_r20_stop(p);
        ++p->rejected;return RP_R20_PRIVATE_REJECTED;
    }
    p->busy=true;
    uint64_t revision=p->revision;
    uint64_t expected_epoch=p->bound_epoch;
    void *context=p->ctx;
    if(!lease_live(p,revision,expected_epoch,context)) {
        ++p->invalidated;rp_r20_stop(p);
        ++p->rejected;p->busy=false;return RP_R20_PRIVATE_REJECTED;
    }
    if(!w || !w->event || !w->sender ||
       w->event_type!=RP_R20_NETWORK_SCRIPT_EVENT_TYPE ||
       w->epoch!=expected_epoch || !w->delivery_id){
        ++p->rejected;p->busy=false;return RP_R20_PRIVATE_REJECTED;
    }
    /* Freeze all untrusted/outer-scope witness fields before invoking an
     * opaque callback. Input may be mutated by reentrant engine work. */
    const rp_r20_witness snapshot=*w;
    uint8_t wire[RP_ENGINE_BYTES]={0};
    uint8_t packet_slot=0xff,real_slot=0xff;
    bool ok=rp_r17_unpack_job(job,len,wire,&packet_slot);
    if(ok){
        rp_r20_attest_pair attest=p->attest;
        bool attested=attest && attest(context,&snapshot,&real_slot);
        /* Validate the lease EVEN WHEN attestation denied the packet: the
         * callback could have changed game session/epoch before denial. */
        bool current=lease_live(p,revision,expected_epoch,context);
        if(!current){++p->invalidated;rp_r20_stop(p);}
        ok=attested && current && real_slot<RP_MAX && packet_slot==real_slot;
    }
    if(ok && p->ticket_used[real_slot] &&
       snapshot.delivery_id<=p->last_ticket[real_slot])ok=false;
    if(ok){
        /* Consume ticket first, even if RPE3 refuses downstream. */
        p->last_ticket[real_slot]=snapshot.delivery_id;
        p->ticket_used[real_slot]=true;
        rp_r20_deliver_rpe3 deliver=p->deliver;
        bool delivered=deliver && deliver(context,snapshot.sender,wire);
        /* Delivery can revoke the session even if it reports failure. */
        bool current=lease_live(p,revision,expected_epoch,context);
        if(!current){++p->invalidated;rp_r20_stop(p);}
        ok=delivered && current;
    }
    memset(wire,0,sizeof wire);
    p->busy=false;
    if(ok){++p->accepted;return RP_R20_PRIVATE_ACCEPTED;}
    ++p->rejected;return RP_R20_PRIVATE_REJECTED;
}
bool rp_r20_deliver_to_r16(void *runtime_r16,uintptr_t sender,
                           const uint8_t wire[RP_ENGINE_BYTES]) {
    if(!runtime_r16 || !wire)return false;
    return rp_r16_transport_receive((rp_runtime_r16 *)runtime_r16,
                                    sender,wire,RP_ENGINE_BYTES);
}
