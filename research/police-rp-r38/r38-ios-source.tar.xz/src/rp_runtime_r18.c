#include "rp_runtime_r18.h"
#include <string.h>

static uint32_t get32(const uint8_t *p) {
    return (uint32_t)p[0] | ((uint32_t)p[1]<<8) |
           ((uint32_t)p[2]<<16) | ((uint32_t)p[3]<<24);
}
void rp_r18_init(rp_runtime_r18 *r) {if(r)memset(r,0,sizeof *r);}
void rp_r18_unbind(rp_runtime_r18 *r) {
    if(!r)return;
    /* Revocation never clears busy: a callback may revoke itself. */
    ++r->revision;
    r->armed=false;r->bound_epoch=0;r->r17=NULL;
    r->on_game_thread=NULL;r->isolated_dispatch=NULL;
    r->read_epoch=NULL;r->context=NULL;
}
/* Single serialized game-thread contract. `busy` remains held while any
 * external callback runs, and revision pins the lease against revocation. */
static bool lease_alive(rp_runtime_r18 *r,uint64_t revision) {
    if(!r->busy || !r->armed || r->revision!=revision)return false;
    /* Runtime may disappear without an explicit R18 disconnect. Revoke the
     * lease rather than leaving an armed, permanently unusable channel. */
    if(!r->r17 || !r->r17->gate || !r->r17->gate->runtime ||
       r->r17->gate->runtime->phase!=RP_R15_ACTIVE ||
       !r->r17->gate->runtime->session.armed ||
       !r->on_game_thread || !r->isolated_dispatch ||
       !r->read_epoch || !r->bound_epoch)goto invalidate;
    void *ctx=r->context;
    rp_r18_check thread=r->on_game_thread;
    bool thread_ok=thread(ctx);
    if(!r->armed || r->revision!=revision)return false;
    if(!thread_ok)goto invalidate;
    rp_r18_check isolation=r->isolated_dispatch;
    bool isolated=isolation(ctx);
    if(!r->armed || r->revision!=revision)return false;
    if(!isolated)goto invalidate;
    rp_r18_epoch epoch=r->read_epoch;
    uint64_t now=epoch(ctx);
    if(!r->armed || r->revision!=revision)return false;
    if(now!=r->bound_epoch)goto invalidate;
    if(r->r17 && r->r17->gate && r->r17->gate->runtime &&
       r->r17->gate->runtime->phase==RP_R15_ACTIVE &&
       r->r17->gate->runtime->session.armed)return true;
    goto invalidate;
invalidate:
    ++r->invalidations;
    rp_r18_unbind(r);
    return false;
}
bool rp_r18_bind(rp_runtime_r18 *r,rp_runtime_r17 *r17,rp_r18_check thread,
                 rp_r18_check isolation,rp_r18_epoch epoch,void *ctx) {
    if(!r || r->armed || r->busy || !r17 || !thread || !isolation || !epoch ||
       !r17->gate || !r17->gate->runtime ||
       r17->gate->runtime->phase!=RP_R15_ACTIVE ||
       !r17->gate->runtime->session.armed || !r17->emit || !r17->attest)
        return false;
    r->busy=true;
    const uint64_t revision=r->revision;
    bool t=thread(ctx);
    if(!t || r->revision!=revision || r->armed)goto fail;
    bool i=isolation(ctx);
    if(!i || r->revision!=revision || r->armed)goto fail;
    uint64_t e=epoch(ctx);
    if(!e || r->revision!=revision || r->armed ||
       !r17->gate || !r17->gate->runtime ||
       r17->gate->runtime->phase!=RP_R15_ACTIVE ||
       !r17->gate->runtime->session.armed || !r17->emit || !r17->attest)
        goto fail;
    r->r17=r17;r->on_game_thread=thread;r->isolated_dispatch=isolation;
    r->read_epoch=epoch;r->context=ctx;r->bound_epoch=e;r->armed=true;
    ++r->revision;
    r->busy=false;
    return true;
fail:
    r->busy=false;
    return false;
}
rp_r18_decision rp_r18_early_decision(const uint8_t *job,size_t len) {
    return job && len>=20 && get32(job)==RP_R17_MAGIC &&
           get32(job+16)==RP_R17_CUSTOM_KIND
           ? RP_R18_PRIVATE_REJECTED : RP_R18_PASS_ORIGINAL;
}
rp_r18_decision rp_r18_receive(rp_runtime_r18 *r,const void *cookie,
                               const uint8_t *job,size_t len) {
    if(!r)return RP_R18_PASS_ORIGINAL;
    /* Only a full magic+kind signature is private.  Other traffic is NEVER
     * interpreted by RP, including truncated headers. */
    if(rp_r18_early_decision(job,len)==RP_R18_PASS_ORIGINAL) {
        ++r->pass_original;
        return RP_R18_PASS_ORIGINAL;
    }
    /* CRITICAL R22: a private command must NEVER fall through into vanilla
     * MPJ2 sequence accounting, even when the RP lease was revoked.  The
     * caller must have installed a real PRE-SEQUENCE private dispatcher and
     * must obey this result; this file cannot install hooks itself. */
    ++r->rejected;
    if(r->busy)return RP_R18_PRIVATE_REJECTED;
    r->busy=true;
    const uint64_t revision=r->revision;
    if(!lease_alive(r,revision) || len!=RP_R17_JOB_BYTES || !cookie) {
        r->busy=false;
        return RP_R18_PRIVATE_REJECTED;
    }
    rp_runtime_r17 *r17=r->r17;
    bool accepted=rp_r17_receive(r17,cookie,job,len);
    /* A successful delivery cannot claim success after a callback revoked
     * the RP session or changed the runtime state. */
    bool still_alive=lease_alive(r,revision) && r->r17==r17;
    r->busy=false;
    if(accepted && still_alive) {
        --r->rejected;
        ++r->handled;
        return RP_R18_PRIVATE_HANDLED;
    }
    return RP_R18_PRIVATE_REJECTED;
}
bool rp_r18_send(rp_runtime_r18 *r,uint8_t target,const uint8_t wire[RP_ENGINE_BYTES]) {
    if(!r || r->busy || !wire)return false;
    r->busy=true;
    const uint64_t revision=r->revision;
    if(!lease_alive(r,revision)){r->busy=false;return false;}
    rp_runtime_r17 *r17=r->r17;
    bool queued=rp_r17_send(r17,target,wire);
    bool still_alive=lease_alive(r,revision) && r->r17==r17;
    r->busy=false;
    if(!queued || !still_alive)return false;
    ++r->sent;
    return true;
}
