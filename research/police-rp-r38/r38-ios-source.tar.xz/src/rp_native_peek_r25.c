#include "rp_native_peek_r25.h"
#include "rp_runtime_r18.h"
#include <limits.h>
#include <string.h>

static bool same(const rp_r24_cursor *a, const rp_r24_cursor *b) {
    return a->read_bit==b->read_bit && a->limit_bit==b->limit_bit &&
           a->storage_generation==b->storage_generation;
}
static bool bounds(const rp_r24_cursor *c, uint32_t nbytes) {
    uint64_t bits=(uint64_t)nbytes*8;
    return c->storage_generation!=0 && c->read_bit<=c->limit_bit &&
           c->limit_bit<=RP_R24_MAX_EVENT_BITS &&
           c->read_bit<=INT_MAX && c->limit_bit-c->read_bit>=bits;
}
static bool run_peek(rp_r25_decoder *d, const void *buffer, void *out,
                     int count, int start_bit) {
    if(d->guarded_peek)
        return d->guarded_peek(d->context,buffer,out,count,start_bit);
    return d->native_peek && d->native_peek(buffer,out,count,start_bit);
}
void rp_r25_decoder_init(rp_r25_decoder *d,rp_r24_read_cursor read,
                         rp_r25_native_peek peek,rp_r25_binding_gate gate,
                         void *context){
    if(!d)return;
    memset(d,0,sizeof *d);
    d->cursor=read; d->native_peek=peek;
    d->bound_to_v133=gate;d->context=context;
}
bool rp_r25_snapshot_cursor(void *context, uintptr_t bitbuffer,
                            rp_r24_cursor *out) {
    rp_r25_decoder *d=context;
    if(!d || !out || !bitbuffer || !d->cursor || !d->bound_to_v133 ||
       !d->bound_to_v133(d->context))return false;
    return d->cursor(d->context,bitbuffer,out);
}
/* Return a 20-byte recognizable PRIVATE header even when the remaining 224B
 * are truncated/corrupted. R24 then returns PRIVATE_REJECTED rather than
 * forwarding the header to vanilla Jobs. Never authorize from this decoder:
 * R23 must independently verify the real RAGE sender and delivery ID.
 */
bool rp_r25_peek_mpj2(void *context,const rp_r23_native_call *call,
                       uint8_t *out,size_t capacity,size_t *decoded_len) {
    rp_r25_decoder *d=context;
    if(decoded_len)*decoded_len=0;
    if(!d || !call || !call->bit_buffer || !out || !decoded_len ||
       capacity!=RP_R17_JOB_BYTES || !d->cursor || (!d->native_peek && !d->guarded_peek) ||
       !d->bound_to_v133 || !d->bound_to_v133(d->context))return false;
    rp_r24_cursor before={0},after={0};
    uint8_t header[20]={0};
    if(!d->cursor(d->context,call->bit_buffer,&before) ||
       !bounds(&before,sizeof header))goto bad;
    if(!run_peek(d,(const void *)call->bit_buffer,header,
                       (int)sizeof header,(int)before.read_bit))goto bad;
    ++d->header_reads;
    if(!d->cursor(d->context,call->bit_buffer,&after) ||
       !same(&before,&after)){
        ++d->cursor_faults;
        /* If cursor was corrupted, R24's own after-check disables the bridge.
         * No private classification is trusted from a faulty native call. */
        goto bad;
    }
    memcpy(out,header,sizeof header);
    *decoded_len=sizeof header;
    if(rp_r18_early_decision(header,sizeof header)==RP_R18_PASS_ORIGINAL)
        return true; /* vanilla MPJ2, no full-body read */
    if(!bounds(&before,RP_R17_JOB_BYTES))return true; /* truncated private */
    /* Do not overwrite the classified header in case native reads partially
     * write and then fail; R24 will reject the private message. */
    uint8_t full[RP_R17_JOB_BYTES]={0};
    bool ok=run_peek(d,(const void *)call->bit_buffer,full,
                           RP_R17_JOB_BYTES,(int)before.read_bit);
    if(!d->cursor(d->context,call->bit_buffer,&after) ||
       !same(&before,&after)){
        ++d->cursor_faults;
        memset(full,0,sizeof full);
        return true; /* Preserve known-private header to reject */
    }
    if(!ok){memset(full,0,sizeof full);return true;}
    /* Require byte-for-byte stable header across the two native peeks. */
    if(memcmp(header,full,sizeof header)){
        memset(full,0,sizeof full);
        return true;
    }
    /* A second full snapshot detects in-callback changes that might not
     * affect the first 20 bytes. This is not a substitute for ownership or
     * a genuinely serialized RAGE dispatch; it is defense in depth. */
    uint8_t confirmed[RP_R17_JOB_BYTES]={0};
    bool stable=run_peek(d,(const void *)call->bit_buffer,confirmed,
                               RP_R17_JOB_BYTES,(int)before.read_bit);
    if(!d->cursor(d->context,call->bit_buffer,&after) ||
       !same(&before,&after)){
        ++d->cursor_faults;
        stable=false;
    }
    if(!stable || memcmp(full,confirmed,sizeof full)){
        memset(full,0,sizeof full);
        memset(confirmed,0,sizeof confirmed);
        return true; /* preserve header and reject untrusted body */
    }
    memcpy(out,full,sizeof full);
    *decoded_len=sizeof full;
    ++d->private_full_reads;
    memset(full,0,sizeof full);
    memset(confirmed,0,sizeof confirmed);
    return true;
bad:
    ++d->rejected;
    memset(header,0,sizeof header);
    return false;
}
