#include "rp_presequence_r28.h"
#include "rp_runtime_r18.h"
#include <string.h>

/* Compare explicit members: no assumptions about structure padding or ABI.
 * The caller's descriptor is not owned by us and may be mutated by callbacks. */
static bool same_call(const rp_r23_native_call *a, const rp_r23_native_call *b) {
    return a->native_event==b->native_event &&
           a->bit_buffer==b->bit_buffer &&
           a->candidate_a==b->candidate_a &&
           a->candidate_b==b->candidate_b;
}

/* A provider must not replace the security policy mid-delivery. This is
 * separate from the caller-owned native event descriptor (R30). */
static bool same_config(const rp_r28_presequence *g,
                        rp_r28_copy_prefix prefix,
                        rp_r28_presequence_proven proof,
                        rp_r24_bridge *bridge,void *context) {
    return g->prefix==prefix && g->presequence==proof &&
           g->bridge==bridge && g->context==context;
}

/* R33: snapshot nested callback policies, not just the outer bridge pointer.
 * A proof/prefix callback must not change the R24 isolation policy or R23
 * identity verifier before dispatch. Compare explicit members; structs can
 * contain padding and cannot be safely memcmp()'d. */
typedef struct {
    rp_r24_bridge *bridge;
    uint64_t bridge_revision;
    rp_r24_provider provider;
    rp_r23_ingress *ingress;
    uint64_t ingress_revision;
    rp_r23_provider identity;
} rp_r33_policy;
static rp_r33_policy capture_policy(rp_r24_bridge *b) {
    rp_r33_policy s={0};
    s.bridge=b;
    if(!b)return s;
    s.bridge_revision=b->revision;
    s.provider=b->provider;
    s.ingress=b->ingress;
    if(s.ingress){
        s.ingress_revision=s.ingress->revision;
        s.identity=s.ingress->provider;
    }
    return s;
}
static bool bound_policy_unchanged(const rp_r33_policy *s) {
    if(!s->bridge)return true;
    const rp_r24_bridge *b=s->bridge;
    if(b->revision!=s->bridge_revision || b->ingress!=s->ingress ||
       b->provider.cursor!=s->provider.cursor ||
       b->provider.peek!=s->provider.peek ||
       b->provider.isolated!=s->provider.isolated ||
       b->provider.context!=s->provider.context)return false;
    if(!s->ingress)return true;
    const rp_r23_ingress *r=s->ingress;
    return r->revision==s->ingress_revision &&
           r->provider.on_game_thread==s->identity.on_game_thread &&
           r->provider.read_epoch==s->identity.read_epoch &&
           r->provider.read_event_type==s->identity.read_event_type &&
           r->provider.verify_native==s->identity.verify_native &&
           r->provider.deliver==s->identity.deliver &&
           r->provider.context==s->identity.context;
}

void rp_r28_init(rp_r28_presequence *g, rp_r24_bridge *b,
                 rp_r28_copy_prefix prefix,
                 rp_r28_presequence_proven presequence, void *context) {
    if (!g) return;
    memset(g, 0, sizeof *g);
    g->bridge=b;
    g->prefix=prefix;
    g->presequence=presequence;
    g->context=context;
}

rp_r20_result rp_r28_dispatch(rp_r28_presequence *g,
                               const rp_r23_native_call *n) {
    if (!g || !n || !n->native_event || !n->bit_buffer || !g->prefix)
        return RP_R20_PASS_ORIGINAL;
    ++g->attempts;
    /* Freeze the exact descriptor on entry. Never let a callback swap the
     * event, buffer, or sender between classification and verification. */
    const rp_r23_native_call frozen=*n;
    const rp_r28_copy_prefix prefix=g->prefix;
    const rp_r28_presequence_proven proof=g->presequence;
    rp_r24_bridge *const bridge=g->bridge;
    void *const context=g->context;
    const rp_r33_policy bound=capture_policy(bridge);
    if (g->scanning) {
        /* A provider tried to dispatch another event during a memory read
         * or a provenance check. Identity is not safely classifiable here. */
        ++g->nested;
        ++g->private_drop;
        return RP_R20_PRIVATE_REJECTED;
    }
    g->scanning=true;
    uint8_t first[RP_R28_PREFIX_BYTES]={0};
    uint8_t second[RP_R28_PREFIX_BYTES]={0};
    /* Both reads must be non-mutating, same-delivery snapshots. We cannot
     * identify an unreadable RP packet safely: it remains vanilla traffic.
     * The platform must not install this hook until this ambiguity is solved.
     */
    rp_r20_result result=RP_R20_PASS_ORIGINAL;
    const bool have_first=prefix(context,&frozen,first);
    const bool first_private=have_first &&
        rp_r18_early_decision(first,sizeof first)!=RP_R18_PASS_ORIGINAL;
    /* Do not call the provider again if it changed the bound configuration.
     * Without a classified PRIVATE header, this ambiguity remains unsafe
     * for an installed hook, just as for an unreadable packet. */
    const bool config_ok_first=same_config(g,prefix,proof,bridge,context);
    const bool policy_ok_first=bound_policy_unchanged(&bound);
    if (!config_ok_first || !policy_ok_first) {
        if(!config_ok_first)++g->config_changed;
        if(!policy_ok_first)++g->policy_changed;
        g->scanning=false;
        result=first_private ? RP_R20_PRIVATE_REJECTED
                             : RP_R20_PASS_ORIGINAL;
        goto finish;
    }
    const bool have_second=prefix(context,&frozen,second);
    const bool changed_during_prefix=!same_call(n,&frozen);
    const bool second_private=have_second &&
        rp_r18_early_decision(second,sizeof second)!=RP_R18_PASS_ORIGINAL;
    g->scanning=false;
    const bool config_ok_second=same_config(g,prefix,proof,bridge,context);
    const bool policy_ok_second=bound_policy_unchanged(&bound);
    if (!config_ok_second || !policy_ok_second) {
        if(!config_ok_second)++g->config_changed;
        if(!policy_ok_second)++g->policy_changed;
        if(first_private || second_private)result=RP_R20_PRIVATE_REJECTED;
        goto finish;
    }
    if(changed_during_prefix){
        ++g->descriptor_changed;
        /* Already-classified PRIVATE packets cannot fall through to Jobs.
         * Unknown packets cannot be safely classified by this source guard. */
        if(first_private || second_private)result=RP_R20_PRIVATE_REJECTED;
        goto finish;
    }
    if (!first_private && !second_private) goto finish;
    result=RP_R20_PRIVATE_REJECTED;
    /* If either observation recognized a PRIVATE command, never allow it
     * through the vanilla Jobs sequence path, even if the other read fails.
     * These checks apply to a callback with game-owned lifetime guarantees.
     */
    if (!have_first || !have_second || memcmp(first,second,sizeof first)) {
        ++g->unstable;
        goto finish;
    }
    if (g->busy) {
        ++g->nested;
        goto finish;
    }
    g->scanning=true;
    const bool proven=proof && proof(context,&frozen);
    g->scanning=false;
    const bool config_ok_proof=same_config(g,prefix,proof,bridge,context);
    const bool policy_ok_proof=bound_policy_unchanged(&bound);
    if(!config_ok_proof || !policy_ok_proof) {
        if(!config_ok_proof)++g->config_changed;
        if(!policy_ok_proof)++g->policy_changed;
        goto finish;
    }
    if(!same_call(n,&frozen)){
        ++g->descriptor_changed;
        goto finish;
    }
    if (!proven) {
        ++g->unproven;
        goto finish;
    }
    if (!bridge || !bridge->armed || bridge->busy ||
        bridge->faulted) goto finish;
    g->busy=true;
    const rp_r20_result inner=rp_r24_snapshot_dispatch(bridge,&frozen);
    g->busy=false;
    const bool config_ok_inner=same_config(g,prefix,proof,bridge,context);
    const bool policy_ok_inner=bound_policy_unchanged(&bound);
    if(!config_ok_inner || !policy_ok_inner){
        if(!config_ok_inner)++g->config_changed;
        if(!policy_ok_inner)++g->policy_changed;
        goto finish;
    }
    /* R24 returns PASS_ORIGINAL when the RP lease expires or a decoder fails.
     * That is NOT permission to forward this already-classified PRIVATE job.
     */
    if (inner==RP_R20_PRIVATE_ACCEPTED) result=inner;
finish:
    memset(first,0,sizeof first);
    memset(second,0,sizeof second);
    if (result==RP_R20_PRIVATE_ACCEPTED)++g->private_accepted;
    else if (result==RP_R20_PRIVATE_REJECTED)++g->private_drop;
    else ++g->normal;
    return result;
}
