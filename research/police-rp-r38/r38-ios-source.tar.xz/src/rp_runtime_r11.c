#include "rp_runtime_r11.h"
#include <string.h>
static bool peer_ok(rp_engine_peer p) {
 return p.verified && p.slot<RP_MAX && p.generation && p.epoch;
}
bool rp_r11_begin(rp_runtime_r11 *r,rp_engine_peer local,rp_engine_peer host,bool is_host) {
 if(!r)return false;
 memset(r,0,sizeof *r);
 if(!peer_ok(local)||!peer_ok(host)||local.epoch!=host.epoch ||
    (is_host && (local.slot!=host.slot || local.generation!=host.generation)))return false;
 r->local=local;r->host=host;r->local_is_host=is_host;
 rp_service_init(&r->service,local.epoch);
 rp_sender_init(&r->sender,local.epoch,local.slot,local.generation);
 rp_client_init(&r->client,local.epoch,local.slot,local.generation);
 r->initialized=true;return true;
}
void rp_r11_close(rp_runtime_r11 *r) { if(r)memset(r,0,sizeof *r); }
bool rp_r11_host_join(rp_runtime_r11 *r,uint8_t slot,uint32_t gen,bool consent) {
 return r && r->initialized && r->local_is_host && rp_join(&r->service.host,slot,gen,consent);
}
bool rp_r11_host_observe(rp_runtime_r11 *r,uint8_t slot,rp_role role,rp_observation o) {
 return r && r->initialized && r->local_is_host && rp_observe(&r->service.host,slot,role,o);
}
void rp_r11_tick(rp_runtime_r11 *r,uint64_t now) {
 if(!r||!r->initialized)return;
 if(r->local_is_host)rp_tick(&r->service.host,now);
 rp_client_tick(&r->client,now);
}
bool rp_r11_submit(rp_runtime_r11 *r,rp_action action,uint8_t target,
                   uint32_t target_gen,uint32_t arg,uint64_t now) {
 return r && r->initialized && peer_ok(r->local) &&
        rp_sender_submit(&r->sender,action,target,target_gen,arg,now);
}
bool rp_r11_next(rp_runtime_r11 *r,uint64_t now,uint8_t out[RP_ENGINE_BYTES]) {
 uint8_t req[RP_WIRE];
 return r && r->initialized && out && rp_sender_poll(&r->sender,now,req) &&
        rp_engine_pack(r->local.slot,RP_ENGINE_REQUEST,req,sizeof req,out);
}
bool rp_r11_host_receive(rp_runtime_r11 *r,rp_engine_peer actual,
                         const uint8_t wire[RP_ENGINE_BYTES],
                         uint8_t ack[RP_ENGINE_BYTES],
                         uint8_t snapshot[RP_ENGINE_BYTES],uint8_t *target) {
 if(target)*target=RP_NONE;
 if(ack)memset(ack,0,RP_ENGINE_BYTES);
 if(snapshot)memset(snapshot,0,RP_ENGINE_BYTES);
 if(!r||!r->initialized||!r->local_is_host||!wire||!ack||!snapshot||!target||
    !peer_ok(actual)||actual.epoch!=r->host.epoch ||
    !r->service.host.p[actual.slot].joined ||
    r->service.host.p[actual.slot].generation!=actual.generation)return false;
 rp_engine_kind kind;rp_inbound payload;rp_request request;
 if(!rp_engine_unpack(wire,RP_ENGINE_BYTES,actual,&kind,&payload) ||
    kind!=RP_ENGINE_REQUEST || !rp_decode(payload.bytes,payload.length,&request))return false;
 if(!rp_bridge_host_request(&r->service,r->host,actual,wire,RP_ENGINE_BYTES,ack))return false;
 /* Reply snapshot even when request is denied; state remains authoritative.
    The target is a *request field*, not an authenticated sender. */
 if(rp_bridge_snapshot(&r->service,r->host,request.target,snapshot))
    *target=request.target;
 /* No snapshot for a non-member/non-consenting target; preserve the ACK so
    a rejected request is not retried indefinitely. *target remains RP_NONE. */
 return true;
}
bool rp_r11_client_receive(rp_runtime_r11 *r,rp_engine_peer actual,
                           const uint8_t wire[RP_ENGINE_BYTES],uint64_t now) {
 return r && r->initialized && wire &&
        rp_bridge_client_receive(&r->sender,&r->client,r->host,actual,
                                 wire,RP_ENGINE_BYTES,now);
}
