#include "rp_native_clone_r26.h"
#include <limits.h>
#include <string.h>

static uint32_t read_le32(const uint8_t *p) {
    return (uint32_t)p[0] | (uint32_t)p[1]<<8 |
           (uint32_t)p[2]<<16 | (uint32_t)p[3]<<24;
}
static uint64_t read_le64(const uint8_t *p) {
    return (uint64_t)read_le32(p) | (uint64_t)read_le32(p+4)<<32;
}
static bool bound(rp_r26_clone *c){
    return c && c->bound && c->bound(c->context);
}
/* Local header parse is an ARM64 *static* layout finding. No RTTI assumption.
 * Flags bit 1 blocks reads in the native, bit 0 selects +0x0c vs +0x14.
 */
static bool parse(const uint8_t h[RP_R26_HEADER_BYTES],uint64_t token,
                  rp_r24_cursor *out) {
    if(!h || !out || !token || !read_le64(h) || (h[0x1c]&2u))return false;
    const uint32_t offset=read_le32(h+0x08);
    const uint32_t limit=read_le32(h+((h[0x1c]&1u)?0x0c:0x14));
    const uint32_t cursor=read_le32(h+0x10);
    if(offset>RP_R24_MAX_EVENT_BITS || !limit ||
       limit>RP_R24_MAX_EVENT_BITS || cursor>limit || cursor>INT_MAX)
        return false;
    *out=(rp_r24_cursor){cursor,limit,token};
    return true;
}
static bool snapshot(rp_r26_clone *c,uintptr_t p,
                     uint8_t h[RP_R26_HEADER_BYTES],rp_r24_cursor *cursor) {
    uint64_t token=0;
    if(!p || !bound(c) || !c->copy_header || !c->token ||
       !c->token(c->context,&token) || !token ||
       !c->copy_header(c->context,p,h) || !parse(h,token,cursor))return false;
    ++c->header_snapshots;
    return true;
}
bool rp_r26_snapshot_cursor(void *context,uintptr_t original,
                            rp_r24_cursor *out) {
    rp_r26_clone *c=context;
    uint8_t h[RP_R26_HEADER_BYTES]={0};
    if(!c || !out || !snapshot(c,original,h,out)){
        if(c)++c->denied;
        return false;
    }
    return true;
}
static bool bound_context(void *context) {
    return bound((rp_r26_clone *)context);
}
static bool cloned_peek(void *context,const void *original,void *dst,
                        int bytes,int start) {
    rp_r26_clone *c=context;
    if(!c || !original || !dst || !c->busy ||
       (c->owned_backing && c->owned_poisoned) ||
       (uintptr_t)original!=c->active_buffer ||
       !c->native || bytes<=0 || (unsigned)bytes>RP_R17_JOB_BYTES || start<0){
        if(c)++c->denied;
        return false;
    }
    uint8_t h[RP_R26_HEADER_BYTES]={0}, check[RP_R26_HEADER_BYTES]={0};
    rp_r24_cursor before={0}, after={0};
    if(!snapshot(c,(uintptr_t)original,h,&before) ||
       (uint64_t)start!=before.read_bit ||
       (uint64_t)bytes*8 > before.limit_bit-before.read_bit){
        ++c->denied;return false;
    }
    /* ARM64 naturally aligned private 32-byte clone. The native may write
     * to +0x10/+0x18 of THIS clone, never to the game-owned cursor. */
    uint64_t clone_words[RP_R26_HEADER_BYTES/sizeof(uint64_t)]={0};
    memcpy(clone_words,h,sizeof h);
    /* R27 optional strict mode: isolate not only the 32-byte header, but
     * also the referenced backing bits. The v13.3 ARM64 PeekBytes routine
     * computes backing + (offset >> 3) and passes (offset & 7) + start to
     * CopyBits. Rebase those bits to an owned 245-byte bounded snapshot.
     * This cannot by itself establish sender/transport provenance.
     */
    uint8_t owned[RP_R17_JOB_BYTES+32u]={0};
    uintptr_t source_at=0;
    size_t source_bytes=0;
    int call_start=start;
    if(c->owned_backing) {
        const uint32_t bit_offset=read_le32(h+0x08);
        const uintptr_t backing=(uintptr_t)read_le64(h);
        const uint64_t absolute=(uint64_t)bit_offset+(uint32_t)start;
        const uint64_t byte_offset=absolute/8u;
        const uint32_t trailing=(uint32_t)(absolute&7u);
        const size_t needed=(size_t)bytes+(trailing?1u:0u);
        if(!backing || bit_offset>RP_R24_MAX_EVENT_BITS ||
           absolute>UINT64_C(2)*RP_R24_MAX_EVENT_BITS ||
           byte_offset>UINTPTR_MAX || backing>UINTPTR_MAX-(uintptr_t)byte_offset ||
           needed>RP_R17_JOB_BYTES+1u ||
           !c->owned_backing(c->context,backing+(uintptr_t)byte_offset,
                             owned,needed)) {
            ++c->owned_denied; ++c->denied;
            memset(owned,0,sizeof owned);
            return false;
        }
        source_at=backing+(uintptr_t)byte_offset;
        source_bytes=needed;
        uintptr_t private_ptr=(uintptr_t)owned;
        memcpy((uint8_t *)clone_words,&private_ptr,sizeof private_ptr);
        /* Native source address is now owned[0], bit offset 0..7. */
        uint8_t *cl=(uint8_t *)clone_words;
        for(unsigned i=0;i<4;++i)cl[0x08+i]=(uint8_t)(trailing>>(i*8));
        call_start=0;
        ++c->owned_snapshots;
    }
    ++c->native_calls;
    const bool ok=c->native(clone_words,dst,bytes,call_start);
    ++c->cloned_calls;
    /* A second, independent checked read detects backing-store mutation
     * during the native call. It does not provide atomicity against a
     * concurrent writer; engine-side serialization is still mandatory. */
    if(c->owned_backing) {
        uint8_t proof[RP_R17_JOB_BYTES+1u]={0};
        bool stable=c->owned_backing(c->context,source_at,proof,source_bytes) &&
                    memcmp(owned,proof,source_bytes)==0;
        memset(proof,0,sizeof proof);
        if(!stable){
            ++c->drift;
            memset(owned,0,sizeof owned);
            /* A successfully decoded 20B header is still an independently
             * owned snapshot: return it ONLY for early RP classification,
             * then poison any subsequent full-body read in this delivery.
             * This prevents a known-private packet falling into vanilla
             * Jobs merely because backing changed during classification.
             * Never authorize gameplay from this unstable header. */
            if(ok && bytes==20){
                c->owned_poisoned=true;
                return true;
            }
            return false;
        }
    }
    memset(owned,0,sizeof owned);
    if(!snapshot(c,(uintptr_t)original,check,&after) ||
       memcmp(check,h,sizeof h)!=0 ||
       before.read_bit!=after.read_bit ||
       before.limit_bit!=after.limit_bit ||
       before.storage_generation!=after.storage_generation){
        ++c->drift;
        return false;
    }
    return ok;
}
bool rp_r26_clone_init(rp_r26_clone *c, rp_r26_copy_header reader,
                       rp_r26_delivery_token token, rp_r25_native_peek native,
                       rp_r25_binding_gate gate, void *context) {
    if(!c)return false;
    memset(c,0,sizeof *c);
    if(!reader || !token || !native || !gate)return false;
    c->copy_header=reader;c->token=token;
    c->native=native;c->bound=gate;c->context=context;
    /* R25's parsing and double-full-peek remain in use. ONLY the call site
     * of the native method is redirected onto our temporary clone. */
    rp_r25_decoder_init(&c->decoder,rp_r26_snapshot_cursor,NULL,
                         bound_context,c);
    c->decoder.guarded_peek=cloned_peek;
    return true;
}
bool rp_r26_peek_mpj2(void *context,const rp_r23_native_call *n,
                       uint8_t *out,size_t capacity,size_t *decoded_len) {
    rp_r26_clone *c=context;
    if(decoded_len)*decoded_len=0;
    if(!c || c->busy || !n || !n->bit_buffer || !bound(c)) {
        if(c)++c->denied;
        return false;
    }
    c->busy=true;
    c->owned_poisoned=false;
    c->active_buffer=n->bit_buffer;
    const bool result=rp_r25_peek_mpj2(&c->decoder,n,out,capacity,decoded_len);
    c->active_buffer=0;
    c->busy=false;
    return result;
}

bool rp_r26_make_provider(rp_r26_clone *c,
                          rp_r24_private_isolation isolation,
                          rp_r24_provider *out) {
    if(!c || !out || !isolation || !c->copy_header || !c->token ||
       !c->native || !c->bound || !bound(c))return false;
    *out=(rp_r24_provider){rp_r26_snapshot_cursor,rp_r26_peek_mpj2,
                           isolation,c};
    return true;
}
