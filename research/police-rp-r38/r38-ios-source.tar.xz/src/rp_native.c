#include "rp_native.h"
#include <limits.h>
#include <math.h>
#include <stddef.h>
#include <string.h>
_Static_assert(offsetof(rp_scr_vector,y)==8 && offsetof(rp_scr_vector,z)==16 && sizeof(rp_scr_vector)==24,"scrVector ABI");
static bool ready(rp_native *n,const rp_native_frame *f) {
    return n && f && n->bound && f->game_thread && f->online && f->local_ped_verified &&
        n->api.script_handler && n->api.script_handler() && n->api.player_ped &&
        n->api.entity_exists && n->api.handcuffs && n->api.disable_control &&
        n->api.follow && n->api.coords && f->local_ped>0 &&
        n->api.player_ped()==f->local_ped && n->api.entity_exists(f->local_ped);
}
bool rp_native_send(rp_native *n,bool thread,bool online,uint8_t local,
                    uint32_t recipients,rp_engine_kind kind,const uint8_t*b,size_t size) {
    if(!n || !n->bound || !thread || !online || local>=RP_MAX || !n->api.trigger_event ||
       !n->api.script_handler || !n->api.script_handler())return false;
    recipients &= ~(UINT32_C(1)<<local);
    if(!recipients)return false; /* Host-local requests use direct local service. */
    _Alignas(8) uint8_t envelope[RP_ENGINE_BYTES];
    if(!rp_engine_pack(local,kind,b,size,envelope))return false;
    int mask; _Static_assert(sizeof mask==sizeof recipients,"32-bit mask ABI");
    memcpy(&mask,&recipients,sizeof mask);
    /* v13 CommandTriggerScriptEvent multiplies count by 8, NOT by 4. */
    n->api.trigger_event(1,(int *)(void *)envelope,RP_ENGINE_SLOTS,mask);
    return true; /* Dispatched; not a delivery confirmation. */
}
bool rp_native_clear(rp_native *n,const rp_native_frame *f) {
    if(!n || !f || !n->bound || !f->game_thread || !n->api.script_handler ||
       !n->api.script_handler() || !n->api.entity_exists || !n->api.handcuffs)return false;
    /* Lack of provenance is not proof the old effect is gone. Keep ownership
       so teardown can retry on a verified script frame. */
    if(n->cuff_owned && (!f->local_ped_verified || !n->api.player_ped ||
       n->api.player_ped()!=f->local_ped)) return false;
    /* The old local ped can be gone after death/model swap. Never touch its
       handle if a new entity may have inherited it: require same current ped. */
    if(n->cuff_owned && n->ped==f->local_ped && f->local_ped_verified &&
       n->api.player_ped && n->api.player_ped()==n->ped && n->api.entity_exists(n->ped))
        n->api.handcuffs(n->ped,false);
    n->cuff_owned=false;n->follow_owned=false;n->jail_placed=false;
    n->ped=0;n->owner_ped=0;n->state=RP_FREE;n->next_follow_ms=0;
    /* Follow has a 600ms finite native timeout. No ClearPedTasks: avoid wiping
       unrelated tasks. Control disables stop being refreshed on next frame. */
    return true;
}
bool rp_native_apply(rp_native *n,const rp_native_frame *f,rp_state state) {
    if(!ready(n,f) || state<RP_FREE || state>RP_JAILED)return false;
    if(state==RP_FREE)return rp_native_clear(n,f);
    if(state==RP_ESCORTED && (!f->owner_verified || f->owner_ped<=0 ||
        f->owner_ped==f->local_ped || !n->api.entity_exists(f->owner_ped)))return false;
    if(state==RP_JAILED && (!f->jail_verified || !isfinite(f->jail.x) ||
        !isfinite(f->jail.y) || !isfinite(f->jail.z) || fabsf(f->jail.x)>10000 ||
        fabsf(f->jail.y)>10000 || fabsf(f->jail.z)>2000))return false;
    if(n->ped && n->ped!=f->local_ped) {
        /* Needs a proven ped-incarnation lifecycle; do not transfer restraint
           automatically to a freshly respawned/replaced local character. */
        return false;
    }
    n->ped=f->local_ped;
    if(!n->cuff_owned){n->api.handcuffs(n->ped,true);n->cuff_owned=true;}
    const int controls[]={24,25,22,23,37,44,45,75,140,141,142,143};
    for(size_t i=0;i<sizeof controls/sizeof controls[0];++i)n->api.disable_control(0,controls[i],true);
    if(state==RP_ESCORTED) {
        if(n->state!=state || n->owner_ped!=f->owner_ped || f->now_ms>=n->next_follow_ms) {
            const rp_scr_vector offset={0,0,-1.0f,0,0,0};
            n->api.follow(n->ped,f->owner_ped,&offset,1.0f,600,1.0f,true);
            n->follow_owned=true;n->owner_ped=f->owner_ped;
            n->next_follow_ms=UINT64_MAX-f->now_ms<500?UINT64_MAX:f->now_ms+500;
        }
    } else {n->follow_owned=false;n->owner_ped=0;}
    if(state==RP_JAILED) {
        if(n->state!=state || !n->jail_placed){n->api.coords(n->ped,&f->jail,false,false,true,false);n->jail_placed=true;}
        n->api.disable_control(0,30,true);n->api.disable_control(0,31,true);
    } else n->jail_placed=false;
    n->state=(uint8_t)state;return true; /* Calls issued, not native effect proof. */
}
