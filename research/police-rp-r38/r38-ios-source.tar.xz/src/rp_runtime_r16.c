#include "rp_runtime_r16.h"
#include <string.h>

void rp_r16_init(rp_runtime_r16 *r,rp_runtime_r15 *runtime) {
    if(!r)return;
    memset(r,0,sizeof *r);
    r->runtime=runtime;
}

/* NEVER infer RP payload length from event+0x224. It is an event kind. */
bool rp_r16_decide(rp_runtime_r16 *r,rp_r16_original_decide original,
                   void *original_ctx,uintptr_t event,uintptr_t player_a,
                   uintptr_t player_b) {
    if(!original)return false;
    /* Call original once, including on reentrant callbacks. A passive
       observer must not decide the engine's handling/return result. */
    bool result=original(original_ctx,event,player_a,player_b);
    if(!r || r->in_observer || !r->runtime ||
       r->runtime->phase!=RP_R15_ACTIVE) {
        if(r && r->in_observer)++r->reentrant;
        return result;
    }
    r->in_observer=true;
    rp_runtime_r13 *session=&r->runtime->session;
    rp_r13_provider *p=&session->provider;
    if(p->on_game_thread && p->read && p->on_game_thread(p->context) &&
       event && event<=UINTPTR_MAX-548u &&
       player_a && player_a<=UINTPTR_MAX-33u) {
        uint32_t kind=0;uint8_t hint=0xff;
        if(p->read(p->context,event+548u,&kind,sizeof kind) &&
           p->read(p->context,player_a+33u,&hint,sizeof hint)) {
            r->last_event_type=kind;
            r->last_slot_hint=hint;
            ++r->vanilla_observed;
        }
    }
    r->in_observer=false;
    return result;
}

static bool same(rp_engine_peer a,rp_engine_peer b) {
    return a.verified && b.verified && a.slot==b.slot &&
           a.generation==b.generation && a.epoch==b.epoch;
}

bool rp_r16_transport_receive(rp_runtime_r16 *r,uintptr_t player,
                              const uint8_t *wire,size_t len) {
    if(!r)return false;
    if(r->in_observer || !r->runtime || !wire || len!=RP_ENGINE_BYTES ||
       !player || r->runtime->phase!=RP_R15_ACTIVE ||
       !r->runtime->session.armed) {++r->transport_rejected;return false;}
    r->in_observer=true;
    rp_runtime_r13 *session=&r->runtime->session;
    rp_runtime_r12 *net=&session->runtime;
    rp_r13_provider *p=&session->provider;
    bool ok=false,opt=false;
    rp_engine_peer actual={0};
    uint64_t peer_id=UINT64_MAX;
    uint8_t engine_slot=0xff;
    if(!p->on_game_thread || !p->resolve || !p->read ||
       !p->on_game_thread(p->context))goto out;
    /* Underlying audit invalidates the RP session on changed roster/session.
       Never automatically send a packet back from a network callback. */
    if(!rp_r12_audit_engine(net)) {
        rp_r15_stop(r->runtime);goto out;
    }
    if(!p->resolve(p->context,player,&actual,&opt) ||
       !opt || !actual.verified || actual.slot>=RP_MAX ||
       actual.slot==session->local.slot || !actual.generation ||
       actual.epoch!=session->engine.fresh_epoch ||
       !net->peers[actual.slot].registered ||
       !net->binding_valid[actual.slot] ||
       !same(actual,net->peers[actual.slot].peer) ||
       !same(actual,net->binding[actual.slot].wire) ||
       net->binding[actual.slot].player!=player ||
       player>UINTPTR_MAX-33u ||
       !p->read(p->context,player+33u,&engine_slot,sizeof engine_slot) ||
       engine_slot!=actual.slot ||
       !rp_roster_matches(&net->roster,actual.epoch,actual.slot,player,
                          net->binding[actual.slot].local_generation) ||
       !rp_peer_id_v13(p->read,p->context,player,
                       session->engine.gamer_info_getter,&peer_id) ||
       peer_id!=net->binding[actual.slot].peer_id) goto out;
    /* Strict RPE3 validation (magic/version, slot, epoch, generation,
       sender role, payload shape) occurs in rp_r12_enqueue_authenticated.
       Do not rewrite the sender field as the legacy Decide adapter did. */
    /* Re-audit immediately before queue insertion. All calls require a
       serialized script/game thread, but a lifecycle or peer transition can
       still invalidate data between engine reads. */
    if(!rp_r12_audit_engine(net)) {
        rp_r15_stop(r->runtime);goto out;
    }
    if(!rp_r12_enqueue_authenticated(net,actual,wire))goto out;
    ok=true;
out:
    if(ok)++r->transport_accepted;
    else ++r->transport_rejected;
    r->in_observer=false;
    return ok;
}
