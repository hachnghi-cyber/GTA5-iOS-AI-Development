#include "rp_engine.h"
#include <string.h>
static uint32_t get32(const uint8_t *p) {
    return (uint32_t)p[0] | (uint32_t)p[1]<<8 | (uint32_t)p[2]<<16 | (uint32_t)p[3]<<24;
}
static uint64_t get64(const uint8_t *p) { return get32(p) | (uint64_t)get32(p+4)<<32; }
static void put32(uint8_t *p, uint32_t v) { for(unsigned i=0;i<4;++i)p[i]=(uint8_t)(v>>(8*i)); }
static bool shape(rp_engine_kind kind, const uint8_t *b, size_t n) {
    if (!b) return false;
    if (kind==RP_ENGINE_REQUEST) { rp_request r; return rp_decode(b,n,&r); }
    if (kind==RP_ENGINE_ACK) return n==RP_ACK_WIRE && !memcmp(b,"RA13",4) && b[4]==2;
    return kind==RP_ENGINE_SNAPSHOT && n==RP_WIRE && !memcmp(b,"RS13",4) && b[4]==2;
}
bool rp_engine_pack(uint8_t sender, rp_engine_kind kind, const uint8_t *b,
                    size_t n, uint8_t out[RP_ENGINE_BYTES]) {
    if (!out || sender>=RP_MAX || !shape(kind,b,n)) return false;
    memset(out,0,RP_ENGINE_BYTES);
    memcpy(out,"RPE3",4); put32(out+8,sender); put32(out+12,3);
    put32(out+16,(uint32_t)n); put32(out+20,(uint32_t)kind);
    memcpy(out+32,b,n); return true;
}
bool rp_engine_unpack(const uint8_t *b, size_t n, rp_engine_peer peer,
                      rp_engine_kind *kind, rp_inbound *out) {
    if (!b || !kind || !out || !peer.verified || peer.slot>=RP_MAX ||
        !peer.generation || !peer.epoch || n!=RP_ENGINE_BYTES || memcmp(b,"RPE3",4) ||
        get32(b+4) || get32(b+8)!=peer.slot || get32(b+12)!=3 || get64(b+24)) return false;
    uint32_t length=get32(b+16), k=get32(b+20);
    if (k<RP_ENGINE_REQUEST || k>RP_ENGINE_SNAPSHOT || length>RP_ACK_WIRE ||
        !shape((rp_engine_kind)k,b+32,length)) return false;
    for(size_t i=32+length;i<RP_ENGINE_BYTES;++i) if(b[i])return false;
    if(k==RP_ENGINE_REQUEST) {
        rp_request r; if(!rp_decode(b+32,length,&r))return false;
        if(r.actor!=peer.slot || r.actor_generation!=peer.generation || r.epoch!=peer.epoch)return false;
    } else {
        /* ACK embeds its request at byte 8; request epoch is at byte 8. */
        size_t epoch_offset=k==RP_ENGINE_ACK?16:8;
        if(get64(b+32+epoch_offset)!=peer.epoch)return false;
    }
    memset(out,0,sizeof *out);out->peer=peer.slot;out->generation=peer.generation;
    out->length=length;memcpy(out->bytes,b+32,length);*kind=(rp_engine_kind)k;return true;
}
