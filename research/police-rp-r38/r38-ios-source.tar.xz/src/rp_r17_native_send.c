#include "rp_r17_native_send.h"
#include <string.h>

void rp_r17_native_init(rp_r17_native_sender *s,rp_r17_job_send_native native,
                        rp_r17_host_guard v,rp_r17_host_guard thread,void *ctx) {
    if(!s)return;
    memset(s,0,sizeof *s);
    s->native=native;s->verified_v133=v;
    s->on_game_thread=thread;s->context=ctx;
}
bool rp_r17_native_emit(void *opaque,const uint8_t message[RP_R17_JOB_BYTES],
                        uint32_t kind,uint32_t mask) {
    rp_r17_native_sender *s=(rp_r17_native_sender *)opaque;
    if(!s)return false;
    if(!s->native || !s->verified_v133 || !s->on_game_thread ||
       !message || s->in_native || kind!=RP_R17_CUSTOM_KIND || !mask ||
       !s->verified_v133(s->context) || !s->on_game_thread(s->context)) {
        ++s->denied;return false;
    }
    uint8_t wire[RP_ENGINE_BYTES];
    if(!rp_r17_unpack_job(message,RP_R17_JOB_BYTES,wire,NULL)) {
        ++s->denied;return false;
    }
    memset(wire,0,sizeof wire);
    s->in_native=true;
    uint8_t copy[RP_R17_JOB_BYTES];
    memcpy(copy,message,sizeof copy);
    s->native(copy,kind,mask);
    memset(copy,0,sizeof copy);
    s->in_native=false;
    ++s->calls;
    return true;
}
