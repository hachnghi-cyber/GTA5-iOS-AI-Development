#include "rp_owned_backing_r27.h"
bool rp_r27_attach_owned_reader(rp_r26_clone *c, rp_r27_copy_backing r) {
    if(!c || c->busy || !c->copy_header || !c->token || !c->native ||
       !c->bound || !r || c->owned_backing)return false;
    c->owned_backing=r;
    return true;
}
bool rp_r27_make_owned_provider(rp_r26_clone *c,
                                rp_r24_private_isolation isolation,
                                rp_r24_provider *out) {
    if(!c || !c->owned_backing || c->busy)return false;
    return rp_r26_make_provider(c,isolation,out);
}
