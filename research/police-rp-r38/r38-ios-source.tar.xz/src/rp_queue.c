#include "rp_queue.h"
#include <string.h>
void rp_queue_init(rp_queue *q) {
    atomic_init(&q->head, 0);
    atomic_init(&q->tail, 0);
}
bool rp_queue_push(rp_queue *q, uint8_t peer, uint32_t gen,
                   const uint8_t *b, size_t n) {
    if (!q || !b || peer >= RP_MAX || !gen || (n != RP_WIRE && n != RP_ACK_WIRE))
        return false;
    unsigned head = atomic_load_explicit(&q->head, memory_order_relaxed);
    unsigned next = (head + 1) % (RP_QUEUE_CAPACITY + 1);
    if (next == atomic_load_explicit(&q->tail, memory_order_acquire)) return false;
    rp_inbound *p = &q->items[head];
    p->peer = peer;
    p->generation = gen;
    p->length = n;
    memcpy(p->bytes, b, n);
    atomic_store_explicit(&q->head, next, memory_order_release);
    return true;
}
bool rp_queue_pop(rp_queue *q, rp_inbound *out) {
    if (!q || !out) return false;
    unsigned tail = atomic_load_explicit(&q->tail, memory_order_relaxed);
    if (tail == atomic_load_explicit(&q->head, memory_order_acquire)) return false;
    const rp_inbound *p = &q->items[tail];
    /* Do not copy uninitialized padding or unused payload bytes. */
    memset(out, 0, sizeof *out);
    out->peer = p->peer;
    out->generation = p->generation;
    out->length = p->length;
    memcpy(out->bytes, p->bytes, p->length);
    atomic_store_explicit(&q->tail, (tail + 1) % (RP_QUEUE_CAPACITY + 1), memory_order_release);
    return true;
}
