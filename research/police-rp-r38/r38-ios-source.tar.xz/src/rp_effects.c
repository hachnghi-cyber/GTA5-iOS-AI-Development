#include "rp_effects.h"
bool rp_effects_frame(rp_effects*e,rp_client*c,const rp_effect_api*a,uint64_t now,bool session,bool thread){
 if(!e||!c||!a||!a->apply_local||!a->clear_local||!thread)return false;
 rp_client_tick(c,now);
 if(!session||!c->valid){
  if(e->active)a->clear_local(a->context);
  e->active=false;return false;
 }
 if(c->state==RP_FREE&&!c->surrender){if(e->active)a->clear_local(a->context);e->active=false;return true;}
 /* Set active first: even a partly-failed native operation gets cleaned up. */
 e->active=true;
 if(!a->apply_local(a->context,(rp_state)c->state,c->owner,c->surrender)){
  a->clear_local(a->context);e->active=false;return false;
 }
 return true;
}
