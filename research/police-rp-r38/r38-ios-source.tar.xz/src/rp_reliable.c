#include "rp_reliable.h"
#include <string.h>
#include <limits.h>
static uint64_t add_ms(uint64_t a, uint64_t b) {
    return UINT64_MAX - a < b ? UINT64_MAX : a + b;
}
static void make_ack(const uint8_t request[RP_WIRE], rp_result result,
                     uint8_t ack[RP_ACK_WIRE]) {
    memset(ack, 0, RP_ACK_WIRE);
    memcpy(ack, "RA13", 4);
    ack[4] = 2;
    ack[5] = (uint8_t)result;
    memcpy(ack + 8, request, RP_WIRE);
}
void rp_service_init(rp_service *s, uint64_t epoch) {
    memset(s, 0, sizeof *s);
    rp_host_init(&s->host, epoch);
}
bool rp_service_receive(rp_service *s, uint8_t peer, uint32_t generation,
                        const uint8_t *wire, size_t length,
                        uint8_t ack[RP_ACK_WIRE]) {
    rp_request r;
    if (!s || !ack || !rp_decode(wire, length, &r) || peer >= RP_MAX ||
        !generation || peer != r.actor || generation != r.actor_generation ||
        !r.seq || !s->host.epoch || r.epoch != s->host.epoch) return false;
    const rp_player *actor = &s->host.p[peer];
    if (!actor->joined || !actor->consent || actor->generation != generation)
        return false;
    /* Cache entries contain the whole request, including epoch and generations.
     * Old peer incarnations cannot claim another incarnation's result. */
    for (unsigned i = 0; i < RP_ACK_CACHE; ++i) {
        const rp_cached_reply *entry = &s->cache[peer][i];
        if (!entry->valid) continue;
        rp_request old;
        if (!rp_decode(entry->request, RP_WIRE, &old)) continue;
        if (old.epoch == r.epoch && old.actor_generation == generation &&
            old.seq == r.seq) {
            if (memcmp(entry->request, wire, RP_WIRE)) {
                make_ack(wire, RP_BAD_WIRE, ack);
            } else {
                make_ack(wire, entry->result, ack);
            }
            return true;
        }
    }
    /* Identity failures must also consume a valid actor's sequence, otherwise
     * a delayed rejected request could become valid after a target joins. */
    if (r.seq <= actor->seq) {
        make_ack(wire, RP_REPLAY, ack);
        return true;
    }
    rp_result result = rp_handle(&s->host, peer, wire, length);
    if (s->host.p[peer].seq < r.seq) s->host.p[peer].seq = r.seq;
    rp_cached_reply *entry = &s->cache[peer][s->next[peer]];
    entry->valid = true;
    entry->result = result;
    memcpy(entry->request, wire, RP_WIRE);
    s->next[peer] = (s->next[peer] + 1) % RP_ACK_CACHE;
    make_ack(wire, result, ack);
    return true;
}
void rp_sender_init(rp_sender *c, uint64_t epoch, uint8_t slot, uint32_t gen) {
    memset(c, 0, sizeof *c);
    c->epoch = epoch;
    c->slot = slot;
    c->generation = gen;
    c->next_seq = 1;
}
bool rp_sender_submit(rp_sender *c, rp_action action, uint8_t target,
                      uint32_t target_gen, uint32_t arg, uint64_t now) {
    if (!c || action < RP_SURRENDER || action > RP_REVIVE ||
        c->status == RP_TX_PENDING || !c->epoch || !c->generation ||
        !target_gen || !c->next_seq || now < c->last_poll_ms ||
        now > UINT64_MAX - RP_REQUEST_TIMEOUT_MS) return false;
    rp_request r = {(uint8_t)action, c->slot, target, c->generation, target_gen,
                    c->next_seq, arg, c->epoch};
    if (!rp_encode(&r, c->request)) return false;
    c->next_seq = c->next_seq == UINT32_MAX ? 0 : c->next_seq + 1;
    c->status = RP_TX_PENDING;
    c->attempts = 0;
    c->result = RP_OK; /* Meaningful only after RP_TX_DONE. */
    c->started_ms = c->last_poll_ms = c->next_send_ms = now;
    return true;
}
bool rp_sender_poll(rp_sender *c, uint64_t now, uint8_t request[RP_WIRE]) {
    if (!c || !request || c->status != RP_TX_PENDING || now < c->last_poll_ms)
        return false;
    c->last_poll_ms = now;
    if (now - c->started_ms >= RP_REQUEST_TIMEOUT_MS) {
        c->status = RP_TX_TIMEOUT;
        return false;
    }
    if (now < c->next_send_ms || c->attempts >= RP_RETRY_COUNT) return false;
    memcpy(request, c->request, RP_WIRE);
    ++c->attempts;
    c->next_send_ms = add_ms(now, RP_RETRY_MS);
    return true;
}
bool rp_sender_ack(rp_sender *c, bool host, const uint8_t *b, size_t n,
                   uint64_t now) {
    if (!c || !host || !b || c->status != RP_TX_PENDING ||
        now < c->last_poll_ms || n != RP_ACK_WIRE || memcmp(b, "RA13", 4) ||
        b[4] != 2 || b[5] > RP_RATE || b[6] || b[7] ||
        memcmp(b + 8, c->request, RP_WIRE)) return false;
    for (size_t i = 48; i < RP_ACK_WIRE; ++i) if (b[i]) return false;
    c->last_poll_ms = now;
    if (now - c->started_ms >= RP_REQUEST_TIMEOUT_MS) {
        c->status = RP_TX_TIMEOUT;
        return false;
    }
    c->result = (rp_result)b[5];
    c->status = RP_TX_DONE;
    return true;
}
