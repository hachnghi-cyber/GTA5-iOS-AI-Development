#include "rp_native.h"
#include <mach/mach.h>
#include <mach/mach_vm.h>
#include <mach-o/dyld.h>
#include <mach-o/loader.h>
#include <string.h>
static bool read_self(uintptr_t a, void *out, size_t n) {
    mach_vm_size_t got=0;
    return mach_vm_read_overwrite(mach_task_self(),a,n,(mach_vm_address_t)(uintptr_t)out,&got)==KERN_SUCCESS && got==n;
}
bool rp_native_bind_v133(rp_native *out) {
    /* Static symbol-name and 16-byte gates only; integration owns thread and lifetime checks. */
    if(!out)return false;
    memset(out,0,sizeof *out);
    const unsigned char uuid[16]={0xeb,0x12,0x2c,0x35,0x96,0xf4,0x30,0x7f,0x91,0xc3,0xa2,0x25,0x5d,0xd9,0xc6,0x85};
    intptr_t slide=0;bool found=false;
    for(uint32_t i=0;i<_dyld_image_count();++i) {
        const struct mach_header *base=_dyld_get_image_header(i);
        if(!base || base->magic!=MH_MAGIC_64 || base->filetype!=MH_EXECUTE)continue;
        const struct mach_header_64 *h=(const struct mach_header_64 *)base;
        const unsigned char *p=(const unsigned char *)(h+1),*end=p+h->sizeofcmds;
        for(uint32_t j=0;j<h->ncmds;++j) {
            if((size_t)(end-p)<sizeof(struct load_command))return false;
            const struct load_command *c=(const struct load_command *)p;
            if(c->cmdsize<sizeof *c || c->cmdsize>(size_t)(end-p))return false;
            if(c->cmd==LC_UUID && c->cmdsize>=sizeof(struct uuid_command) && !memcmp(((const struct uuid_command *)c)->uuid,uuid,16))found=true;
            p+=c->cmdsize;
        }
        if(!found)return false;
        slide=_dyld_get_image_vmaddr_slide(i);break;
    }
    if(!found)return false;
    rp_native_api api={0};
    {
        const unsigned char expected[16]={0xfd,0x7b,0xbf,0xa9,0xfd,0x03,0x00,0x91,0x00,0x4e,0x00,0xd0,0x00,0xa0,0x35,0x91};unsigned char actual[16];
        uintptr_t address=(uintptr_t)(slide+INT64_C(0x101faa42c));
        if(!read_self(address,actual,sizeof actual) || memcmp(actual,expected,sizeof actual))return false;
        _Static_assert(sizeof(api.script_handler)==sizeof address,"function pointer ABI");
        memcpy(&api.script_handler,&address,sizeof address);
    }
    {
        const unsigned char expected[16]={0x28,0xf8,0x00,0x90,0x08,0x41,0x36,0x91,0x08,0x01,0x40,0xf9,0x00,0x05,0x40,0xf9};unsigned char actual[16];
        uintptr_t address=(uintptr_t)(slide+INT64_C(0x100d66024));
        if(!read_self(address,actual,sizeof actual) || memcmp(actual,expected,sizeof actual))return false;
        _Static_assert(sizeof(api.player_ped)==sizeof address,"function pointer ABI");
        memcpy(&api.player_ped,&address,sizeof address);
    }
    {
        const unsigned char expected[16]={0x1f,0x04,0x00,0x31,0xe0,0x03,0x00,0x54,0xff,0xc3,0x00,0xd1,0xf4,0x4f,0x01,0xa9};unsigned char actual[16];
        uintptr_t address=(uintptr_t)(slide+INT64_C(0x100c3c428));
        if(!read_self(address,actual,sizeof actual) || memcmp(actual,expected,sizeof actual))return false;
        _Static_assert(sizeof(api.entity_exists)==sizeof address,"function pointer ABI");
        memcpy(&api.entity_exists,&address,sizeof address);
    }
    {
        const unsigned char expected[16]={0xff,0xc3,0x00,0xd1,0xf4,0x4f,0x01,0xa9,0xfd,0x7b,0x02,0xa9,0xfd,0x83,0x00,0x91};unsigned char actual[16];
        uintptr_t address=(uintptr_t)(slide+INT64_C(0x100d2b478));
        if(!read_self(address,actual,sizeof actual) || memcmp(actual,expected,sizeof actual))return false;
        _Static_assert(sizeof(api.handcuffs)==sizeof address,"function pointer ABI");
        memcpy(&api.handcuffs,&address,sizeof address);
    }
    {
        const unsigned char expected[16]={0x3f,0xa8,0x05,0x71,0x88,0x07,0x00,0x54,0xff,0x03,0x01,0xd1,0xf6,0x57,0x01,0xa9};unsigned char actual[16];
        uintptr_t address=(uintptr_t)(slide+INT64_C(0x100d1ebb8));
        if(!read_self(address,actual,sizeof actual) || memcmp(actual,expected,sizeof actual))return false;
        _Static_assert(sizeof(api.disable_control)==sizeof address,"function pointer ABI");
        memcpy(&api.disable_control,&address,sizeof address);
    }
    {
        const unsigned char expected[16]={0xff,0x03,0x02,0xd1,0xe9,0x23,0x03,0x6d,0xf8,0x5f,0x04,0xa9,0xf6,0x57,0x05,0xa9};unsigned char actual[16];
        uintptr_t address=(uintptr_t)(slide+INT64_C(0x100daaf28));
        if(!read_self(address,actual,sizeof actual) || memcmp(actual,expected,sizeof actual))return false;
        _Static_assert(sizeof(api.follow)==sizeof address,"function pointer ABI");
        memcpy(&api.follow,&address,sizeof address);
    }
    {
        const unsigned char expected[16]={0x26,0x00,0x80,0x52,0x36,0xff,0xff,0x17,0x06,0x00,0x80,0x52,0x34,0xff,0xff,0x17};unsigned char actual[16];
        uintptr_t address=(uintptr_t)(slide+INT64_C(0x100c46b08));
        if(!read_self(address,actual,sizeof actual) || memcmp(actual,expected,sizeof actual))return false;
        _Static_assert(sizeof(api.coords)==sizeof address,"function pointer ABI");
        memcpy(&api.coords,&address,sizeof address);
    }
    {
        const unsigned char expected[16]={0xfa,0x67,0xbb,0xa9,0xf8,0x5f,0x01,0xa9,0xf6,0x57,0x02,0xa9,0xf4,0x4f,0x03,0xa9};unsigned char actual[16];
        uintptr_t address=(uintptr_t)(slide+INT64_C(0x100d7db10));
        if(!read_self(address,actual,sizeof actual) || memcmp(actual,expected,sizeof actual))return false;
        _Static_assert(sizeof(api.trigger_event)==sizeof address,"function pointer ABI");
        memcpy(&api.trigger_event,&address,sizeof address);
    }
    out->api=api;out->bound=true;return true;
}
