#!/bin/sh
# R35: build an iPhoneOS ARM64 dylib; install NOTHING until same-call sender
# proof, independent private pre-sequence skip and transport framing are real.
set -eu
cd "$(dirname "$0")/.."
python3 tools/preflight_r35_ios.py
python3 tools/r35_symbol_closure.py --out build/r35-symbol-closure.json
make check-r35 CC=clang
make sanitize-r35 CC=clang
if ! command -v xcrun >/dev/null 2>&1; then
    echo 'ERROR: macOS + Xcode iPhoneOS SDK required. No IPA created.' >&2
    exit 1
fi
sdk="$(xcrun --sdk iphoneos --show-sdk-path)"
mkdir -p build/ios-r35
objects=''
for source in src/*.c ios/native_v133.c ios/r18_bootstrap.c \
              ios/r25_bind_v133.c ios/r26_snapshot_v133.c \
              ios/r27_backing_v133.c ios/r27_bootstrap.c; do
    stem="$(basename "$source" .c)"
    xcrun --sdk iphoneos clang -arch arm64 -isysroot "$sdk" \
        -miphoneos-version-min=16.3 -std=c11 -O2 -Wall -Wextra -Werror \
        -fvisibility=hidden -fstack-protector-strong -Iinclude \
        -c "$source" -o "build/ios-r35/$stem.o"
    objects="$objects build/ios-r35/$stem.o"
done
# shellcheck disable=SC2086
xcrun --sdk iphoneos clang -arch arm64 -isysroot "$sdk" \
    -miphoneos-version-min=16.3 -dynamiclib \
    -Wl,-install_name,@executable_path/Frameworks/libPoliceRP_R35.dylib \
    $objects -o build/ios-r35/libPoliceRP_R35.dylib
xcrun lipo -info build/ios-r35/libPoliceRP_R35.dylib
xcrun otool -l build/ios-r35/libPoliceRP_R35.dylib > build/ios-r35/load_commands.txt
shasum -a 256 build/ios-r35/libPoliceRP_R35.dylib
printf '%s\n' 'Dylib built (not yet injected or authenticated). Gameplay remains disabled.'
