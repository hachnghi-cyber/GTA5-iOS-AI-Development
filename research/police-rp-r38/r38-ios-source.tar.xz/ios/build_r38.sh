#!/bin/sh
# Compile/link real iPhoneOS ARM64 only; never use test headers or Linux mocks.
# Produce NO installable IPA: game hooks and verified sender are not implemented.
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
if ! command -v xcrun >/dev/null 2>&1; then
    echo 'R38 BLOCKED: macOS/Xcode xcrun missing; no iOS dylib created.' >&2
    exit 2
fi
SDK=$(xcrun --sdk iphoneos --show-sdk-path) || { echo 'R38 BLOCKED: iPhoneOS SDK missing.' >&2; exit 2; }
[ -d "$SDK" ] || { echo 'R38 BLOCKED: invalid SDK path.' >&2; exit 2; }
python3 tools/preflight_r35_ios.py
mkdir -p build/ios-r38
TMP=$(mktemp -d "${TMPDIR:-/tmp}/prp-r38.XXXXXXXX")
trap 'rm -rf "$TMP"' EXIT HUP INT TERM
objects=''
count=0
for source in src/*.c ios/native_v133.c ios/r18_bootstrap.c \
    ios/r25_bind_v133.c ios/r26_snapshot_v133.c ios/r27_backing_v133.c \
    ios/r27_bootstrap.c; do
    [ -f "$source" ] || { echo "R38 ERROR: missing source: $source" >&2; exit 1; }
    case "$source" in
        *stub*|*mock*|*/tools/*) echo "R38 ERROR: test source forbidden: $source" >&2; exit 1 ;;
    esac
    count=$((count+1))
    stem=$(basename "$source" .c)
    xcrun --sdk iphoneos clang -arch arm64 -isysroot "$SDK" \
      -miphoneos-version-min=16.3 -std=c11 -O2 -Wall -Wextra -Werror \
      -fvisibility=hidden -fstack-protector-strong -Iinclude \
      -c "$source" -o "$TMP/$stem.o"
    objects="$objects $TMP/$stem.o"
done
[ "$count" -eq 34 ] || { echo "R38 ERROR: expected 34 source files, got $count" >&2; exit 1; }
# shellcheck disable=SC2086
xcrun --sdk iphoneos clang -arch arm64 -isysroot "$SDK" \
  -miphoneos-version-min=16.3 -dynamiclib \
  -Wl,-install_name,@executable_path/Frameworks/libPoliceRP_R38.dylib \
  $objects -o "$TMP/libPoliceRP_R38.dylib"
python3 tools/verify_r38_macho.py "$TMP/libPoliceRP_R38.dylib" --json "$TMP/R38-macho-report.json"
xcrun --sdk iphoneos lipo -info "$TMP/libPoliceRP_R38.dylib"
xcrun --sdk iphoneos nm -gU "$TMP/libPoliceRP_R38.dylib" > "$TMP/R38-exports.txt"
xcrun --sdk iphoneos otool -l "$TMP/libPoliceRP_R38.dylib" > "$TMP/R38-load-commands.txt"
# Publish only after successful link + structural validation, never leave stale success.
mv "$TMP/libPoliceRP_R38.dylib" build/ios-r38/libPoliceRP_R38.dylib
mv "$TMP/R38-macho-report.json" build/ios-r38/R38-macho-report.json
mv "$TMP/R38-exports.txt" build/ios-r38/R38-exports.txt
mv "$TMP/R38-load-commands.txt" build/ios-r38/R38-load-commands.txt
echo 'R38: genuine iPhoneOS dylib linked and statically verified. No hooks installed; game RP remains disabled.'
