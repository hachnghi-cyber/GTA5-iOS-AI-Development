/* R27 — source-level adapter preparation only.
 * This MUST be called from a verified iOS game-thread callback owner which
 * supplies the SAME-DELIVERY token, proper lifetime and a pinned build gate.
 * It resolves the exact v13.3 PeekBytes function and installs the bounded
 * *owned* backing-store reader. It does NOT install any RAGE hook, prove the
 * network sender, authorize RP gameplay, or send a network packet.
 */
#include "rp_owned_backing_r27.h"

__attribute__((visibility("default"))) bool prp_r27_prepare_native_decoder(rp_r26_clone *clone,
                                     rp_r26_delivery_token token,
                                     rp_r25_binding_gate pinned,
                                     void *context) {
    rp_r25_native_peek native=NULL;
    if(!clone || !token || !pinned || !pinned(context) ||
       !rp_r25_resolve_v133_peek(&native) || !native)return false;
    if(!rp_r26_clone_init(clone,rp_r26_ios_copy_header,token,native,
                          pinned,context))return false;
    return rp_r27_attach_owned_reader(clone,rp_r27_ios_copy_backing);
}
