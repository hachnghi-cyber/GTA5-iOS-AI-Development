/* R18 iPhoneOS bootstrap (SOURCE-ONLY). It does NOT install a hook or prove
 * transport provenance. R17 direct ingress/egress are explicitly disabled;
 * only the R18 pre-sequence guard can forward Roleplay traffic. */
#define PRP_R18_GUARD 1
#include "r17_bootstrap.c"
#include "rp_runtime_r18.h"

static rp_runtime_r18 r18_channel;
static bool r18_guarded_provider_send(void *ctx,uint8_t slot,
                                     const uint8_t wire[RP_ENGINE_BYTES]) {
    (void)ctx;
    return rp_r18_send(&r18_channel,slot,wire);
}

/* Must be called by separately VERIFIED game-thread callback owner after
 * prp_r17_open_verified(). The isolation callback must prove that the native
 * receiver will NOT run its vanilla sequence code for kind RP17. No isolation
 * callback => no gameplay or network send. */
EXPORTED bool prp_r18_arm_presequence(rp_r18_check game_thread,
                                     rp_r18_check isolated_dispatch,
                                     rp_r18_epoch read_epoch,void *ctx) {
    if(!verified_v133() || !r17_bound || entered ||
       !runtime.session.armed || runtime.phase!=RP_R15_ACTIVE)return false;
    return rp_r18_bind(&r18_channel,&r17_gate,game_thread,
                       isolated_dispatch,read_epoch,ctx);
}
/* Return 0=pass original, 1=private consumed, 2=private rejected.
 * Only a verified pre-sequence hook may use 1/2 to skip original processing.
 * This function alone DOES NOT modify the game's control flow. */
EXPORTED unsigned prp_r18_presequence_event(const void *attested_cookie,
                                           const uint8_t *job,size_t length) {
    if(!verified_v133() || entered || !r17_bound)
        return (unsigned)rp_r18_early_decision(job,length);
    entered=true;
    const rp_r18_decision d=rp_r18_receive(&r18_channel,attested_cookie,job,length);
    entered=false;
    return (unsigned)d;
}
/* Explicit leave request also disarms the private job channel. */
EXPORTED void prp_r18_disconnect(void) {
    rp_r18_unbind(&r18_channel);
    prp_r16_disconnect();
    r17_bound=false;
}
EXPORTED unsigned prp_r18_is_armed(void) {return (unsigned)r18_channel.armed;}
EXPORTED unsigned prp_r18_received(void) {return r18_channel.handled;}
