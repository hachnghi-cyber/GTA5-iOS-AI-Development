/* iPhoneOS-only passive header reader for the private v13.3 buffer layout.
 * Should be called from verified main-thread RAGE callback. Never attempts
 * to grant permissions, infer a sender or rewrite the game's buffer.
 */
#include "rp_native_clone_r26.h"
#include <mach/mach.h>
#include <mach/mach_vm.h>

bool rp_r26_ios_copy_header(void *context,uintptr_t original,
                             uint8_t out[RP_R26_HEADER_BYTES]) {
    (void)context;
    if(!original || !out || (original&7u))return false;
    mach_vm_size_t copied=0;
    kern_return_t kr=mach_vm_read_overwrite(
        mach_task_self(),(mach_vm_address_t)original,
        (mach_vm_size_t)RP_R26_HEADER_BYTES,
        (mach_vm_address_t)(uintptr_t)out,&copied);
    return kr==KERN_SUCCESS && copied==RP_R26_HEADER_BYTES;
}
