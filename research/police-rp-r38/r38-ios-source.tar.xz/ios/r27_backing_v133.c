/* Read-only snapshot of a bounded backing range. No hooks installed.
 * Caller must run on the confirmed game thread and verify callback ownership.
 * Note: mach_vm_read_overwrite is not an atomic memory snapshot. */
#include "rp_owned_backing_r27.h"
#include <mach/mach.h>
#include <mach/mach_vm.h>
bool rp_r27_ios_copy_backing(void *context, uintptr_t source,
                             uint8_t *out, size_t length) {
    (void)context;
    if(!source || !out || !length || length>RP_R17_JOB_BYTES+1u)return false;
    mach_vm_size_t n=0;
    kern_return_t status=mach_vm_read_overwrite(mach_task_self(),
        (mach_vm_address_t)source,(mach_vm_size_t)length,
        (mach_vm_address_t)(uintptr_t)out,&n);
    return status==KERN_SUCCESS && n==(mach_vm_size_t)length;
}
