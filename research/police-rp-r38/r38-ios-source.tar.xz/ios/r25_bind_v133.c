/* iPhoneOS-only resolver. NOT a hook and NOT a verified transport callback.
 * Requires iPhoneOS SDK to compile/link. This function does not call PeekBytes.
 */
#include "rp_native_peek_r25.h"
#include <mach/mach.h>
#include <mach/mach_vm.h>
#include <mach-o/dyld.h>
#include <mach-o/loader.h>
#include <stdint.h>
#include <string.h>

static bool self_read(uintptr_t address,void *out,size_t n) {
    mach_vm_size_t got=0;
    return mach_vm_read_overwrite(mach_task_self(),(mach_vm_address_t)address,
            (mach_vm_size_t)n,(mach_vm_address_t)(uintptr_t)out,&got)==
            KERN_SUCCESS && got==(mach_vm_size_t)n;
}
/* Prototype with the C++ "this" pointer passed as the first C argument.
 * ABI was inferred from v13.3 instructions and is NOT device-verified.
 */
bool rp_r25_resolve_v133_peek(rp_r25_native_peek *out) {
    if(!out)return false;
    *out=NULL;
    static const uint8_t uuid[16]={0xeb,0x12,0x2c,0x35,0x96,0xf4,0x30,0x7f,
                                    0x91,0xc3,0xa2,0x25,0x5d,0xd9,0xc6,0x85};
    static const uint8_t prologue[16]={0x42,0x70,0x1d,0x53,0x69,0x00,0x02,0x0b,
                                       0x0a,0x70,0x40,0x39,0x5f,0x01,0x00,0x72};
    static const uint8_t restore[16]={0x13,0x10,0x00,0xb9,0x14,0x18,0x00,0xb9,
                                      0xfd,0x7b,0x42,0xa9,0xf4,0x4f,0x41,0xa9};
    for(uint32_t i=0;i<_dyld_image_count();++i) {
        const struct mach_header *mh=_dyld_get_image_header(i);
        if(!mh || mh->magic!=MH_MAGIC_64 || mh->filetype!=MH_EXECUTE)continue;
        const struct mach_header_64 *h=(const struct mach_header_64 *)mh;
        if(h->sizeofcmds>UINT32_C(1)<<20 || h->ncmds>4096)return false;
        const uint8_t *p=(const uint8_t *)(h+1);
        size_t remain=h->sizeofcmds;
        bool matches=false;
        for(uint32_t j=0;j<h->ncmds;++j){
            if(remain<sizeof(struct load_command))return false;
            struct load_command lc;
            memcpy(&lc,p,sizeof lc);
            if(lc.cmdsize<sizeof lc || lc.cmdsize>remain)return false;
            if(lc.cmd==LC_UUID && lc.cmdsize>=sizeof(struct uuid_command)){
                struct uuid_command u;memcpy(&u,p,sizeof u);
                matches=!memcmp(u.uuid,uuid,sizeof uuid);
            }
            p+=lc.cmdsize;remain-=lc.cmdsize;
        }
        if(!matches)return false;
        intptr_t slide=_dyld_get_image_vmaddr_slide(i);
        uintptr_t at=(uintptr_t)(slide+INT64_C(0x10000DA74));
        uint8_t actual[16];
        if(!self_read(at,actual,sizeof actual) ||
           memcmp(actual,prologue,sizeof actual))return false;
        /* Restore of two 32-bit cursor fields at +0xB0 in PeekBytes. */
        if(!self_read(at+0xB0,actual,sizeof actual) ||
           memcmp(actual,restore,sizeof actual))return false;
        _Static_assert(sizeof(*out)==sizeof(at),"ARM64 function pointer size");
        memcpy(out,&at,sizeof at);
        return true;
    }
    return false;
}
