#ifndef RP_INGRESS_R23_H
#define RP_INGRESS_R23_H

#include "rp_provenance_r20.h"

/* R23: source-only ABI for a TRUE SAME-CALL network receive boundary.
 * Binary evidence at 0x10200C950: netGameEvent vtable+0x60 receives
 * (event, datBitBuffer*, 0, netPlayer_A*, netPlayer_B*).
 * No executable hook, decoder or authenticated sender provider is installed.
 * NetPlayer_A MUST NOT be called an authenticated sender solely because
 * HandleEvent supplied it. The independent verify() callback is mandatory.
 */
typedef struct {
    uintptr_t native_event;       /* netGameEvent* from HandleEvent x1 */
    uintptr_t bit_buffer;         /* datBitBuffer* from HandleEvent x2 */
    uintptr_t candidate_a;        /* netPlayer* from HandleEvent x3 */
    uintptr_t candidate_b;        /* netPlayer* from HandleEvent x4 */
} rp_r23_native_call;

typedef bool (*rp_r23_thread_check)(void *);
typedef uint64_t (*rp_r23_epoch_read)(void *);
/* Read event type from the native event object (not from job payload). */
typedef bool (*rp_r23_read_event_type)(void *, uintptr_t event, uint32_t *kind);
/* Must establish same-delivery provenance from RAGE receive metadata. Must
 * return monotonic delivery_id independently of user-controlled MPJ2 seq.
 * Return false if no credible native sender/delivery identity is available. */
typedef bool (*rp_r23_verify_native)(void *, const rp_r23_native_call *,
                                    uint64_t epoch, uint8_t *verified_slot,
                                    uint64_t *delivery_id);
typedef bool (*rp_r23_deliver)(void *, uintptr_t verified_player,
                                const uint8_t wire[RP_ENGINE_BYTES]);

typedef struct {
    rp_r23_thread_check on_game_thread;
    rp_r23_epoch_read read_epoch;
    rp_r23_read_event_type read_event_type;
    rp_r23_verify_native verify_native;
    rp_r23_deliver deliver;
    void *context;
} rp_r23_provider;

typedef struct {
    rp_r20_boundary boundary;
    rp_r23_provider provider;
    /* R34: immutable function/context policy during one in-flight receipt.
     * Any swap (even to a more permissive verifier/deliverer) must fail. */
    rp_r23_provider scoped_policy;
    rp_r20_witness scoped;
    uint8_t scoped_slot;
    uint64_t revision;
    uint64_t scoped_revision;
    uint32_t attempts, accepted, rejected, pass_original, revoked;
    bool armed, busy, scoped_valid;
} rp_r23_ingress;

void rp_r23_init(rp_r23_ingress *);
bool rp_r23_arm(rp_r23_ingress *, const rp_r23_provider *);
void rp_r23_stop(rp_r23_ingress *);
/* The caller supplies MPJ2 BYTES decoded within this SAME native dispatch;
 * passing data later from MacportJobsUpdate() violates this contract.
 * No vanilla event is ever consumed unless an independently validated
 * pre-sequence skip hook obeys the PRIVATE_* decision. */
rp_r20_result rp_r23_receive_same_call(rp_r23_ingress *,
    const rp_r23_native_call *, const uint8_t *decoded_mpj2, size_t length);
#endif
