#ifndef RP_RUNTIME_R14_H
#define RP_RUNTIME_R14_H
#include "rp_runtime_r13.h"
#include "rp_native.h"

/* R14 binds a host-authenticated local RP snapshot to LOCAL-PED-ONLY effects.
 * The embedder MUST provide proven real game/script thread, local ped, owner
 * ped, and jail coordinates. It must NOT use packet sender hints or remote
 * CPed handles as the local ped. Nothing here auto-installs an engine hook. */
typedef bool (*rp_r14_native_frame_fn)(void *ctx, uint8_t local_slot,
     uint8_t escort_owner_slot, rp_state state, rp_native_frame *out);
typedef struct {
    rp_r14_native_frame_fn frame;
    void *context;
} rp_r14_provider;
typedef struct {
    rp_native native;
    rp_r14_provider provider;
    uint64_t epoch;
    uint8_t local_slot;
    uint32_t generation;
    unsigned applied, cleared, rejected;
    bool initialized, effects_owned, pending_clear;
} rp_runtime_r14;

/* The rp_runtime_r14 instance MUST be zero-initialized on first use.
 * Reattachment refuses any pending native cleanup.
 * Separate from R13 session bootstrap. Caller must already have a verified,
 * live R13 session and validated RAGE native-function table. */
bool rp_r14_attach(rp_runtime_r14 *, const rp_runtime_r13 *,
                    const rp_native *, const rp_r14_provider *);
/* Calls R13 frame once then reconciles local-only native effects. Host ACK
 * alone NEVER enables effects; requires a nonexpired host snapshot. */
bool rp_r14_frame(rp_runtime_r14 *, rp_runtime_r13 *, uint64_t now_ms);
/* Revokes permission immediately, but cleanup must be retried on an attested
 * game thread. Call rp_r14_cleanup even after rp_r13_stop. */
void rp_r14_revoke(rp_runtime_r14 *);
bool rp_r14_cleanup(rp_runtime_r14 *, uint64_t now_ms);
#endif
