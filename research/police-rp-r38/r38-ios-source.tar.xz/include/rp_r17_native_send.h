#ifndef RP_R17_NATIVE_SEND_H
#define RP_R17_NATIVE_SEND_H
#include "rp_runtime_r17.h"

/* Disassembly-confirmed v13.3 function interface:
   static void MacportJobSend(MacportJobMsg&, unsigned job_kind, unsigned mask)
   RVA 0xF7D30 in the ORIGINAL GTA5 image; ASLR must be applied by loader.
   This module neither resolves that address nor installs a hook.
   Binding must require the game's expected UUID, expected instruction bytes,
   serialized game-thread context and native function ABI review. */
typedef void (*rp_r17_job_send_native)(uint8_t *job_message,
                                     unsigned job_kind, unsigned target_mask);
typedef bool (*rp_r17_host_guard)(void *ctx);

typedef struct {
    rp_r17_job_send_native native;
    rp_r17_host_guard verified_v133;
    rp_r17_host_guard on_game_thread;
    void *context;
    unsigned calls, denied;
    bool in_native;
} rp_r17_native_sender;

void rp_r17_native_init(rp_r17_native_sender *,rp_r17_job_send_native,
                        rp_r17_host_guard verified_v133,
                        rp_r17_host_guard on_game_thread,void *context);
/* rp_r17_emit_job callback. A native void return does not prove that the event
   was queued/sent, so the true return means only 'native function invoked'. */
bool rp_r17_native_emit(void *,const uint8_t job[RP_R17_JOB_BYTES],
                        uint32_t private_kind,uint32_t recipient_mask);
#endif
