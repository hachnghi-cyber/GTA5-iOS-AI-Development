#ifndef RP_CAPTURE_H
#define RP_CAPTURE_H
#include "rp_engine.h"
typedef bool (*rp_read_memory)(void *,uintptr_t,void *,size_t);
/* LEGACY SYNTHETIC parser only. NOT to be wired to vanilla Decide on v13.3.
 * Integration retains original engine dispatch and provides trusted peer epoch
 * and generation. This function neither installs a hook nor invents identity. */
bool rp_capture_v13(rp_read_memory, void *context, uintptr_t event,
                     uintptr_t net_player, rp_engine_peer,
                     rp_engine_kind *, rp_inbound *);
#endif
