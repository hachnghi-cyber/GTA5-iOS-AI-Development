#ifndef RP_H
#define RP_H
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#define RP_MAX 32
#define RP_WIRE 40
#define RP_NONE 255
#define RP_LEASE_MS 5000
/* All calls on one owner/game thread. Transport supplies authenticated identity.
   No direct game pointers, native calls, sockets or allocation in the core. */
typedef enum { RP_CIV, RP_POLICE, RP_EMS } rp_role;
typedef enum { RP_FREE, RP_CUFFED, RP_ESCORTED, RP_JAILED } rp_state;
typedef enum { RP_SURRENDER=1, RP_CUFF, RP_UNCUFF, RP_ESCORT, RP_STOP_ESCORT, RP_JAIL, RP_REVIVE } rp_action;
typedef enum { RP_OK, RP_BAD_WIRE, RP_SESSION, RP_IDENTITY, RP_REPLAY, RP_STALE, RP_PERMISSION, RP_RANGE, RP_TRANSITION, RP_RATE } rp_result;
typedef struct { bool alive, in_vehicle, jail_zone; float x,y,z; } rp_observation;
typedef struct {
 bool joined, consent, surrender, observed; uint8_t role, state, owner;
 uint32_t generation, seq, revision; uint64_t observed_ms, changed_ms, until_ms, next_action_ms;
 rp_observation obs;
} rp_player;
typedef struct { uint64_t epoch, now_ms, snapshot_seq; rp_player p[RP_MAX]; } rp_host;
typedef struct { uint8_t action, actor, target; uint32_t actor_generation,target_generation,seq,arg; uint64_t epoch; } rp_request;
typedef struct { uint64_t epoch, expires_ms, snapshot_seq; uint32_t generation, revision, owner_generation; uint8_t slot,state,owner; bool surrender,valid; } rp_client;
void rp_host_init(rp_host *, uint64_t epoch);
bool rp_join(rp_host *,uint8_t slot,uint32_t generation,bool consent);
void rp_leave(rp_host *,uint8_t slot);
void rp_tick(rp_host *,uint64_t now_ms);
bool rp_observe(rp_host *,uint8_t slot,rp_role,rp_observation);
bool rp_encode(const rp_request *,uint8_t out[RP_WIRE]);
bool rp_decode(const uint8_t *,size_t,rp_request *);
rp_result rp_handle(rp_host *,uint8_t authenticated_peer,const uint8_t *,size_t);
bool rp_snapshot(rp_host *,uint8_t slot,uint8_t out[RP_WIRE]);
void rp_client_init(rp_client *,uint64_t epoch,uint8_t slot,uint32_t generation);
bool rp_client_apply(rp_client *,bool authenticated_host,const uint8_t *,size_t,uint64_t now_ms);
void rp_client_tick(rp_client *,uint64_t now_ms);
#endif
