#ifndef RP_ROSTER_H
#define RP_ROSTER_H
#include "rp_capture.h"
/* Exact v13 layout. Read only on the serialized engine/game thread. */
#define RP_V13_PHYSICAL_TABLE 416u
#define RP_V13_LOCAL_PLAYER 256u
#define RP_V13_PHYSICAL_INDEX 33u
#define RP_V13_INITIALIZED 2296u
#define RP_ROSTER_SLOTS 32u
typedef struct { uintptr_t player[32]; uintptr_t local; } rp_roster_snapshot;
typedef struct {
    rp_roster_snapshot snapshot;
    uint64_t epoch;
    uint32_t generation[32];
    bool usable;
} rp_roster;
/* Checks native reverse slot mapping and two matching reads. This is structural
 * evidence, NOT authentication or proof that the engine was quiescent. */
bool rp_roster_read_v13(rp_read_memory, void *, uintptr_t manager,
                        rp_roster_snapshot *);
/* Epoch must be fresh on every session/hook restart, provided by integration.
 * Generation counters are LOCAL lifetime guards, never wire peer generations. */
bool rp_roster_begin(rp_roster *, uint64_t epoch, const rp_roster_snapshot *);
void rp_roster_invalidate(rp_roster *);
/* Call AFTER original SetPhysicalPlayerIndex returns, for EVERY invocation.
 * touched may have been detached/reassigned using the same pointer. Increment
 * its generations even when the final slot/pointer is unchanged (ABA guard).
 * Also detects eviction/displacement and bumps all affected slots. */
bool rp_roster_after_assignment(rp_roster *, uintptr_t touched,
                                const rp_roster_snapshot *);
/* Frame audit must match the observed state. Unexpected changes quarantine the
 * entire tracker; do not silently heal a missed lifecycle callback. */
bool rp_roster_audit(rp_roster *, const rp_roster_snapshot *);
bool rp_roster_matches(const rp_roster *, uint64_t epoch, uint8_t slot,
                       uintptr_t player, uint32_t local_generation);
#endif
