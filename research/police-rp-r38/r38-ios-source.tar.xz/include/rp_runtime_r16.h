#ifndef RP_RUNTIME_R16_H
#define RP_RUNTIME_R16_H
#include "rp_runtime_r15.h"

/* R16 corrects the v13.3 transport boundary.
 * Disassembly: CScriptedGameEvent::Decide reads [x0+0x224] as a 32-bit EVENT
 * TYPE and supplies x1 (rage::netPlayer*) as the event-constructor's x3.
 * The field is NOT the length of a 96-byte RPE3 packet. Vanilla Decide must
 * never be treated as a validated RPE3 receive callback. */

typedef bool (*rp_r16_original_decide)(void *ctx, uintptr_t event,
                                       uintptr_t player_a, uintptr_t player_b);
typedef struct {
    rp_runtime_r15 *runtime;
    unsigned vanilla_observed;
    unsigned transport_accepted;
    unsigned transport_rejected;
    unsigned reentrant;
    uint32_t last_event_type;
    uint8_t last_slot_hint;
    bool in_observer;
} rp_runtime_r16;
void rp_r16_init(rp_runtime_r16 *, rp_runtime_r15 *);

/* Hook wrapper MUST preserve original return value and call exactly once,
 * even for non-RP events and when the source is untrusted. This is a READ-ONLY
 * event-type diagnostic: NEVER calls rp_r13_decide_observe(). The real hook
 * trampoline still requires independent ABI/device validation. */
bool rp_r16_decide(rp_runtime_r16 *, rp_r16_original_decide, void *original_ctx,
                   uintptr_t event, uintptr_t player_a, uintptr_t player_b);

/* Only call from an independently verified RP-capable P2P transport receive
 * callback, with the ACTUAL engine netPlayer pointer and authenticated 96B
 * payload/length (not from CScriptedGameEvent::Decide nor a packet slot hint).
 * This function rechecks session/roster/peer/generation and existing R11
 * envelope restrictions. It does not itself establish transport provenance. */
bool rp_r16_transport_receive(rp_runtime_r16 *, uintptr_t actual_player,
                              const uint8_t *wire, size_t len);
#endif
