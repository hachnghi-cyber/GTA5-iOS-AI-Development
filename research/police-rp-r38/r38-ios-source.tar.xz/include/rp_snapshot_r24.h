#ifndef RP_SNAPSHOT_R24_H
#define RP_SNAPSHOT_R24_H

#include "rp_ingress_r23.h"

/* R24: bridge from an opaque SAME-CALL RAGE datBitBuffer to R23.
 * This deliberately does NOT implement undocumented datBitBuffer layout.
 * The native integration MUST provide a vetted, non-mutating snapshot
 * decoder and an independently verified pre-sequence private skip hook.
 * No callback has been installed in GTA V; source-only until proven.
 */
#define RP_R24_MAX_EVENT_BITS (1u<<20)
typedef struct {
    uint64_t read_bit;
    uint64_t limit_bit;
    uint64_t storage_generation;
} rp_r24_cursor;

/* Snapshot of cursor state must be passive; no cursor advance/rewind. */
typedef bool (*rp_r24_read_cursor)(void *ctx, uintptr_t opaque_bitbuffer,
                                   rp_r24_cursor *out);
/* Decoder operates on an independently-owned clone or a verified peek API.
 * Its input is the SAME native call; MUST NOT mutate GTA's live bitbuffer.
 * out_capacity is 244. decoded_len is output; never write > capacity.
 * If format is not independently understood, return false. */
typedef bool (*rp_r24_peek_mpj2)(void *ctx, const rp_r23_native_call *call,
                                 uint8_t *out, size_t out_capacity,
                                 size_t *decoded_len);
/* TRUE only after an installed handler has independently demonstrated that
 * PRIVATE RP messages skip original Jobs handling before sequence updates.
 * Returning true based solely on RP packet fields is INVALID. */
typedef bool (*rp_r24_private_isolation)(void *ctx,
                                        const rp_r23_native_call *call);

typedef struct {
    rp_r24_read_cursor cursor;
    rp_r24_peek_mpj2 peek;
    rp_r24_private_isolation isolated;
    void *context;
} rp_r24_provider;

typedef struct {
    rp_r23_ingress *ingress;
    rp_r24_provider provider;
    uint64_t revision;
    uint32_t attempts, vanilla, accepted, rejected, decode_failed,
             cursor_changed, epoch_changed, isolation_denied, policy_changed;
    bool armed, busy, faulted; /* decoder cursor violation disables bridge */
} rp_r24_bridge;

void rp_r24_init(rp_r24_bridge *);
bool rp_r24_arm(rp_r24_bridge *, rp_r23_ingress *,
                const rp_r24_provider *);
void rp_r24_stop(rp_r24_bridge *);
/* Must be called inside the live network-event virtual dispatch. Source-only
 * decision; engine-side hook MUST honor PRIVATE_REJECTED/ACCEPTED and MUST
 * preserve vanilla messages. This library cannot install that engine hook.
 */
rp_r20_result rp_r24_snapshot_dispatch(rp_r24_bridge *,
                                        const rp_r23_native_call *);
#endif
