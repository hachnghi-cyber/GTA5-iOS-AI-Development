#ifndef RP_RUNTIME_R12_H
#define RP_RUNTIME_R12_H
#include "rp_runtime_r11.h"
#include "rp_receive.h"

/* R12: serialized engine-thread transport adapter. No hooks or senders are
 * created here: the engine adapter must attest the live connection identity,
 * session lifetime, and serialized callback context independently. */
#define RP_R12_RX_CAP 32u

typedef bool (*rp_r12_send_fn)(void *ctx, uint8_t recipient,
                               const uint8_t packet[RP_ENGINE_BYTES]);
typedef struct {
    rp_engine_peer peer;           /* from trusted connection, NOT payload */
    bool registered;
} rp_r12_peer;
typedef struct {
    rp_engine_peer actual;
    rp_engine_kind kind;
    uint8_t wire[RP_ENGINE_BYTES];
} rp_r12_event;
typedef struct {
    rp_runtime_r11 core;
    rp_r12_send_fn send;
    void *send_ctx;
    rp_r12_peer peers[RP_MAX];
    rp_r12_event pending[RP_R12_RX_CAP];
    unsigned rx_head,rx_tail,rx_count;
    uint64_t epoch;
    unsigned sent, received, rejected, dropped;
    bool active, quarantined;
    /* Read-only live provenance gate; caller must install validated callbacks. */
    rp_roster roster;
    rp_session_guard session;
    rp_lifecycle life;
    rp_receive_binding binding[RP_MAX];
    bool binding_valid[RP_MAX];
    rp_read_memory read;
    void *read_ctx;
    uintptr_t manager, session_ptr, getter_runtime;
    bool engine_pinned;
} rp_runtime_r12;

bool rp_r12_begin(rp_runtime_r12 *, rp_engine_peer local,
                  rp_engine_peer host, bool local_is_host,
                  rp_r12_send_fn, void *send_ctx);
/* All methods on ONE serialized game thread. Generation update invalidates
 * a peer's old binding and prevents stale inbound snapshots. */
bool rp_r12_register_peer(rp_runtime_r12 *, rp_engine_peer authenticated,
                          bool opt_in);
void rp_r12_stop(rp_runtime_r12 *);
bool rp_r12_observe(rp_runtime_r12 *, uint8_t slot, rp_role,
                    rp_observation);
bool rp_r12_action(rp_runtime_r12 *, rp_action, uint8_t target,
                   uint32_t generation, uint32_t arg, uint64_t now_ms);
/* Host/test adapter from authenticated engine event transport. Never call
 * with a slot obtained from bytes +8 or the physical-index hint alone. */
bool rp_r12_enqueue_authenticated(rp_runtime_r12 *, rp_engine_peer actual_sender,
                                   const uint8_t wire[RP_ENGINE_BYTES]);
/* Drain bounded queue and dispatch reliable sender retries (max 1 per tick).
 * send=true means QUEUED/DISPATCHED only; not delivery proof. */
bool rp_r12_frame(rp_runtime_r12 *, uint64_t now_ms);
/* Install a strict live-session gate, if the real engine has supplied a
 * lifetime-safe snSession, manager, getter address and memory reader. */
bool rp_r12_pin_engine(rp_runtime_r12 *, rp_read_memory, void *ctx,
                       uintptr_t manager, uintptr_t session,
                       uintptr_t getter_runtime);
bool rp_r12_bind_player(rp_runtime_r12 *, rp_engine_peer authenticated,
                        uintptr_t player, uint32_t local_generation,
                        uint64_t peer_id);
/* Native Decide adapter, original event dispatch MUST still be called.
 * Copies into bounded queue; does NOT send or apply native in Decide. */
/* Disabled for v13.3: event+0x224 is event KIND, not RPE3 length. */
bool rp_r12_decide(rp_runtime_r12 *, uintptr_t event, uintptr_t actual_player,
                    rp_engine_peer actual_sender);
/* Frame audit should be invoked before dispatching each live game frame. */
bool rp_r12_audit_engine(rp_runtime_r12 *);
#endif
