#ifndef RP_R16_EXPORTS_H
#define RP_R16_EXPORTS_H
#include "rp_runtime_r16.h"
#ifdef __cplusplus
extern "C" {
#endif
/* Only for a properly linked iOS dylib. NO hooks auto-installed. */
unsigned rp_r16_api_level(void);
bool prp_r16_open_verified(const rp_r13_provider *,const rp_r13_engine_start *,
                            const rp_r14_provider *);
bool prp_r16_decide_wrapped(rp_r16_original_decide,void *,uintptr_t,uintptr_t,uintptr_t);
bool prp_r16_transport_receive(uintptr_t,const uint8_t *,size_t);
bool prp_r16_frame(uint64_t);
bool prp_r16_admit(uintptr_t);
bool prp_r16_request(rp_action,uint8_t,uint32_t,uint32_t,uint64_t);
void prp_r16_after_assignment(uintptr_t);
void prp_r16_disconnect(void);
bool prp_r16_cleanup(uint64_t);
unsigned prp_r16_phase(void);
#ifdef __cplusplus
}
#endif
#endif
