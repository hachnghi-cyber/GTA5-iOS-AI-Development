#ifndef RP_PRESEQUENCE_R28_H
#define RP_PRESEQUENCE_R28_H
#include "rp_snapshot_r24.h"
/* R28: pre-sequence PRIVATE branch wrapper. The platform MUST prove that
 * prefix() is a passive copy from the SAME event delivery at the interception
 * point BEFORE the vanilla Jobs sequence counter changes. Merely reading a
 * packet's slot/sequence/magic does not prove sender identity or isolation.
 * This module does not install an iOS hook or establish that platform proof.
 */
#define RP_R28_PREFIX_BYTES 20u
typedef bool (*rp_r28_copy_prefix)(void *ctx, const rp_r23_native_call *call,
                                    uint8_t out[RP_R28_PREFIX_BYTES]);
typedef bool (*rp_r28_presequence_proven)(void *ctx,
                                          const rp_r23_native_call *call);
typedef struct {
    rp_r24_bridge *bridge;
    rp_r28_copy_prefix prefix;
    rp_r28_presequence_proven presequence;
    void *context;
    uint32_t attempts, normal, private_drop, private_accepted;
    uint32_t unstable, unproven, nested;
    uint32_t descriptor_changed; /* R30: mutable same-call argument detected */
    uint32_t config_changed; /* R32: provider/bridge swapped during callback */
    uint32_t policy_changed; /* R33: nested R24/R23 policy changed */
    bool busy, scanning; /* scanning guards against reentry from prefix/provider */
} rp_r28_presequence;
void rp_r28_init(rp_r28_presequence *, rp_r24_bridge *,
                 rp_r28_copy_prefix, rp_r28_presequence_proven, void *);
/* Known RP signatures NEVER reach vanilla Jobs, even when the R24/R23
 * bridge is unavailable or reentered. Unknown signatures keep vanilla behavior.
 * Caller MUST obey PRIVATE_* return values at the real pre-sequence hook.
 */
rp_r20_result rp_r28_dispatch(rp_r28_presequence *,
                               const rp_r23_native_call *);
#endif
