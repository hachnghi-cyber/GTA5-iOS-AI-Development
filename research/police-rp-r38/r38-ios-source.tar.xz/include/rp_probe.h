#ifndef RP_PROBE_H
#define RP_PROBE_H
#include <stdint.h>
/* Read-only. Must be called by an independently verified game-thread adapter.
   Returning OK proves readable candidate fields, not their gameplay semantics. */
typedef struct { uint32_t uuid_match, fields_readable, receive_code_match, receive_seen_word; int32_t work_candidate; uint8_t shift_candidate; } rp_probe_result;
int rp_v13_probe(rp_probe_result *out);
#endif
