#ifndef RP_RECEIVE_H
#define RP_RECEIVE_H
#include "rp_session.h"
/* Handshake result from a separately authenticated transport. NEVER construct
 * this record from packet claims or a roster scan alone. */
typedef struct {
 rp_engine_peer wire;
 uintptr_t player;
 uint32_t local_generation;
 uint64_t peer_id;
 rp_session_identity session;
} rp_receive_binding;
/* getter_runtime must be UUID/bytes-verified CNetGamePlayer::GetGamerInfo VA
 * plus ASLR slide. Validate vtable slot before using that concrete layout. */
bool rp_peer_id_v13(rp_read_memory,void *,uintptr_t player,uintptr_t getter_runtime,uint64_t *);
/* Call from verified serialized native Decide integration BEFORE original.
 * Does not consume engine events, install hooks, or replace original Decide.
 * On false, outputs cleared; caller must still run original engine dispatch. */
bool rp_receive_v13(rp_read_memory,void *,uintptr_t manager,uintptr_t session,
 uintptr_t getter_runtime,uintptr_t event,uintptr_t actual_player,
 const rp_receive_binding *,rp_session_guard *,rp_roster *,rp_lifecycle *,
 rp_engine_kind *,rp_inbound *);
#endif
