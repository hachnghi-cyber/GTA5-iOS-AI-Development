#ifndef RP_ENGINE_H
#define RP_ENGINE_H
#include "rp_queue.h"
#define RP_ENGINE_BYTES 96
#define RP_ENGINE_SLOTS (RP_ENGINE_BYTES / 8)
/* Engine may rewrite u32 at byte 8. Never put the inner RP epoch there. */
typedef enum { RP_ENGINE_REQUEST=1, RP_ENGINE_ACK=2, RP_ENGINE_SNAPSHOT=3 } rp_engine_kind;
typedef struct { uint8_t slot; uint32_t generation; uint64_t epoch; bool verified; } rp_engine_peer;
bool rp_engine_pack(uint8_t sender, rp_engine_kind, const uint8_t *, size_t,
                    uint8_t out[RP_ENGINE_BYTES]);
/* actual_length must come from native event metadata BEFORE RetrieveData's
 * zero-padding. Peer provenance comes from the connection, not the payload. */
bool rp_engine_unpack(const uint8_t *, size_t actual_length, rp_engine_peer,
                      rp_engine_kind *, rp_inbound *);
#endif
