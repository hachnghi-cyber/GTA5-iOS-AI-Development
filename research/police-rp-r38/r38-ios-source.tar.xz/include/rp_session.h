#ifndef RP_SESSION_H
#define RP_SESSION_H
#include "rp_lifecycle.h"
/* snSession layout proven against the exact baseline. A live snSession address
 * must come from verified integration, not a packet or guessed global. */
typedef struct { uint64_t session_id, host_peer, local_peer; } rp_session_identity;
typedef struct { uintptr_t address; rp_session_identity identity; bool pinned; } rp_session_guard;
bool rp_session_read_v13(rp_read_memory,void *,uintptr_t,rp_session_identity *);
/* Only consistency/lifetime guards. Neither function authenticates senders,
 * creates an RP epoch nor sets rp_engine_peer.verified. */
bool rp_session_pin(rp_session_guard *,rp_read_memory,void *,uintptr_t);
/* Must run before consuming queued traffic or applying native effects on the
 * serialized script/game thread. Any mismatch tears down RP and unpins. */
bool rp_session_audit(rp_session_guard *,rp_read_memory,void *,uintptr_t,rp_lifecycle *);
#endif
