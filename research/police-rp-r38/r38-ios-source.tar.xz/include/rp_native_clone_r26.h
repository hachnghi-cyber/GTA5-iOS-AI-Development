#ifndef RP_NATIVE_CLONE_R26_H
#define RP_NATIVE_CLONE_R26_H

#include "rp_native_peek_r25.h"

/* Binary v13.3 evidence: datBitBuffer::PeekBytes reads 0x00..0x1c,
 * modifies cursor at +0x10 and count at +0x18, then restores them.
 * The 32-byte header is PRIVATE v13.3 ABI, not a public Apple type.
 * This code does not install native hooks or attest the sender.
 */
#define RP_R26_HEADER_BYTES 32u

typedef bool (*rp_r26_copy_header)(void *context, uintptr_t original,
                                    uint8_t out[RP_R26_HEADER_BYTES]);
/* Must return a nonzero stable token for the SAME native event delivery.
 * Never derive this token from the untrusted MPJ2 sequence or player slot.
 * No verified iOS source for this token has been implemented yet. */
typedef bool (*rp_r26_delivery_token)(void *context, uint64_t *token);

/* R27: the 32-byte RAGE header may point into mutable game memory.
 * Read backing bytes through a bounded, checked platform callback; never
 * follow the game's backing pointer directly from the native PeekBytes call.
 */
typedef bool (*rp_r27_copy_backing)(void *context, uintptr_t address,
                                    uint8_t *out, size_t length);

typedef struct {
    rp_r25_decoder decoder;
    rp_r26_copy_header copy_header;
    rp_r26_delivery_token token;
    rp_r25_native_peek native;
    rp_r27_copy_backing owned_backing; /* NULL means legacy R26 shallow clone */
    rp_r25_binding_gate bound;
    void *context;
    uintptr_t active_buffer;
    bool busy, owned_poisoned;
    uint32_t header_snapshots, native_calls, cloned_calls, denied, drift;
    uint32_t owned_snapshots, owned_denied;
} rp_r26_clone;

bool rp_r26_clone_init(rp_r26_clone *clone, rp_r26_copy_header copy_header,
                       rp_r26_delivery_token token, rp_r25_native_peek native,
                       rp_r25_binding_gate bound, void *context);
/* These match rp_r24_provider {cursor, peek} with context = rp_r26_clone*.
 * Integration MUST additionally provide an independently proven pre-sequence
 * RP isolation gate, and an R23 sender verifier from the SAME receive call.
 */
bool rp_r26_make_provider(rp_r26_clone *clone,
                          rp_r24_private_isolation isolation,
                          rp_r24_provider *provider);
bool rp_r26_snapshot_cursor(void *context, uintptr_t original,
                            rp_r24_cursor *out);
bool rp_r26_peek_mpj2(void *context, const rp_r23_native_call *call,
                       uint8_t *out, size_t capacity, size_t *decoded_len);

/* iOS-only passive, bounded 32B header read; no raw dereference, no hook.
 * NOT a verified binding to RAGE, and NOT a source of sender provenance. */
bool rp_r26_ios_copy_header(void *context, uintptr_t original,
                             uint8_t out[RP_R26_HEADER_BYTES]);
#endif
