#ifndef RP_PROVENANCE_R20_H
#define RP_PROVENANCE_R20_H
#include "rp_runtime_r17.h"
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

/* R20 EVENT-SOURCE BOUNDARY: a single trusted native receive callback must
 * provide BOTH the event and the sender netPlayer. DO NOT correlate
 * CScriptedGameEvent::Decide(x0) with MacportJobsUpdate(x25): the binary
 * exposes different engine object types for those callbacks.
 *
 * This is a fail-closed source integration, NOT a working iOS hook. Live
 * event-to-sender attestation remains unavailable without engine code. */
#define RP_R20_NETWORK_SCRIPT_EVENT_TYPE 174u /* CEventNetworkScriptEvent */

typedef struct {
    uintptr_t event;                  /* CEventNetworkScriptEvent*, H6 x25 */
    uintptr_t sender;                 /* MUST be supplied by trusted dispatch */
    uint64_t epoch;                   /* independent engine session epoch */
    uint64_t delivery_id;             /* monotonic per authenticated sender */
    uint32_t event_type;              /* engine-verified event type, not MPJ2 kind */
} rp_r20_witness;

typedef bool (*rp_r20_on_game_thread)(void *ctx);
typedef uint64_t (*rp_r20_read_epoch)(void *ctx);
/* Must independently verify event and netPlayer were paired by the same
 * authenticated native network receive call. Cannot use MPJ2 slot, event
 * address, RPE3 data, or previous Decide() log as the sole evidence. */
typedef bool (*rp_r20_attest_pair)(void *ctx, const rp_r20_witness *w,
                                   uint8_t *verified_slot);
typedef bool (*rp_r20_deliver_rpe3)(void *ctx, uintptr_t sender,
                                     const uint8_t wire[RP_ENGINE_BYTES]);
typedef struct {
    rp_r20_on_game_thread thread;
    rp_r20_read_epoch get_epoch;
    rp_r20_attest_pair attest;
    rp_r20_deliver_rpe3 deliver;
    void *ctx;
    uint64_t bound_epoch;
    /* R21: incremented at each stop/rebind. Prevents callback-driven ABA
     * and a stale handler from claiming success after its session ends. */
    uint64_t revision;
    uint64_t last_ticket[RP_MAX];
    bool ticket_used[RP_MAX];
    uint32_t attempted, accepted, rejected, invalidated;
    bool armed, busy;
} rp_r20_boundary;

/* Single serialized game-thread contract. A callback may reenter stop(),
 * but callers on OTHER threads must serialize externally. stop() never
 * unlocks the in-flight callback; re-arm is refused until it returns. */
void rp_r20_init(rp_r20_boundary *);
void rp_r20_stop(rp_r20_boundary *);
bool rp_r20_arm(rp_r20_boundary *,rp_r20_on_game_thread,
                rp_r20_read_epoch,rp_r20_attest_pair,
                rp_r20_deliver_rpe3,void *ctx);
/* PASS_ORIGINAL always on non-RP work packets; caller MUST NOT alter game
 * vanilla sequence handling unless a separately proven private branch exists.
 * This function does not itself hook/skip/modify GTA event dispatch. */
typedef enum {RP_R20_PASS_ORIGINAL=0, RP_R20_PRIVATE_ACCEPTED=1,
              RP_R20_PRIVATE_REJECTED=2} rp_r20_result;
rp_r20_result rp_r20_receive(rp_r20_boundary *,const rp_r20_witness *,
                             const uint8_t *mpj2,size_t length);
/* Concrete adapter to existing R16 transport authorization. */
bool rp_r20_deliver_to_r16(void *runtime_r16,uintptr_t sender,
                           const uint8_t wire[RP_ENGINE_BYTES]);
#endif
