#ifndef RP_RELIABLE_H
#define RP_RELIABLE_H
#include "rp.h"
#define RP_ACK_WIRE 64
#define RP_ACK_CACHE 8
#define RP_RETRY_MS 250
#define RP_RETRY_COUNT 5
#define RP_REQUEST_TIMEOUT_MS 2000
/* Single game-thread API. Identity comes from the authenticated transport,
 * never from fields parsed out of the request. No crypto is implemented here. */
typedef struct {
    bool valid;
    uint8_t request[RP_WIRE];
    rp_result result;
} rp_cached_reply;
typedef struct {
    rp_host host;
    rp_cached_reply cache[RP_MAX][RP_ACK_CACHE];
    unsigned next[RP_MAX];
} rp_service;
typedef enum { RP_TX_IDLE, RP_TX_PENDING, RP_TX_DONE, RP_TX_TIMEOUT } rp_tx_status;
typedef struct {
    uint64_t epoch, started_ms, last_poll_ms, next_send_ms;
    uint32_t generation, next_seq;
    uint8_t slot, attempts;
    rp_tx_status status;
    rp_result result;
    uint8_t request[RP_WIRE];
} rp_sender;
void rp_service_init(rp_service *, uint64_t epoch);
/* Returns false (no ACK) for malformed/unbound traffic. For an accepted
 * envelope, result may still reject gameplay; ACK is not a state snapshot. */
bool rp_service_receive(rp_service *, uint8_t authenticated_slot,
                        uint32_t authenticated_generation,
                        const uint8_t *, size_t, uint8_t ack[RP_ACK_WIRE]);
void rp_sender_init(rp_sender *, uint64_t epoch, uint8_t slot, uint32_t generation);
bool rp_sender_submit(rp_sender *, rp_action, uint8_t target,
                      uint32_t target_generation, uint32_t arg, uint64_t now_ms);
bool rp_sender_poll(rp_sender *, uint64_t now_ms, uint8_t request[RP_WIRE]);
bool rp_sender_ack(rp_sender *, bool authenticated_host,
                   const uint8_t *, size_t, uint64_t now_ms);
#endif
