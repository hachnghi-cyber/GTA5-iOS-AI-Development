#ifndef RP_NATIVE_H
#define RP_NATIVE_H
#include "rp_engine.h"
/* scrVector loads are at offsets 0, 8, 16 in the verified v13 disassembly. */
typedef struct { float x; uint32_t pad_x; float y; uint32_t pad_y; float z; uint32_t pad_z; } rp_scr_vector;
typedef struct {
    void *(*script_handler)(void);
    int (*player_ped)(void);
    bool (*entity_exists)(int);
    void (*handcuffs)(int,bool);
    void (*disable_control)(int,int,bool);
    void (*follow)(int,int,const rp_scr_vector *,float,int,float,bool);
    void (*coords)(int,const rp_scr_vector *,bool,bool,bool,bool);
    void (*trigger_event)(int,int *,int,int);
} rp_native_api;
typedef struct {
    rp_native_api api;
    bool bound, cuff_owned, follow_owned, jail_placed;
    int ped, owner_ped;
    uint64_t next_follow_ms;
    uint8_t state;
} rp_native;
/* Verified game-thread + online/local-ped/session provenance must be supplied
 * by the integration. bound only certifies the function table, not that context. */
typedef struct {
    bool game_thread, online, local_ped_verified, owner_verified, jail_verified;
    int local_ped, owner_ped;
    rp_scr_vector jail;
    uint64_t now_ms;
    uint32_t owner_generation;
} rp_native_frame;
bool rp_native_send(rp_native *, bool game_thread, bool online,
                    uint8_t local_slot, uint32_t recipients,
                    rp_engine_kind, const uint8_t *, size_t);
bool rp_native_apply(rp_native *, const rp_native_frame *, rp_state);
bool rp_native_clear(rp_native *, const rp_native_frame *);
/* iOS implementation: v13.3 UUID + first 16 instruction bytes for every target.
 * Candidate ABI only; cannot attest engine thread, receiver or device behavior.
 * No auto-load, no trampoline/hook installation. */
bool rp_native_bind_v133(rp_native *);
#endif
