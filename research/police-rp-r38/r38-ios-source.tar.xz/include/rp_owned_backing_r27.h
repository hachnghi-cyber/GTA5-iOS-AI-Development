#ifndef RP_OWNED_BACKING_R27_H
#define RP_OWNED_BACKING_R27_H
#include "rp_native_clone_r26.h"
/* Strict R27 mode. Must be set after rp_r26_clone_init and before any
 * callback starts. No automatic installation in game; iOS must supply a
 * checked backing reader, same-call sender verification and RP isolation. */
bool rp_r27_attach_owned_reader(rp_r26_clone *clone, rp_r27_copy_backing reader);
bool rp_r27_make_owned_provider(rp_r26_clone *clone,
                                rp_r24_private_isolation isolation,
                                rp_r24_provider *out);
/* Platform callback: iPhoneOS Mach read, bounded to <=245 bytes. */
bool rp_r27_ios_copy_backing(void *context, uintptr_t source,
                             uint8_t *out, size_t length);
#endif
