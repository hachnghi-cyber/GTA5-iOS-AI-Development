#ifndef RP_RUNTIME_R11_H
#define RP_RUNTIME_R11_H
#include "rp_bridge.h"
/* Transport adapter boundary: caller MUST authenticate actual_sender/host
   from live engine connection identity. This source does not create that proof. */
typedef struct {
    rp_service service;  /* only authoritative when local_is_host */
    rp_sender sender;
    rp_client client;
    rp_engine_peer local, host;
    bool initialized, local_is_host;
} rp_runtime_r11;
bool rp_r11_begin(rp_runtime_r11 *,rp_engine_peer local,rp_engine_peer host,bool local_is_host);
void rp_r11_close(rp_runtime_r11 *);
bool rp_r11_host_join(rp_runtime_r11 *,uint8_t slot,uint32_t generation,bool opt_in);
bool rp_r11_host_observe(rp_runtime_r11 *,uint8_t slot,rp_role,rp_observation);
void rp_r11_tick(rp_runtime_r11 *,uint64_t now_ms);
bool rp_r11_submit(rp_runtime_r11 *,rp_action,uint8_t target,uint32_t target_gen,
                   uint32_t arg,uint64_t now_ms);
bool rp_r11_next(rp_runtime_r11 *,uint64_t now_ms,uint8_t out[RP_ENGINE_BYTES]);
/* Engine sends back ACK to actual_sender.slot and snapshot to request target.
   Validated by host service and transport provenance. The integration must
   send BOTH messages over authenticated RAGE transport on the correct thread. */
bool rp_r11_host_receive(rp_runtime_r11 *,rp_engine_peer actual_sender,
                         const uint8_t wire[RP_ENGINE_BYTES],
                         uint8_t ack[RP_ENGINE_BYTES],
                         uint8_t snapshot[RP_ENGINE_BYTES],uint8_t *snapshot_target);
/* Only authenticated host may ACK/snapshot. Never applies native from ACK. */
bool rp_r11_client_receive(rp_runtime_r11 *,rp_engine_peer actual_sender,
                           const uint8_t wire[RP_ENGINE_BYTES],uint64_t now_ms);
#endif
