#ifndef RP_RUNTIME_R18_H
#define RP_RUNTIME_R18_H
#include "rp_runtime_r17.h"
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

/* R18 is a opt-in pre-sequence MPJ2 dispatch contract, NOT a live RAGE hook.
 * No caller can enable RP by reading the untrusted MPJ2 sender slot alone.
 * The provider must independently validate the live game-thread, session
 * epoch, and installed private-job bypass BEFORE original MPJ2 sequencing.
 * All vanilla jobs MUST be dispatched unchanged. Private RP commands MUST
 * be skipped by a verified pre-sequence hook EVEN IF RP IS DISABLED. */
typedef bool (*rp_r18_check)(void *ctx);
typedef uint64_t (*rp_r18_epoch)(void *ctx);
typedef enum {
    RP_R18_PASS_ORIGINAL=0,  /* no interference with native GTA processing */
    RP_R18_PRIVATE_HANDLED=1,/* skip original ONLY for this authenticated private job */
    RP_R18_PRIVATE_REJECTED=2/* skip original ONLY for private job, no gameplay */
} rp_r18_decision;
typedef struct {
    rp_runtime_r17 *r17;
    rp_r18_check on_game_thread;
    rp_r18_check isolated_dispatch; /* verified private bypass installed */
    rp_r18_epoch read_epoch;
    void *context;
    uint64_t bound_epoch;
    uint64_t revision; /* R22: revoke token, prevents callback-driven ABA */
    bool busy;         /* single game thread; preserved across unbind() */
    bool armed;
    unsigned pass_original, rejected, handled, sent, invalidations;
} rp_runtime_r18;

void rp_r18_init(rp_runtime_r18 *);
/* Return false until ALL checks prove the safe receiver is installed. */
bool rp_r18_bind(rp_runtime_r18 *, rp_runtime_r17 *, rp_r18_check game_thread,
                 rp_r18_check pre_sequence_isolation, rp_r18_epoch epoch, void *ctx);
/* Invalidates the binding; callers must clean any native RP effects separately. */
void rp_r18_unbind(rp_runtime_r18 *);
/* Must be called ONLY from a separately vetted callback BEFORE vanilla MPJ2
 * per-sender sequence state is modified. The engine-side dispatcher must
 * honor PRIVATE_REJECTED even after the RP runtime is unbound. Caller MUST use decision to branch;
 * code in this file NEVER changes the original GTA event's memory. */
/* May be used by the pre-sequence bootstrap when the runtime is not yet
 * initialized. No callbacks, no memory reads beyond length. */
rp_r18_decision rp_r18_early_decision(const uint8_t *,size_t);
rp_r18_decision rp_r18_receive(rp_runtime_r18 *, const void *authenticated_cookie,
                               const uint8_t *mpj2, size_t length);
/* Return true means native enqueue callback was invoked, NOT peer delivery. */
bool rp_r18_send(rp_runtime_r18 *, uint8_t recipient,
                 const uint8_t wire[RP_ENGINE_BYTES]);
#endif
