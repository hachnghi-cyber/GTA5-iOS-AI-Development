#ifndef RP_QUEUE_H
#define RP_QUEUE_H
#include <stdatomic.h>
#include "rp_reliable.h"
#define RP_QUEUE_CAPACITY 64
/* Exactly one producer, one consumer. Never reset while either is active.
 * The producer attaches authenticated transport identity BEFORE enqueue.
 * Payload length is exact; oversized datagrams are rejected, not truncated. */
typedef struct {
    uint8_t peer;
    uint32_t generation;
    size_t length;
    uint8_t bytes[RP_ACK_WIRE];
} rp_inbound;
typedef struct {
    atomic_uint head, tail;
    rp_inbound items[RP_QUEUE_CAPACITY + 1];
} rp_queue;
void rp_queue_init(rp_queue *);
bool rp_queue_push(rp_queue *, uint8_t peer, uint32_t generation,
                   const uint8_t *, size_t);
bool rp_queue_pop(rp_queue *, rp_inbound *);
#endif
