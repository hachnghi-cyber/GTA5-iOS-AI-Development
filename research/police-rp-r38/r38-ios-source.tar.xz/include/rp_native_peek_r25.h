#ifndef RP_NATIVE_PEEK_R25_H
#define RP_NATIVE_PEEK_R25_H
#include "rp_snapshot_r24.h"

/* ARM64 ABI (v13.3): rage::datBitBuffer::PeekBytes(void*, int bytes, int start_bit)
 * This native method TEMPORARILY changes cursor fields and restores them on
 * return. It is only safe to invoke within a proven serialized game callback.
 * Pointer is NOT resolved from untrusted packet data; the platform binder
 * must check v13.3's MH_EXECUTE UUID and entry/tail opcode fingerprints.
 */
typedef bool (*rp_r25_native_peek)(const void *bitbuffer, void *dest,
                                    int byte_count, int start_bit);
typedef bool (*rp_r25_binding_gate)(void *context);
/* R26: context-aware, read-only-clone invocation. This replaces the live
 * datBitBuffer this-pointer in the R25 decoder when configured. */
typedef bool (*rp_r25_guarded_peek)(void *context, const void *original,
                                     void *dest, int byte_count, int start_bit);

typedef struct {
    rp_r24_read_cursor cursor;
    rp_r25_native_peek native_peek;
    rp_r25_guarded_peek guarded_peek;
    rp_r25_binding_gate bound_to_v133;
    void *context;
    uint32_t header_reads, private_full_reads, rejected, cursor_faults;
} rp_r25_decoder;

/* Does not install hooks or change the original engine's sequencing. */
void rp_r25_decoder_init(rp_r25_decoder *decoder,
                         rp_r24_read_cursor cursor,
                         rp_r25_native_peek peek,
                         rp_r25_binding_gate gate,
                         void *context);
bool rp_r25_snapshot_cursor(void *context, uintptr_t bitbuffer,
                            rp_r24_cursor *out);
bool rp_r25_peek_mpj2(void *context, const rp_r23_native_call *call,
                       uint8_t *out, size_t capacity, size_t *decoded_len);
/* Platform-only: resolves the local (not exported) method from pinned v13.3
 * Mach-O. Does not activate network RP or call the native function. */
bool rp_r25_resolve_v133_peek(rp_r25_native_peek *out);
#endif
