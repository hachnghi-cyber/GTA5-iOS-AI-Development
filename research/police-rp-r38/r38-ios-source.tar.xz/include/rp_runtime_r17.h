#ifndef RP_RUNTIME_R17_H
#define RP_RUNTIME_R17_H
#include "rp_runtime_r16.h"

/* v13.3 Macport job transport format from audited ARM64 disassembly.
   The game emits an MPJ2 244-byte CScriptedGameEvent, with header:
   +0 magic MPJ2; +8 claimed sender index; +16 job kind; +20 seq;
   +24 engine job-state field.  The private R17 extension starts at +32.
   This is ONLY a candidate transport envelope. No iOS hook is installed. */
#define RP_R17_JOB_BYTES 244u
#define RP_R17_MAGIC 0x324a504dU /* 'MPJ2' as little-endian uint32 */
#define RP_R17_CUSTOM_KIND 0x37315052U /* 'RP17' private command, not vanilla jobs 1..12 */
#define RP_R17_EXTENSION_MAGIC 0x37315250U /* 'PR17' */
#define RP_R17_EXT_OFFSET 32u
#define RP_R17_PAYLOAD_OFFSET 48u
#define RP_R17_EXT_VERSION 1u

/* Same thread as game event handler; callback must queue through the verified
   244-byte CScriptedGameEvent path. Return=true means queued, NOT delivered.
   Calling MacportJobSend by address without verifying the original ABI is
   forbidden. Target is a 32-bit mask of recipients, never from RP payload. */
typedef bool (*rp_r17_emit_job)(void *context,
    const uint8_t job[RP_R17_JOB_BYTES], uint32_t private_kind,
    uint32_t recipient_mask);

/* This callback MUST derive sender netPlayer from an independently verified
   RAGE network dispatch context, NOT from packet slot, event hint, address,
   or RP payload.  The external event cookie is owned by the hook adapter. */
typedef bool (*rp_r17_attest_sender)(void *context, const void *event_cookie,
                                    uintptr_t *verified_net_player);

typedef struct {
    rp_runtime_r16 *gate;
    rp_r17_emit_job emit;
    rp_r17_attest_sender attest;
    void *context;
    unsigned encoded, queued, rejected_send, accepted_receive, rejected_receive;
    bool busy;
} rp_runtime_r17;

void rp_r17_init(rp_runtime_r17 *, rp_runtime_r16 *, rp_r17_emit_job,
                 rp_r17_attest_sender, void *);

/* Encode/decode isolated private job command.  Slot & seq fields are filled
   by the existing MacportJobSend native path (not by these functions).
   CRC is accidental-corruption detection ONLY, never authentication. */
bool rp_r17_pack_job(uint8_t out[RP_R17_JOB_BYTES],
                     const uint8_t rpe3[RP_ENGINE_BYTES]);
bool rp_r17_unpack_job(const uint8_t *job, size_t len,
                       uint8_t rpe3[RP_ENGINE_BYTES], uint8_t *slot_hint);

/* Adapter for rp_r12_send_fn: no reference to native game functions and
   no network I/O. Valid only after a vetted emit callback is installed. */
bool rp_r17_send(rp_runtime_r17 *, uint8_t recipient_slot,
                 const uint8_t rpe3[RP_ENGINE_BYTES]);

/* Network-side callback: validates private MPJ2 envelope, obtains independent
   sender provenance, checks hint == netPlayer slot via trusted reader, and
   finally passes only the 96-byte RPE3 into the R16 authenticated gate.
   The original GTA event dispatch MUST continue regardless of this result. */
bool rp_r17_receive(rp_runtime_r17 *, const void *event_cookie,
                    const uint8_t *job, size_t len);
#endif
