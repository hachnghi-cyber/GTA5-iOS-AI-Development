#ifndef RP_LIFECYCLE_H
#define RP_LIFECYCLE_H
#include "rp_bridge.h"
#include "rp_roster.h"
typedef enum { RP_LIFE_REMOVE=1, RP_LIFE_DEALLOCATE, RP_LIFE_SHUTDOWN, RP_LIFE_PROVENANCE_LOST } rp_life_reason;
/* Single serialized game-thread context. These are integration adapters, not
 * installed detours. Original callbacks MUST be verified trampolines/callers. */
typedef struct {
    rp_service *service;
    rp_sender *sender;
    rp_client *client;
    rp_roster *roster;
    rp_native *native;
    bool cleanup_pending;
    rp_life_reason reason;
} rp_lifecycle;
/* Conservative policy: any player removal stops the entire RP session until
 * a fresh authenticated epoch/handshake. Never calls GTA natives here. */
void rp_lifecycle_stop(rp_lifecycle *, rp_life_reason);
bool rp_lifecycle_cleanup_frame(rp_lifecycle *, const rp_native_frame *);
typedef void (*rp_original_player_call)(uintptr_t manager, uintptr_t player);
typedef void (*rp_original_shutdown_call)(uintptr_t manager);
/* Calls original exactly once, including null player. Return only says original
 * was called, not whether a player was removed. NULL original fails closed. */
bool rp_lifecycle_remove(rp_lifecycle *, rp_original_player_call, uintptr_t, uintptr_t);
bool rp_lifecycle_deallocate(rp_lifecycle *, rp_original_player_call, uintptr_t, uintptr_t);
bool rp_lifecycle_shutdown(rp_lifecycle *, rp_original_shutdown_call, uintptr_t);
#endif
