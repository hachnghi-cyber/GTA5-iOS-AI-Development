#ifndef RP_RUNTIME_R15_H
#define RP_RUNTIME_R15_H
#include "rp_runtime_r14.h"

/* R15 orchestration boundary for ONE serialized game/script thread.
 * No hook is installed and no transport/engine identity is invented here.
 * The embedding layer must independently attest RAGE callback provenance,
 * game-thread affinity, local/host/remote peers, and native ABI before open.
 * A caller MUST always dispatch the original RAGE event handler. */
typedef enum {
    RP_R15_IDLE = 0,
    RP_R15_ACTIVE = 1,
    RP_R15_DRAINING = 2
} rp_r15_phase;

typedef struct {
    rp_runtime_r13 session;
    rp_runtime_r14 effects;
    rp_r15_phase phase;
    uint64_t last_tick_ms;
    uint64_t last_input_ms;
    unsigned opens, stops, observed_events, accepted_events;
    unsigned submitted, denied_inputs, rejected_frames, cleanup_retries;
    bool tick_seen, input_seen;
} rp_runtime_r15;

/* First initialize once; NEVER zero/reset while cleanup is pending.
 * Opening requires independently verified providers and an attested session.
 * R15 does NOT authenticate engine callback providers by itself. */
void rp_r15_init(rp_runtime_r15 *);
bool rp_r15_open(rp_runtime_r15 *, const rp_r13_provider *,
                 const rp_r13_engine_start *, const rp_native *,
                 const rp_r14_provider *);
/* Admit a peer only after independently authenticated RP opt-in/handshake. */
bool rp_r15_admit(rp_runtime_r15 *, uintptr_t authenticated_player);
/* Diagnostic Decide observer. Return true only if a validated RP packet was
 * queued. Does not replace, block, or forward the game's original handler. */
bool rp_r15_observe_decide(rp_runtime_r15 *, uintptr_t event,
                           uintptr_t actual_authenticated_player);
/* Input edge from separately verified touch/custom-key provider; 300 ms
 * anti-spam gating. Submission means request queued, NOT a cuff success. */
bool rp_r15_request(rp_runtime_r15 *, rp_action, uint8_t target,
                    uint32_t generation, uint32_t arg, uint64_t now_ms);
/* One tick invokes R13 audit & network and R14 local effects at most once.
 * On DRAINING phase, only native cleanup is retried. */
bool rp_r15_frame(rp_runtime_r15 *, uint64_t now_ms);
/* Call AFTER original physical-player assignment, with the real pointer. */
void rp_r15_after_assignment(rp_runtime_r15 *, uintptr_t touched_player);
/* On disconnect/host migration/session loss, immediately revoke RP effects.
 * Cleanup retries only with fresh attested script-thread and local ped. */
void rp_r15_stop(rp_runtime_r15 *);
bool rp_r15_cleanup(rp_runtime_r15 *, uint64_t now_ms);
#endif
