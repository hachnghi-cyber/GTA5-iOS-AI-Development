#ifndef RP_R15_EXPORTS_H
#define RP_R15_EXPORTS_H
#include "rp_runtime_r15.h"
#ifdef __cplusplus
extern "C" {
#endif
/* Exported by libPoliceRP_R15.dylib only when linked with Apple iPhoneOS SDK.
 * The application owns the original RAGE event/game-thread dispatch and must
 * independently attest callback ABI, sender, and session. NOT a public GTA API.
 * No functions below are automatically hooked by the library constructor. */
unsigned rp_r15_api_level(void);
bool prp_r15_open_verified(const rp_r13_provider *callbacks,
                           const rp_r13_engine_start *session,
                           const rp_r14_provider *local_ped);
bool prp_r15_admit(uintptr_t authenticated_player);
bool prp_r15_event_observer(uintptr_t event, uintptr_t actual_sender_player);
bool prp_r15_frame(uint64_t monotonic_ms);
bool prp_r15_request(rp_action action,uint8_t target,
                     uint32_t generation,uint32_t arg,uint64_t now_ms);
void prp_r15_after_assignment(uintptr_t touched_player);
void prp_r15_disconnect(void);
bool prp_r15_cleanup(uint64_t monotonic_ms);
unsigned prp_r15_phase(void);
#ifdef __cplusplus
}
#endif
#endif
