#ifndef RP_BRIDGE_H
#define RP_BRIDGE_H
#include "rp_native.h"
/* All functions run on the verified game thread after a bounded network queue.
 * Caller manages roster/handshake and supplies actual engine connection identity. */
bool rp_bridge_host_request(rp_service *, rp_engine_peer host, rp_engine_peer sender,
                            const uint8_t *,size_t,uint8_t ack[RP_ENGINE_BYTES]);
bool rp_bridge_snapshot(rp_service *,rp_engine_peer host,uint8_t target,
                        uint8_t out[RP_ENGINE_BYTES]);
bool rp_bridge_client_receive(rp_sender *,rp_client *,rp_engine_peer expected_host,
                              rp_engine_peer actual_sender,const uint8_t *,size_t,uint64_t);
/* Apply ONLY accepted local snapshot; ACK does not trigger gameplay effects. */
bool rp_bridge_local_frame(rp_native *,rp_client *,const rp_native_frame *,bool session_valid);
#endif
