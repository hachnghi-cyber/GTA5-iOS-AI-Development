#ifndef RP_EFFECTS_H
#define RP_EFFECTS_H
#include "rp.h"
/* Adapter is supplied only after game-thread/native ABI validation.
   apply_local must be idempotent, modify only this module's own effects, and
   return false on unavailable player/model/native context. Never use remote CPed*.
   clear_local must release only RP-owned controls/attachments, not unrelated mods. */
typedef struct {
 void *context;
 bool (*apply_local)(void *,rp_state,uint8_t owner,bool surrender);
 void (*clear_local)(void *);
} rp_effect_api;
typedef struct { bool active; } rp_effects;
bool rp_effects_frame(rp_effects *,rp_client *,const rp_effect_api *,uint64_t now_ms,bool session_valid,bool game_thread);
#endif
