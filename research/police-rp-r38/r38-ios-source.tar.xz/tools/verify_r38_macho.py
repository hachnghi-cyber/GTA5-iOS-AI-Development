#!/usr/bin/env python3
"""Fail-closed structural validation of a *linked* iOS ARM64 dylib.

This is a static Mach-O validator, NOT evidence that dyld can load the file,
that signing is correct, or that a RAGE callback is installed. Deliberately
rejects objects, ELF, macOS-only dylibs, and unlinked or missing entrypoints.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import struct
from pathlib import Path

MH_MAGIC_64 = 0xFEEDFACF
CPU_TYPE_ARM64 = 0x0100000C
MH_DYLIB = 6
LC_ID_DYLIB = 0x0D
LC_SYMTAB = 0x02
LC_BUILD_VERSION = 0x32
LC_VERSION_MIN_IPHONEOS = 0x25
PLATFORM_IOS = 2
EXPECTED_ID = '@executable_path/Frameworks/libPoliceRP_R38.dylib'
REQUIRED_EXPORTS = (
    '_prp_r16_open_verified',
    '_prp_r16_transport_receive',
    '_prp_r16_request',
    '_prp_r16_disconnect',
    '_prp_r18_presequence_event',
    '_prp_r27_prepare_native_decoder',
)

class InvalidMachO(ValueError):
    pass

def need(condition: bool, message: str) -> None:
    if not condition:
        raise InvalidMachO(message)

def parse(data: bytes) -> dict:
    need(len(data) >= 32, 'missing 64-bit Mach-O header')
    magic, cpu, subtype, ftype, ncmds, cmdsize, flags, reserved = struct.unpack_from('<IiiIIIII', data)
    need(magic == MH_MAGIC_64, 'not a little-endian 64-bit Mach-O (objects/ELF rejected)')
    need(cpu == CPU_TYPE_ARM64, 'not CPU_TYPE_ARM64')
    need(ftype == MH_DYLIB, 'not an MH_DYLIB: object/executable rejected')
    need(1 <= ncmds <= 4096 and 8 <= cmdsize <= 1 << 20, 'invalid load command count or size')
    need(32 + cmdsize <= len(data), 'load commands truncated')
    p, end = 32, 32 + cmdsize
    has_ios = False
    name = None
    sym = None
    for _ in range(ncmds):
        need(p + 8 <= end, 'load command header truncated')
        cmd, size = struct.unpack_from('<II', data, p)
        need(size >= 8 and p + size <= end, 'load command outside command region')
        if cmd == LC_BUILD_VERSION:
            need(size >= 24, 'LC_BUILD_VERSION truncated')
            platform = struct.unpack_from('<I', data, p + 8)[0]
            need(platform == PLATFORM_IOS, f'wrong Mach-O target platform: {platform}; iOS required')
            has_ios = True
        elif cmd == LC_VERSION_MIN_IPHONEOS:
            need(size >= 16, 'LC_VERSION_MIN_IPHONEOS truncated')
            has_ios = True
        elif cmd == LC_ID_DYLIB:
            need(size >= 24, 'LC_ID_DYLIB truncated')
            name_off = struct.unpack_from('<I', data, p + 8)[0]
            need(24 <= name_off < size, 'install-name offset invalid')
            raw = data[p + name_off:p + size].split(b'\0', 1)[0]
            try:
                name = raw.decode('ascii')
            except UnicodeDecodeError as e:
                raise InvalidMachO('install name non-ASCII') from e
        elif cmd == LC_SYMTAB:
            need(size >= 24, 'LC_SYMTAB truncated')
            sym = struct.unpack_from('<IIII', data, p + 8)
        p += size
    need(p == end, 'load-command-size mismatch')
    need(has_ios, 'missing iOS platform load command')
    need(name == EXPECTED_ID, f'install name mismatch: {name}')
    need(sym is not None, 'missing symbol table')
    off, nsyms, stroff, strsize = sym
    need(nsyms <= 300000 and strsize <= 32 * 1024 * 1024, 'unbounded symbol table')
    need(off <= len(data) and 16 * nsyms <= len(data) - off, 'symbol table out of file')
    need(stroff <= len(data) and strsize <= len(data) - stroff, 'string table out of file')
    strtab = data[stroff:stroff + strsize]
    exports: set[str] = set()
    for i in range(nsyms):
        index, typ, sect, desc, value = struct.unpack_from('<IBBHQ', data, off + i * 16)
        # N_EXT with defined symbol (N_UNDF is 0). Ignore STABS.
        if (typ & 0xE0) or not (typ & 1) or (typ & 0x0E) == 0:
            continue
        need(index < len(strtab), 'symbol string offset out of range')
        end_of_name = strtab.find(b'\0', index)
        need(end_of_name != -1, 'unterminated symbol name')
        try:
            exports.add(strtab[index:end_of_name].decode('ascii'))
        except UnicodeDecodeError:
            continue
    missing = sorted(set(REQUIRED_EXPORTS) - exports)
    need(not missing, f'required exported symbols missing: {missing}')
    return {
        'format': 'Mach-O 64-bit ARM64 DYLIB',
        'platform': 'iOS device (per LC_BUILD_VERSION/LC_VERSION_MIN_IPHONEOS)',
        'install_name': name,
        'load_commands': ncmds,
        'exported_symbols_found': sorted(set(REQUIRED_EXPORTS) & exports),
        'byte_length': len(data),
        'sha256': hashlib.sha256(data).hexdigest(),
        'verified_by': 'static parser only',
        'dyld_device_load_verified': False,
        'codesigned': False,
        'gameplay_verified': False,
    }

def main() -> int:
    ap=argparse.ArgumentParser()
    ap.add_argument('dylib', type=Path)
    ap.add_argument('--json', type=Path)
    opts=ap.parse_args()
    try:
        result=parse(opts.dylib.read_bytes())
    except (OSError, InvalidMachO) as exc:
        print('R38 Mach-O validation FAIL:', exc)
        return 1
    result_text=json.dumps(result,ensure_ascii=False,indent=2)+'\n'
    if opts.json:
        opts.json.parent.mkdir(parents=True,exist_ok=True)
        opts.json.write_text(result_text)
    print('R38 Mach-O static validation PASS:',result['sha256'])
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
