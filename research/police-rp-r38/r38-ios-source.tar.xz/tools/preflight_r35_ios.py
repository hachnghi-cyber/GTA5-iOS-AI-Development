#!/usr/bin/env python3
"""Fail-fast input audit for PoliceRP R35 iOS build. No SDK or device is implied."""
from __future__ import annotations
import argparse
import hashlib
import json
import pathlib
import re
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
SCRIPT = ROOT / 'ios' / 'build_r35.sh'
REQUIRED = {
    'ios/native_v133.c',
    'ios/r18_bootstrap.c',
    'ios/r25_bind_v133.c',
    'ios/r26_snapshot_v133.c',
    'ios/r27_backing_v133.c',
    'ios/r27_bootstrap.c',
}
FORBIDDEN = {'ios/r28_backing_v133.c', 'ios/r28_bootstrap.c'}

def run() -> dict:
    raw = SCRIPT.read_text(encoding='utf-8')
    # Build script uses a fixed source list across a backslash-continued shell
    # for-loop, without variable substitution in its iOS source entries.
    m = re.search(r'for source in\s+(.*?)\s*;\s*do', raw, re.S)
    if not m:
        raise ValueError('missing explicit source loop in ios/build_r35.sh')
    entries = re.sub(r'\\\s*\n', ' ', m.group(1)).split()
    expected_token = 'src/*.c'
    if entries.count(expected_token) != 1:
        raise ValueError('src/*.c must occur exactly once')
    ios = {x for x in entries if x.startswith('ios/')}
    if ios != REQUIRED:
        raise ValueError('iOS source manifest mismatch; missing=%s unexpected=%s' %
                         (sorted(REQUIRED-ios), sorted(ios-REQUIRED)))
    if ios & FORBIDDEN:
        raise ValueError('references nonexistent R28 bootstrap/backing source')
    src = sorted((ROOT / 'src').glob('*.c'))
    files = [*map(lambda p: str(p.relative_to(ROOT)), src), *sorted(ios)]
    if not src or len(entries) != len(set(entries)):
        raise ValueError('missing core modules or duplicated entries')
    if any(not (ROOT / p).is_file() for p in files):
        raise ValueError('at least one listed iOS source file is absent')
    stems = [pathlib.Path(s).stem for s in files]
    if len(set(stems)) != len(stems):
        raise ValueError('object file stem collision')
    for label in ('-arch arm64', '-dynamiclib', '-isysroot "$sdk"',
                  '-miphoneos-version-min=16.3'):
        if label not in raw:
            raise ValueError('missing iOS compiler/link contract: %s' % label)
    return {'result':'PASS', 'scope':'build input audit only',
        'source_script':str(SCRIPT.relative_to(ROOT)),
        'source_script_sha256':hashlib.sha256(SCRIPT.read_bytes()).hexdigest(),
        'ios_source_count':len(ios), 'core_source_count':len(src),
        'listed_sources':files,
        'linked_dylib':False, 'ios_sdk_compiled':False,
        'ipa_created':False, 'runtime_hook_installed':False}

def main() -> int:
    p = argparse.ArgumentParser(); p.add_argument('--json'); a=p.parse_args()
    try:
        info=run()
    except (ValueError, OSError) as ex:
        print('R35 preflight FAIL:', ex, file=sys.stderr)
        return 1
    if a.json:
        pathlib.Path(a.json).write_text(json.dumps(info,indent=2)+'\n',encoding='utf-8')
    print('R35 preflight PASS: %d core + %d iOS inputs; no SDK compile/link performed' %
          (info['core_source_count'],info['ios_source_count']))
    return 0
if __name__ == '__main__':
    raise SystemExit(main())
