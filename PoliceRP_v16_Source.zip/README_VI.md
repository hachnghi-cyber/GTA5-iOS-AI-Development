# GTA V iOS v12 Police RP ONLY – v1.6 Online Session Probe

**Không phải bản Police RP bắt được người chơi.** Chỉ đọc một số biến toàn cục đã xác định tĩnh từ đúng GTA5 v12, không gọi API gameplay, không hook, không gửi sự kiện mạng, không bật Menyoo.

Mục tiêu v1.6: so sánh **Story Mode**, **phòng Online có 1 người**, **phòng có 2 người**, và **thoát phòng** trước khi cố gắng liệt kê Player ID thật. Chỉ có `online_mode_raw`, `session_started_raw`, `job_players_raw`, `was_in_game_raw`, `p2p_joining_raw`. `job_players_raw` **CHƯA chứng minh là số người trong phòng**; KHÔNG sử dụng làm Player ID, quyền Host hoặc mục tiêu bắt giữ.

Các địa chỉ chỉ áp dụng cho GTA5 UUID `6A498E32-E70C-334C-BCA3-AFFD35E8D171`:

| Ký hiệu nhị phân | VM address |
|---|---|
| `s_iMacportOnlineMode` | `0x1027B1AE8` |
| `s_bMacportSessionStarted` | `0x10355577D` |
| `s_uMacportJobPlayers` | `0x103555794` |
| `s_bMacportP2pJoining` | `0x103550204` |
| `s_bWasInGame` (local static of MacportOnlineUpdate) | `0x1035501FC` |
| `s_iMacportWork` | `0x1027B1B2C` |
| `s_bMacportWorkOnShift` | `0x10355EE34` |

Các tên/địa chỉ được kiểm tra từ bảng symbol Mach-O của IPA v12. **Ý nghĩa chính xác của các trường Online chưa được xác minh bằng chạy thực tế**; mã chỉ ghi giá trị thô. Thao tác đọc đồng thời trên main queue không phải đồng bộ chính thức với game thread, nên đôi khi snapshot có thể không nhất quán. Đừng dùng để xử lý gameplay.

## Build trên GitHub bằng iPhone

Cách đơn giản: chỉ cần đưa `PoliceRP_v1.6_Source.zip` lên thư mục gốc repository, rồi tạo `.github/workflows/import-police-rp-v16-IPHONE.yml` bằng nội dung tệp kèm ngoài ZIP. Vào Actions > `Police RP v1.6 - Import ZIP and build iOS session diagnostic` > Run workflow. Gửi artifact `PRP-v16-iPhone-ARM64-ONLINE-SESSION-DIAGNOSTIC-ONLY.zip` vào ChatGPT.

Hoặc giải nén 5 tệp của ZIP vào repo để chạy workflow `build-prp-v16-online-ios.yml` trong ZIP.

## Sau khi có IPA thử nghiệm

1. Sao lưu GTA V v12 và dữ liệu game, ký IPA đúng chứng chỉ, chạy Story Mode 10 giây.
2. Tạo phòng Online riêng một người, đợi 20 giây.
3. Mời một bạn vào (không cần cài mod), đợi 20 giây, **không bật Menyoo và không thực hiện Police RP**.
4. Bạn kia thoát, đợi 20 giây, rồi thoát phòng. Đọc `Documents/PoliceRPOnline-v16.txt`.
5. Gửi log hoặc chạy `python3 Tools/check_online_v16.py PoliceRPOnline-v16.txt`.

Bản test không lưu Player ID, mã mời, IP, tên hoặc mật khẩu phòng. Không ghi các thông tin đó vào log khi chia sẻ.

## Giới hạn

- Không có Native Hook, không có Network Bridge thật, không có người chơi gần nhất.
- Không có còng, tháo còng, áp giải, tù hoặc tương tác thật.
- Không sửa binary IPA tại bước build nguồn. Cần có dylib hợp lệ được GitHub build trước khi tạo IPA chẩn đoán.
- Vẫn sử dụng v12 **thường**, không bật Menyoo Online.
