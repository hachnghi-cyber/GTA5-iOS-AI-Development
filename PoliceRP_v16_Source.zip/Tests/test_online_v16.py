import sys
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'Tools'))
from check_online_v16 import analyze

H='[PRP_DIAG_V16] dylib_loaded=1 gta5_uuid_verified=1 hooks=0 network_events=0 police_gameplay=0 timer=main_queue_1s\n'
def s(t,job=-1,shift=0,mode=0,started=0,players=0,was=0,joining=0,active=None):
    if active is None: active=int(0<=job<=2 and shift==1)
    return f'[PRP_ONLINE_V16] tick={t} job={job} shift={shift} police_active={active} online_mode_raw={mode} session_started_raw={started} job_players_raw={players} was_in_game_raw={was} p2p_joining_raw={joining} remote_id_verified=0 player_count_verified=0 hooks=0 network_events=0\n'

class TestV16(unittest.TestCase):
    def test_missing_header(self): self.assertEqual(analyze(s(1))['status'],'LIBRARY_NOT_VERIFIED')
    def test_invalid_uuid(self): self.assertEqual(analyze(H.replace('verified=1','verified=0')+s(1))['status'],'LIBRARY_NOT_VERIFIED')
    def test_header_only(self): self.assertEqual(analyze(H)['status'],'TIMER_NO_SAMPLES')
    def test_idle(self):
        r=analyze(H+s(1)+s(20));self.assertEqual(r['status'],'SAMPLES_OK_NO_CHANGE');self.assertEqual(r['samples'],2)
    def test_session_transition(self):
        r=analyze(H+s(1)+s(5,mode=2,started=1,players=2,was=1));self.assertEqual(r['status'],'SESSION_STATE_CHANGE_OBSERVED');self.assertTrue(r['transitions']['online_mode_changed'])
    def test_joining_changes(self):
        r=analyze(H+s(1)+s(3,joining=1)+s(4,joining=0));self.assertTrue(r['transitions']['joining_changed'])
    def test_duty_transition(self):
        r=analyze(H+s(1)+s(2,job=0)+s(3,job=0,shift=1));self.assertTrue(r['transitions']['police_duty_changed'])
    def test_bad_police_active(self): self.assertEqual(analyze(H+s(1,job=0,shift=0,active=1))['status'],'BAD_SAMPLE')
    def test_corrupt_sample(self): self.assertEqual(analyze(H+s(1).replace('job_players_raw=0','job_players_raw=X'))['status'],'MALFORMED_SAMPLE')
    def test_duplicate_tick(self): self.assertEqual(analyze(H+s(1)+s(1,mode=2))['status'],'TICK_NOT_INCREASING')
    def test_invalid_snapshot(self): self.assertEqual(analyze(H+'[PRP_ONLINE_V16] invalid_snapshot=1 observe_only=1\n')['status'],'INVALID_SNAPSHOT')
    def test_not_player_count(self):
        r=analyze(H+s(1)+s(2,players=99));self.assertFalse(r['verified_player_count']);self.assertFalse(r['verified_remote_player_ids'])
    def test_unrelated_lines_ignored(self): self.assertEqual(analyze(H+'noise\n'+s(1))['samples'],1)
if __name__=='__main__':unittest.main()
