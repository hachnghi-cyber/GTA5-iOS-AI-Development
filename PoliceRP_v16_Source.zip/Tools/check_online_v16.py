#!/usr/bin/env python3
"""Read-only v1.6 on-device log analyzer: never treats raw job-player field as player count."""
import argparse
import json
import re
from pathlib import Path

HEADER = re.compile(r'^\[PRP_DIAG_V16\] dylib_loaded=1 gta5_uuid_verified=([01]) hooks=0 network_events=0 police_gameplay=0 timer=main_queue_1s$')
DATA = re.compile(r'^\[PRP_ONLINE_V16\] tick=(\d+) job=(-?\d+) shift=([01]) police_active=([01]) '
                  r'online_mode_raw=(-?\d+) session_started_raw=([01]) job_players_raw=(\d+) '
                  r'was_in_game_raw=([01]) p2p_joining_raw=([01]) '
                  r'remote_id_verified=0 player_count_verified=0 hooks=0 network_events=0$')
FIELDS = ('tick', 'job', 'shift', 'police_active', 'online_mode_raw',
          'session_started_raw', 'job_players_raw', 'was_in_game_raw', 'p2p_joining_raw')

def analyze(blob: str) -> dict:
    lines = [s.strip() for s in blob.splitlines() if s.strip()]
    header = [m for s in lines if (m := HEADER.fullmatch(s))]
    if not header or header[-1].group(1) != '1':
        return {'status': 'LIBRARY_NOT_VERIFIED', 'samples': 0}
    samples = []
    for line in lines:
        if line.startswith('[PRP_ONLINE_V16] invalid_snapshot=1'):
            return {'status': 'INVALID_SNAPSHOT', 'samples': len(samples)}
        if not line.startswith('[PRP_ONLINE_V16] tick='):
            continue
        match = DATA.fullmatch(line)
        if not match:
            return {'status': 'MALFORMED_SAMPLE', 'samples': len(samples)}
        s = dict(zip(FIELDS, map(int, match.groups())))
        if not (0 < s['tick'] < 10000000 and -1 <= s['job'] <= 64 and
                s['police_active'] == int(0 <= s['job'] <= 2 and s['shift'] == 1)
                and 0 <= s['job_players_raw'] <= 0xFFFFFFFF):
            return {'status': 'BAD_SAMPLE', 'samples': len(samples)}
        if samples and s['tick'] <= samples[-1]['tick']:
            return {'status': 'TICK_NOT_INCREASING', 'samples': len(samples)}
        samples.append(s)
    if not samples:
        return {'status':'TIMER_NO_SAMPLES','samples':0}
    transitions = {
        'online_mode_changed': any(a['online_mode_raw'] != b['online_mode_raw'] for a,b in zip(samples, samples[1:])),
        'session_started_changed': any(a['session_started_raw'] != b['session_started_raw'] for a,b in zip(samples, samples[1:])),
        'joining_changed': any(a['p2p_joining_raw'] != b['p2p_joining_raw'] for a,b in zip(samples, samples[1:])),
        'raw_job_field_changed': any(a['job_players_raw'] != b['job_players_raw'] for a,b in zip(samples, samples[1:])),
        'police_duty_changed': any(a['police_active'] != b['police_active'] for a,b in zip(samples, samples[1:]))
    }
    return {
        'status': 'SESSION_STATE_CHANGE_OBSERVED' if any(transitions.values()) else 'SAMPLES_OK_NO_CHANGE',
        'samples': len(samples), 'transitions': transitions,
        'first': samples[0], 'last': samples[-1],
        'verified_remote_player_ids': False,
        'verified_player_count': False,
        'note': 'job_players_raw is an unverified game field, NOT a validated player count',
    }

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('log', type=Path)
    args=p.parse_args()
    print(json.dumps(analyze(args.log.read_text('utf-8',errors='replace')),ensure_ascii=False,indent=2))
if __name__=='__main__':main()
