"""Preflight checks for the unified GTA V iOS v11.1 Gojo mod build.

These verify packaging/intent, not execution inside the iOS GTA engine.
"""

import hashlib
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parent


class GojoFullModTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.script = (ROOT / "Gojo_iOS.2.cs").read_text()
        cls.overlay = (ROOT / "native" / "GojoTouchOverlay.mm").read_text()
        cls.visual = (ROOT / "native" / "GojoVisualFX.mm").read_text()
        cls.queue_header = (ROOT / "native" / "GojoTouchQueue.h").read_text()
        cls.native_build = (ROOT / "native" / "build_ios.sh").read_text()

    def test_original_mod_wavs_are_exact(self):
        expected = {
            "RR.wav": "4708cdf42ba733775bac6c97eaede8c84b64e66262dff2949cb99ae7c5cc36a9",
            "Bl.wav": "d0ad8b837c5abbd4b4ae1178d3a2aebca7ccaf6aac63d1a3e77541c072ab5b61",
            "HP.wav": "d231306e793da33fd20ec8144ef276f32ca93a28ffb9caf65459aed069b0f167",
            "UV.wav": "694f7c714e1f2da8d0f0dbbc423d97b5986ac88a4f1a19874991c58198a88320",
            "MU.wav": "46f1d9f099f838da032fd8022a6a10497c966b4794d6d9bb21f5663936b7c927",
        }
        for name, digest in expected.items():
            with self.subTest(name=name):
                self.assertEqual(hashlib.sha256((ROOT / "gojomusic" / name)
                                                .read_bytes()).hexdigest(), digest)
                if name != "MU.wav":
                    self.assertIn(f'PlayOriginalSound("{name}")', self.script)
        self.assertTrue((ROOT / "gojomusic" / "MU_short.wav").is_file())
        # iOS AudioServices cannot play the 50s MU.wav as a system sound.
        self.assertIn('PlayOriginalSound("MU_short.wav")', self.script)

    def test_exactly_five_powers_with_matching_ui_and_bridge_indices(self):
        titles = ["INFINITY", "RED", "BLUE", "PURPLE", "VOID"]
        for ability, title in enumerate(titles):
            self.assertIn(f'@"{title}"', self.overlay)
            self.assertIn(f"TouchBridge.ShowVfx({ability}u)", self.script)
        self.assertIn("if (action >= 0 && action < 5)", self.overlay)

    def test_visual_is_only_after_accepted_cast(self):
        # UIButton posts an action; only the script on GTA's Tick may show FX.
        self.assertIn("gojo_touch_press((unsigned int)action)", self.overlay)
        pressed = self.overlay.split("- (void)pressed:(UIButton *)sender", 2)[-1]
        pressed = pressed.split("@end", 1)[0]
        self.assertNotIn("gojo_vfx_cast(", pressed)
        self.assertIn("gojo_touch_show_vfx", self.overlay)
        self.assertIn("gojo_touch_clear_vfx", self.overlay)
        self.assertIn("gojo_vfx_reset", self.visual)

    def test_legacy_screen_art_is_disabled_but_touch_is_unchanged(self):
        # Avoid a UI hierarchy traversal on every 50-ms game tick.
        self.assertIn("gEnabled.exchange(on, std::memory_order_acq_rel)",
                      self.overlay)
        self.assertIn("if (previous == on) return;", self.overlay)
        self.assertIn("#define GOJO_LEGACY_SCREEN_VFX 0", self.visual)
        self.assertIn("void gojo_vfx_attach(UIView *host) { (void)host; }",
                      self.visual)

    def test_blue_has_no_extra_240x_force(self):
        # Red/Purple retain their impulses; Blue does not stack them.
        red = self.script.split("private void PushRedWithVelocity", 1)[1]
        red = red.split("private void PullBlueWithVelocity", 1)[0]
        blue = self.script.split("private void PullBlueWithVelocity", 1)[1]
        blue = blue.split("private int HitPurple", 1)[0]
        self.assertIn("TrySetVelocity(entity, velocity, now)", red)
        self.assertIn("TryMoveNativeActor(target.Handle, velocity, now)", red)
        self.assertIn("TrySetVelocity(entity, velocity, now, false)", blue)
        self.assertIn("TryMoveNativeActor(target.Handle, velocity, now, false)", blue)
        self.assertIn("if (withImpulse)", self.script)

    def test_crashing_gta_marker_is_never_invoked(self):
        self.assertNotIn("Function.Call(Hash.DRAW_MARKER", self.script)
        self.assertIn("EnableExperimentalParticles = true", self.script)
        self.assertIn("MaxParticlesPerSecond = 22", self.script)
        self.assertIn("particleApiDisabled = true", self.script)
        self.assertIn("gojo_vfx_set_visible", self.overlay)

    def test_real_3d_fx_are_spawned_at_gta_world_coordinates(self):
        # Unlike the old Canvas overlays, particles use GTA world points.
        self.assertIn('Hash.HAS_NAMED_PTFX_ASSET_LOADED, "core"', self.script)
        self.assertIn('Hash.REQUEST_NAMED_PTFX_ASSET, "core"', self.script)
        self.assertIn("Hash.START_PARTICLE_FX_NON_LOOPED_AT_COORD", self.script)
        self.assertIn("position.X, position.Y, position.Z", self.script)
        self.assertIn("EmitWorldRing(orb, shrink", self.script)  # Blue vortex
        self.assertIn("EmitWorldRing(orb, 0.6f + progress", self.script)  # Red
        self.assertIn("EmitEnergy(orb + side", self.script)  # Purple trail
        self.assertIn("EmitWorldRing(center, 8.5f", self.script)  # Void

    def test_original_2022_mod_lighting_and_void_filter_are_ported(self):
        # In the original supplied Class1.cs, the visual code only uses
        # coloured DrawLightWithRange and DeathFailMPIn: no .ypt/.ydr assets.
        self.assertIn("World.DrawLightWithRange(center, Color.Red,", self.script)
        self.assertIn("100f, originalRedFrame * 5f", self.script)
        self.assertIn("20f, originalRedFrame * 10f", self.script)
        self.assertIn("World.DrawLightWithRange(orb, Color.Blue, 100f, 5f)",
                      self.script)
        self.assertIn("World.DrawLightWithRange(orb, Color.White, 20f, 10f)",
                      self.script)
        self.assertIn("World.DrawLightWithRange(left, Color.Red, 5f, 320f)",
                      self.script)
        self.assertIn("World.DrawLightWithRange(right, Color.Blue, 5f, 320f)",
                      self.script)
        self.assertIn("World.DrawLightWithRange(orb, Color.Purple, 7f, 1000f)",
                      self.script)
        self.assertIn("Hash._START_SCREEN_EFFECT", self.script)
        self.assertIn("Hash._STOP_SCREEN_EFFECT", self.script)
        self.assertIn('"DeathFailMPIn"', self.script)
        self.assertIn("StopOriginalVoidScreenEffect();", self.script)

    def test_dylib_exports_match_managed_declarations(self):
        for name in ["gojo_touch_consume", "gojo_touch_set_enabled",
                     "gojo_touch_show_vfx", "gojo_touch_clear_vfx"]:
            self.assertIn(f'EntryPoint = "{name}"', self.script)
            self.assertIn(name, self.queue_header)
            self.assertIn("_" + name, self.native_build)

    def test_build_inputs_are_present(self):
        self.assertTrue((ROOT / "Gojo_iOS.csproj").exists())
        for reference in ("ScriptHookVDotNet2.dll", "System.Windows.Forms.dll"):
            self.assertGreater((ROOT / "refs" / reference).stat().st_size, 0)


if __name__ == "__main__":
    unittest.main()
