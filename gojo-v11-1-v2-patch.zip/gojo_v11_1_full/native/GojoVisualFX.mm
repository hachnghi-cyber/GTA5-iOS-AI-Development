// Legacy 2D artwork retained behind a compile-time switch for comparisons.
// The supplied 2022 PC mod contains coloured World.DrawLightWithRange calls,
// not projectile meshes, particles, textures or shaders. These are NEW 2D
// visual effects to make cast feedback visible on this iOS port.
//
// UIKit/CoreAnimation only: no GTA drawing native (DRAW_MARKER crashed on iOS),
// no per-frame CPU renderer, no asset loading, no extra touches consumed.
#import "GojoVisualFX.h"
#import <QuartzCore/QuartzCore.h>
#import <objc/runtime.h>
#include <math.h>

// This v3D build uses GTA's own world-space particle renderer from the
// ScriptHook mod. Disabling these screen-space drawings does NOT disable
// the Gojo touch buttons (those live in GojoTouchOverlay.mm).
#define GOJO_LEGACY_SCREEN_VFX 0

#if GOJO_LEGACY_SCREEN_VFX

static char kGojoVfxAssociation;
static NSHashTable<UIView *> *sGojoCanvases;
static bool sInfinityVisualOn = false;

static UIColor *GojoColor(CGFloat r, CGFloat g, CGFloat b, CGFloat a)
{
    return [UIColor colorWithRed:r green:g blue:b alpha:a];
}

static void GojoAnimate(CALayer *layer, NSString *key, id from, id to,
                        CFTimeInterval seconds, CFTimeInterval delay)
{
    CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:key];
    animation.fromValue = from;
    animation.toValue = to;
    animation.beginTime = CACurrentMediaTime() + delay;
    animation.duration = seconds;
    animation.timingFunction = [CAMediaTimingFunction
        functionWithName:kCAMediaTimingFunctionEaseOut];
    animation.fillMode = kCAFillModeBoth;
    animation.removedOnCompletion = NO;
    [layer addAnimation:animation forKey:key];
}

@interface GojoVisualCanvas : UIView
@property(nonatomic, strong) CALayer *infinityLayer;
@end

@implementation GojoVisualCanvas

- (void)clearAllEffects
{
    for (CALayer *layer in [self.layer.sublayers copy])
        [layer removeFromSuperlayer];
    self.infinityLayer = nil;
}

- (CGPoint)playerPoint
{
    // Approximate projection in GTA's third-person camera: waist/hand region.
    // This does not pretend to be a 3D world-to-screen projection.
    return CGPointMake(CGRectGetWidth(self.bounds) * 0.49,
                       CGRectGetHeight(self.bounds) * 0.60);
}

- (CGPoint)targetPoint
{
    return CGPointMake(CGRectGetWidth(self.bounds) * 0.62,
                       CGRectGetHeight(self.bounds) * 0.43);
}

- (CALayer *)newBurstWithLifetime:(NSTimeInterval)lifetime
{
    CALayer *group = [CALayer layer];
    group.frame = self.bounds;
    [self.layer addSublayer:group];
    // All animation layers are removed even if the game stays open for hours.
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW,
        (int64_t)((lifetime + 0.15) * NSEC_PER_SEC)),
        dispatch_get_main_queue(), ^{ [group removeFromSuperlayer]; });
    return group;
}

- (void)orbIn:(CALayer *)group center:(CGPoint)center radius:(CGFloat)radius
        color:(UIColor *)tint duration:(CFTimeInterval)duration
        delay:(CFTimeInterval)delay
{
    CGFloat diameter = radius * 2.0;
    CAGradientLayer *orb = [CAGradientLayer layer];
    orb.type = kCAGradientLayerRadial;
    orb.startPoint = CGPointMake(0.5, 0.5);
    orb.endPoint = CGPointMake(1, 1);
    orb.frame = CGRectMake(center.x - radius, center.y - radius,
                           diameter, diameter);
    orb.colors = @[(id)[UIColor.whiteColor colorWithAlphaComponent:0.95].CGColor,
                   (id)[tint colorWithAlphaComponent:0.95].CGColor,
                   (id)[tint colorWithAlphaComponent:0.38].CGColor,
                   (id)[tint colorWithAlphaComponent:0].CGColor];
    orb.locations = @[@0.0, @0.18, @0.51, @1.0];
    [group addSublayer:orb];
    GojoAnimate(orb, @"transform.scale", @0.12, @1.28, duration, delay);
    GojoAnimate(orb, @"opacity", @0.98, @0.0, duration, delay);
}

- (void)ringIn:(CALayer *)group center:(CGPoint)center radius:(CGFloat)radius
         color:(UIColor *)tint stroke:(CGFloat)lineWidth
      duration:(CFTimeInterval)duration delay:(CFTimeInterval)delay
{
    CAShapeLayer *circle = [CAShapeLayer layer];
    // Give the ring its own local coordinate system. Otherwise scaling the
    // default zero-frame layer scales around (0,0), far from the spell.
    circle.frame = CGRectMake(center.x - radius, center.y - radius,
                              radius * 2.0, radius * 2.0);
    circle.path = [UIBezierPath bezierPathWithOvalInRect:
       CGRectMake(0, 0, radius * 2.0, radius * 2.0)].CGPath;
    circle.fillColor = UIColor.clearColor.CGColor;
    circle.strokeColor = tint.CGColor;
    circle.lineWidth = lineWidth;
    circle.shadowColor = tint.CGColor;
    circle.shadowRadius = 12.0;
    circle.shadowOpacity = 0.9;
    circle.shadowOffset = CGSizeZero;
    [group addSublayer:circle];
    GojoAnimate(circle, @"transform.scale", @0.15, @2.0, duration, delay);
    GojoAnimate(circle, @"opacity", @0.98, @0.0, duration, delay);
}

- (void)beamIn:(CALayer *)group from:(CGPoint)start to:(CGPoint)end
         color:(UIColor *)tint width:(CGFloat)width
      duration:(CFTimeInterval)duration delay:(CFTimeInterval)delay
{
    UIBezierPath *path = [UIBezierPath bezierPath];
    [path moveToPoint:start];
    [path addQuadCurveToPoint:end controlPoint:
        CGPointMake((start.x + end.x) * 0.5,
                    (start.y + end.y) * 0.5 - width * 1.7)];
    CAShapeLayer *beam = [CAShapeLayer layer];
    beam.path = path.CGPath;
    beam.strokeColor = tint.CGColor;
    beam.fillColor = UIColor.clearColor.CGColor;
    beam.lineCap = kCALineCapRound;
    beam.lineWidth = width;
    beam.shadowColor = tint.CGColor;
    beam.shadowOffset = CGSizeZero;
    beam.shadowRadius = width * 2.0;
    beam.shadowOpacity = 1.0;
    [group addSublayer:beam];
    GojoAnimate(beam, @"strokeEnd", @0.0, @1.0, duration * 0.62, delay);
    GojoAnimate(beam, @"opacity", @0.95, @0.0, duration, delay);
}

- (void)sparksIn:(CALayer *)group center:(CGPoint)center radius:(CGFloat)radius
          color:(UIColor *)tint count:(int)count
       duration:(CFTimeInterval)duration delay:(CFTimeInterval)delay
{
    for (int i = 0; i < count; ++i)
    {
        const CGFloat fullCircle = 6.283185307179586;
        CGFloat angle = (CGFloat)i * (fullCircle / (CGFloat)count);
        // Different lengths without randomness: stable, deterministic VFX.
        CGFloat distance = radius * (0.58 + 0.35 * (i % 3));
        CGPoint destination = CGPointMake(center.x + distance * cos(angle),
                                           center.y + distance * sin(angle));
        CGFloat dotSize = 2.5 + (i % 3);
        CALayer *spark = [CALayer layer];
        spark.bounds = CGRectMake(0, 0, dotSize, dotSize);
        spark.cornerRadius = dotSize * 0.5;
        spark.backgroundColor = tint.CGColor;
        spark.shadowColor = tint.CGColor;
        spark.shadowRadius = 7.0;
        spark.shadowOpacity = 1.0;
        spark.position = center;
        [group addSublayer:spark];
        GojoAnimate(spark, @"position", [NSValue valueWithCGPoint:center],
                    [NSValue valueWithCGPoint:destination], duration, delay);
        GojoAnimate(spark, @"opacity", @0.9, @0.0, duration, delay);
    }
}

- (void)toggleInfinity:(BOOL)enabled
{
    if (!enabled)
    {
        [self.infinityLayer removeFromSuperlayer];
        self.infinityLayer = nil;
        return;
    }
    if (self.infinityLayer) return;
    CGPoint center = [self playerPoint];
    CGFloat diameter = MIN(self.bounds.size.width, self.bounds.size.height) * 0.44;
    CGFloat radius = diameter / 2.0;
    CALayer *group = [CALayer layer];
    group.frame = self.bounds;
    [self.layer addSublayer:group];
    self.infinityLayer = group;

    CAShapeLayer *boundary = [CAShapeLayer layer];
    boundary.path = [UIBezierPath bezierPathWithOvalInRect:
        CGRectMake(center.x - radius, center.y - radius,
                   diameter, diameter)].CGPath;
    UIColor *blue = GojoColor(0.17, 0.82, 1.0, 0.8);
    boundary.strokeColor = blue.CGColor;
    boundary.fillColor = UIColor.clearColor.CGColor;
    boundary.lineWidth = 2.4;
    boundary.shadowColor = blue.CGColor;
    boundary.shadowRadius = 14.0;
    boundary.shadowOpacity = 0.85;
    [group addSublayer:boundary];
    CABasicAnimation *pulse = [CABasicAnimation animationWithKeyPath:@"opacity"];
    pulse.fromValue = @0.2;
    pulse.toValue = @0.85;
    pulse.duration = 0.95;
    pulse.autoreverses = YES;
    pulse.repeatCount = HUGE_VALF;
    [boundary addAnimation:pulse forKey:@"InfinityPulse"];
}

- (void)cast:(unsigned int)ability
{
    if (ability == 0)
    {
        [self toggleInfinity:sInfinityVisualOn];
        return;
    }
    CGFloat basis = MIN(self.bounds.size.width, self.bounds.size.height);
    CGFloat stroke = MAX(2.4, basis * 0.008);
    CGPoint origin = [self playerPoint];
    CGPoint target = [self targetPoint];
    CALayer *group = [self newBurstWithLifetime:ability == 4 ? 4.5 : 1.7];

    switch (ability)
    {
        case 1: { // Reversal Red: explosive red shockwave from Gojo.
            UIColor *red = GojoColor(1, 0.12, 0.25, 1);
            [self orbIn:group center:origin radius:basis * 0.21
                  color:red duration:0.78 delay:0];
            [self ringIn:group center:origin radius:basis * 0.17
                   color:red stroke:stroke * 1.5 duration:0.6 delay:0.08];
            [self beamIn:group from:origin to:target color:red
                   width:stroke * 3.8 duration:0.7 delay:0.05];
            [self sparksIn:group center:target radius:basis * 0.36
                     color:red count:13 duration:0.8 delay:0.25];
            break;
        }
        case 2: { // Lapse Blue: suction target in front, NOT at player.
            UIColor *blue = GojoColor(0.10, 0.54, 1.0, 1.0);
            [self orbIn:group center:target radius:basis * 0.23
                  color:blue duration:1.2 delay:0];
            for (int ring = 0; ring < 3; ++ring)
                [self ringIn:group center:target radius:basis * (0.08 + ring * 0.05)
                       color:blue stroke:stroke duration:1.0 delay:ring * 0.14];
            [self sparksIn:group center:target radius:basis * 0.25
                     color:GojoColor(0.2, 0.85, 1.0, 1) count:14
                  duration:0.95 delay:0.12];
            break;
        }
        case 3: { // Hollow Purple: merge red/blue, then a large travelling ray.
            UIColor *purple = GojoColor(0.73, 0.19, 1, 1);
            [self orbIn:group center:CGPointMake(origin.x - basis * 0.12, origin.y)
                    radius:basis * 0.12 color:UIColor.redColor
                  duration:0.62 delay:0];
            [self orbIn:group center:CGPointMake(origin.x + basis * 0.12, origin.y)
                    radius:basis * 0.12 color:UIColor.cyanColor
                  duration:0.62 delay:0];
            CGPoint far = CGPointMake(self.bounds.size.width * 0.86,
                                      self.bounds.size.height * 0.34);
            [self beamIn:group from:origin to:far color:purple
                   width:stroke * 7.0 duration:0.95 delay:0.25];
            [self beamIn:group from:origin to:far color:UIColor.whiteColor
                   width:stroke * 1.8 duration:0.95 delay:0.29];
            [self orbIn:group center:far radius:basis * 0.26
                  color:purple duration:0.9 delay:0.53];
            [self sparksIn:group center:far radius:basis * 0.47
                     color:purple count:19 duration:0.82 delay:0.59];
            break;
        }
        case 4: { // Unlimited Void: purple screen tint + expanding domain rings.
            CALayer *tint = [CALayer layer];
            tint.frame = self.bounds;
            UIColor *shade = GojoColor(0.12, 0.015, 0.27, 0.4);
            tint.backgroundColor = shade.CGColor;
            [group addSublayer:tint];
            GojoAnimate(tint, @"opacity", @0.9, @0.0, 4.5, 0);
            UIColor *violet = GojoColor(0.58, 0.35, 1, 1);
            for (int ring = 0; ring < 5; ++ring)
                [self ringIn:group center:CGPointMake(self.bounds.size.width / 2.0,
                                                     self.bounds.size.height / 2.0)
                       radius:basis * (0.07 + ring * 0.055)
                       color:violet stroke:stroke duration:3.5
                       delay:ring * 0.25];
            break;
        }
        default:
            [group removeFromSuperlayer];
            break;
    }
}

@end

void gojo_vfx_attach(UIView *host)
{
    if (!host || objc_getAssociatedObject(host, &kGojoVfxAssociation)) return;
    if (!sGojoCanvases) sGojoCanvases = [NSHashTable weakObjectsHashTable];

    GojoVisualCanvas *canvas = [[GojoVisualCanvas alloc] initWithFrame:host.bounds];
    canvas.autoresizingMask = UIViewAutoresizingFlexibleWidth |
                               UIViewAutoresizingFlexibleHeight;
    canvas.backgroundColor = UIColor.clearColor;
    canvas.userInteractionEnabled = NO;
    canvas.opaque = NO;
    [host insertSubview:canvas atIndex:0];
    objc_setAssociatedObject(host, &kGojoVfxAssociation, canvas,
                             OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    [sGojoCanvases addObject:canvas];
    if (sInfinityVisualOn) [canvas toggleInfinity:YES];
}

void gojo_vfx_cast(unsigned int ability)
{
    if (ability >= 5u) return;
    // Called on UIKit's main thread from UIButton target action.
    if (ability == 0) sInfinityVisualOn = !sInfinityVisualOn;
    for (UIView *view in sGojoCanvases.allObjects)
    {
        if ([view isKindOfClass:[GojoVisualCanvas class]] && !view.hidden)
            [(GojoVisualCanvas *)view cast:ability];
    }
}

void gojo_vfx_set_visible(int enabled)
{
    for (UIView *view in sGojoCanvases.allObjects)
        view.hidden = enabled == 0;
}

void gojo_vfx_reset(void)
{
    sInfinityVisualOn = false;
    for (UIView *view in sGojoCanvases.allObjects)
        if ([view isKindOfClass:[GojoVisualCanvas class]])
            [(GojoVisualCanvas *)view clearAllEffects];
}

#else

void gojo_vfx_attach(UIView *host) { (void)host; }
void gojo_vfx_cast(unsigned int ability) { (void)ability; }
void gojo_vfx_set_visible(int enabled) { (void)enabled; }
void gojo_vfx_reset(void) { }

#endif
