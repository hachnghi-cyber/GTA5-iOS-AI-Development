"""Revision 2 regression checks; structural only, not an iPhone test."""

from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parent


class GojoV2SafetyTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.source = (ROOT / "Gojo_iOS.2.cs").read_text(encoding="utf-8")

    def test_still_has_five_keyboard_and_touch_abilities(self):
        for key in ("H", "J", "U", "Y", "I"):
            self.assertRegex(self.source, r"key == Keys\." + key + r"\b")
        for number in range(5):
            self.assertIn(f"TouchBridge.ShowVfx({number}u)", self.source)

    def test_aborted_script_releases_frozen_entities(self):
        self.assertIn("Aborted += OnAborted;", self.source)
        teardown = self.source.split("private void OnAborted", 1)[1]
        teardown = teardown.split("private void OnKeyDown", 1)[0]
        self.assertIn("EmergencyReset();", teardown)
        self.assertIn("TouchBridge.SetEnabled(false);", teardown)
        reset = self.source.split("private void EmergencyReset()", 1)[1]
        reset = reset.split("private static class TouchBridge", 1)[0]
        self.assertIn("ReleaseAll(voidFrozen, infinityFrozen)", reset)
        self.assertIn("ReleaseNativeFrozen(voidNativeFrozen, infinityNativeFrozen)", reset)

    def test_safe_mode_disables_optional_graphics_not_gameplay(self):
        self.assertIn('"GOJO_SAFE_MODE.txt"', self.source)
        self.assertIn("safeModeRequested = IsSafeModeRequested()", self.source)
        for method in ("RenderInfinity", "RenderRed", "RenderBlue",
                       "RenderPurple", "RenderVoid"):
            section = self.source.split("private void " + method, 1)[1]
            self.assertIn("if (safeModeRequested) return;", section[:210])
        self.assertRegex(
            self.source,
            r"private void StartOriginalVoidScreenEffect\(\)\s*\{"
            r"\s*if \(safeModeRequested \|\| originalVoidScreenUnsupported\)",
        )
        self.assertIn("if (safeModeRequested || !EnableExperimentalParticles", self.source)

    def test_loading_screen_does_not_repeatedly_reset(self):
        self.assertIn("if (gamePlayerWasReady) EmergencyReset();", self.source)
        self.assertIn("gamePlayerWasReady = false;", self.source)

    def test_no_windows_sound_player_or_crashing_marker(self):
        self.assertNotIn("using System.Media;", self.source)
        self.assertNotIn("Hash.DRAW_MARKER", self.source)
        self.assertIn("AudioServicesCreateSystemSoundID", self.source)

    def test_blue_and_purple_use_3d_orbits_with_shared_budget(self):
        self.assertIn("private void EmitVerticalRing", self.source)
        self.assertIn("lateral * (radius * (float)Math.Cos(angle))", self.source)
        self.assertIn("radius * (float)Math.Sin(angle)", self.source)
        self.assertIn("EmitVerticalRing(orb, new Vector3(0f, 1f, 0f)",
                      self.source)
        self.assertIn("EmitVerticalRing(orb, purpleDirection, 0.9f",
                      self.source)
        self.assertIn("MaxParticlesPerSecond = 22", self.source)


if __name__ == "__main__":
    unittest.main()
