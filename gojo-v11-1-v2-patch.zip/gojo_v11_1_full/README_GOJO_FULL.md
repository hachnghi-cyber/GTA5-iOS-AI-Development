# Gojo iOS v11.1 – bản làm lại V2 / 3D World-Space VFX (THỬ NGHIỆM)

## Những sửa đổi riêng của V2 (08/11/2026)

- Giữ đủ **Infinity, Red, Blue, Hollow Purple, Unlimited Void** và bộ âm
  thanh WAV nguyên bản. Không đưa `System.Media.SoundPlayer` hay các hàm
  Windows không có trên iPhone vào đường chạy âm thanh.
- Đăng ký sự kiện **ScriptHook `Aborted`** để thử giải phóng NPC/xe đang bị
  đóng băng và ẩn nút cảm ứng khi script được tải lại/tắt bình thường.
  Lưu ý: **SIGSEGV native không thể được bắt bằng C#**, nên đây là cơ chế
  dọn dẹp khi script dừng có kiểm soát, không phải bảo đảm chống crash.
- Trong lúc loading hoặc chuyển map, chỉ dọn một lần khi nhân vật biến mất,
  không lặp lại thao tác dọn VFX 20 lần/giây.
- Blue có thêm vòng hạt xoay **thẳng đứng** quanh tâm hút; Purple chuyển
  từ hai hạt Đỏ/Xanh đang tụ lại sang vòng sáng hạt xoáy quanh quỹ đạo
  bay. Vị trí hạt tính trong hệ tọa độ 3D của game; giới hạn tổng cộng 22
  hạt/giây để giảm chi phí đồ họa.
- Thêm chế độ `GOJO_SAFE_MODE.txt`: đặt một **file rỗng** đúng tên này trong
  `scripts/` của ScriptHook (hoặc cạnh `Gojo_iOS.dll`) rồi khởi động lại game.
  Chế độ an toàn **tắt toàn bộ đồ họa bổ sung** của Gojo (hạt, ánh sáng và
  filter Unlimited Void), giữ 5 kỹ năng, WAV và nút cảm ứng. Xóa file này,
  khởi động lại để bật lại hiệu ứng. Hữu ích để khoanh vùng crash do native.
- Bổ sung `test_v2_safety.py` để phát hiện hồi quy về 5 phím, dọn frozen,
  chế độ an toàn và sự phụ thuộc Windows.

**Trạng thái:** đã rà soát mã nguồn + chạy kiểm tra tĩnh. Chưa biên dịch
trên macOS, chưa cài hay chơi thử trên iPhone. Các API PTFX có thể không
được bản port hỗ trợ. Chưa có tài nguyên mesh/texture anime của mod TikTok;
V2 là hiệu ứng 3D world-space từ bộ PTFX GTA V, không phải bản sao 1:1.

## Cài V2 trên iPhone bằng GitHub Actions

1. Giữ nguyên Release private `gojo-base-v11-1` chứa IPA v11.1 gốc và
   `Gojo_iOS_v11_1_FULL_OnePass_Source_TEST.zip` (không chỉnh sửa gốc).
2. Đưa `gojo-v11-1-v2-patch.zip` vào **thư mục gốc** của repo và đặt
   `gojo-iphone-v2-release.yml` tại `.github/workflows/`, rồi commit cả hai.
3. Mở **Actions → Gojo v11.1 V2 SAFE 3D iPhone Build (TEST) → Run workflow**.
4. Chỉ khi job màu xanh mới tải artifact có **IPA chưa ký** và ZIP
   **ScriptHook**. Ký IPA theo phương pháp của bạn; sao lưu dữ liệu/saves
   trước khi cài. Mở game rồi nhập **ZIP ScriptHook** qua mục MODS.
5. Vô hiệu hóa bản Gojo cũ trước khi nhập, tránh tải trùng hai DLL.

Khi đã gặp văng ở hiệu ứng: chạy lại trong chế độ an toàn, lấy `run.log`,
`posthook.log` và crash report để xác định API gây lỗi. Đừng đăng bản thử
nghiệm này như bản ổn định cho người dùng cuối.

## Bản 3D khác bản trước như thế nào?

- **Đã đối chiếu `Class1.cs` của ZIP mod Gojo 2022 gốc:** không có
  `.ypt`, `.ydr`, shader hoặc texture. Gốc chỉ dùng
  `World.DrawLightWithRange` và màn hình `DeathFailMPIn` cùng 5 WAV.
- Khôi phục đúng các công thức ánh sáng Red (đỏ + trắng), Blue (xanh + trắng)
  và Purple (đỏ/xanh/trắng chuyển sang tím/trắng) với thông số ánh sáng gốc;
  vị trí và thời gian được điều chỉnh để khớp hitbox iOS và không kéo xe vào
  người chơi. Unlimited Void bật filter `DeathFailMPIn` trong 4,5 giây và
  cố gắng dọn filter sau khi kết thúc/reset. Infinity không có VFX gốc.
- Không còn vẽ quả cầu/tia sáng 2D cố định trên màn hình.
- Cả năm chiêu yêu cầu hiệu ứng hạt PTFX `core` của chính GTA V tại tọa độ
  **3D trong thế giới game**: Red tạo vòng xung kích lan rộng, Blue có luồng
  hút xoay quanh mục tiêu cách người chơi 10 m, Purple phát sáng dọc đường
  đạn di chuyển, Infinity/Unlimited Void có các hạt bao quanh khu vực.
- Phần mềm giới hạn **22 hạt/giây** và dừng gọi API khi nhiều lần báo lỗi;
  thao tác vật lý và 5 tệp WAV gốc không đổi.
- Tuyệt đối không gọi `DRAW_MARKER` vì GTA V iOS trước đó đã SIGSEGV trong
  `CommandDrawMarkerEx`.
- **Chưa xác minh khả năng hiển thị hoặc độ ổn định trên máy thật.** Nếu port
  thiếu dictionary `core` hoặc không hỗ trợ `START_PARTICLE_FX_NON_LOOPED_AT_COORD`,
  game chỉ còn ánh sáng 3D, không có hạt; một lỗi native SIGSEGV vẫn có thể
  gây crash trước khi C# kịp tắt hiệu ứng.
- PTFX mặc định của GTA không phải mô hình anime Gojo có mesh/shader riêng;
  không hứa tương đồng hình ảnh PC 100%.

## Phạm vi gói

Bộ này được dựng từ **chính** `GTAV-v11.1(1).ipa` (SHA256 bắt đầu
`a3f7b847...`) và mod Gojo PC 2022 do người dùng cung cấp.

Workflow GitHub Actions tạo cùng lúc **hai tệp khớp phiên bản**:

1. `GTAV_v11_1_Gojo_3D_PTFX_UNSIGN_TEST.ipa`: GTA v11.1 gốc, chỉ thêm
   `GojoTouchBridge.dylib` và một lệnh tải thư viện trong vùng trống header
   `libgtacompat.dylib`. Bản 3D tắt vẽ 2D trong dylib và thay bằng engine
   PTFX ở phía C#. Đây là **IPA chưa ký**, phải ký lại trước khi cài.
2. `Gojo_v11_1_3D_PTFX_ScriptHook_IMPORT_TEST.zip`: chứa đúng **một**
   `scripts/Gojo_iOS.dll` đã biên dịch, năm WAV gốc byte-identical từ mod PC
   và `MU_short.wav` (đoạn mở đầu 5 giây được trích từ MU.wav).

Gói ScriptHook không nhét C# `.2.cs` vào `scripts` vì ScriptHook sẽ biên dịch
trùng với DLL và chạy hai bản script, rất dễ gây lỗi. Mã `.2.cs` vẫn có trong
bộ source để sửa lại về sau.

## Có những chiêu nào?

| Nút | Chiêu | Gameplay hiện được lập trình | VFX của bản này |
| --- | --- | --- | --- |
| Infinity | Chặn vật thể trong vòng bảo vệ | Đóng băng vòng ngoài, giải phóng khi tắt | Vòng hạt PTFX 3D xoay quanh người |
| Red | Reverse Red | Đẩy peds và xe bằng vận tốc + lực vật lý | Ánh sáng đỏ/trắng gốc + vòng hạt PTFX 3D lan rộng |
| Blue | Lapse Blue | Hút mục tiêu về tâm cách người chơi 10m; KHÔNG áp lực phụ 240 lần | Ánh sáng xanh/trắng gốc + xoáy hạt PTFX 3D tại tâm hút |
| Purple | Hollow Purple | Vùng va chạm di chuyển phía trước, đẩy mục tiêu; không xóa entity hàng loạt | Ánh sáng đỏ/xanh/tím/trắng gốc + hạt PTFX 3D dọc vùng va chạm |
| Void | Unlimited Void | Tạm đóng băng NPC, giải phóng tự động sau 4,5 giây | Bộ lọc màn hình gốc + vành hạt PTFX 3D |

**Trung thực về tính năng:** nguồn Gojo PC chỉ có đèn màu GTA và một bộ lọc
toàn màn hình, không kèm mô hình quả cầu hoặc tia chiếu. Bản 3D dùng hiệu ứng
hạt của GTA V, không tạo thêm mesh/model riêng. Màu tùy theo cách engine
render particle, có thể không khớp hoàn toàn yêu cầu.

## Cách chạy một lượt trên GitHub iPhone (repo Private)

1. Giữ nguyên Release private `gojo-base-v11-1` chứa IPA v11.1 gốc và ZIP
   Gojo source gốc bất biến. Không cần sửa Release hoặc tải lại IPA gốc.
2. Upload đúng file `gojo-v11-1-3d-patch.zip` vào **thư mục gốc** của repository,
   rồi upload file workflow `gojo-iphone-3d-release.yml` vào
   `.github/workflows/` (commit cả hai).
3. Vào **Actions → Gojo v11.1 - REAL 3D PTFX iPhone Build (TEST)** →
   **Run workflow**, để tag `gojo-base-v11-1`.
4. Tải artifact `Gojo_v11_1_3D_PTFX_UNSIGNED_TEST`.
5. Ký lại IPA bằng SideStore/chứng chỉ như bình thường. Sao lưu dữ liệu game
   trước khi cài hoặc thay ứng dụng.
6. Mở GTA v11.1, đảm bảo đã cài **ScriptHook Pack phù hợp với v11.1** qua
   mục MODS của launcher, sau đó nhập tệp
   `Gojo_v11_1_3D_PTFX_ScriptHook_IMPORT_TEST.zip` vào MODS.

**Quan trọng:** nếu trước đây đã cài Gojo ở bản khác, cần bảo đảm chỉ có
**một** bản `Gojo_iOS.dll` đang được ScriptHook tải. Tắt/gỡ bản cũ theo trình
quản lý MODS. Nếu Gojo bị tự vô hiệu hóa sau crash trước, kiểm tra và bỏ đúng
dòng script Gojo trong `posthook/disabled-scripts.txt` sau khi đã sao lưu.
Không xóa toàn bộ thư mục MODS hoặc dữ liệu game.

## Chưa được bảo đảm và tiêu chí kiểm thử bắt buộc

- Chưa có quyền chạy ứng dụng trên iPhone của người dùng; test mã và đóng
  gói **không tương đương** test gameplay.
- Cần xác nhận nút hiện và nhận chạm; cả 5 WAV đúng; hiệu ứng không che nút
  Menyoo/tạm dừng; Blue không đẩy xe vào người; Red có lực; Purple va chạm;
  Infinity/Void giải phóng NPC; tắt game không bị giữ NPC đông cứng; nhiệt
  độ, FPS và bộ nhớ ổn định; vào/ra game không crash.
- VFX chỉ chạy khi C# **chấp nhận** chiêu, nên không hiện tia ảo trong lúc
  chiêu đang cooldown. Khi reset hoặc lỗi script sẽ dọn VFX.
- Không dùng `DRAW_MARKER` vì đã có log SIGSEGV tại `CommandDrawMarkerEx`.
- IPA và mod ZIP được kiểm tra tính toàn vẹn, nhưng các bước biên dịch iOS
  và C# phải thực hiện trên runner macOS/.NET qua GitHub Actions.
- Không quảng cáo là bản **100% ổn định** cho tới khi đạt kiểm thử thực tế.
